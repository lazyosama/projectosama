package com.cts.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;

public class DBConnect {									//Creating class to connect database
	ResourceBundle res=null;								//creating Resource bundle and connection
	Connection con=null;
public void initializeDriver() 								//method to initialise MySql driver
{
	
	res=ResourceBundle.getBundle("DBproperties");			//setting Property File
	try {
		Class.forName(res.getString("DriverName"));			//setting Driver Name
	} catch (ClassNotFoundException e) {
		
		 Logger.getLogger(DBConnect.class.getName()).error(e.toString());
	}
	
}
public Connection getConnect() {							//Method to set connection
	try {
		
		con=DriverManager.getConnection(res.getString("url"),res.getString("userName"),res.getString("password"));
	
	
	} catch (SQLException e) {
		
		 Logger.getLogger(DBConnect.class.getName()).error(e.toString());
	}
	return con;												//returning connection object
}
}
