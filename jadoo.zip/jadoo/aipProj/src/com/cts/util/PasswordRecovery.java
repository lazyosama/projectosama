package com.cts.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;
import com.cts.model.SetPass;


public class PasswordRecovery {
		Connection con=null;
		PreparedStatement smt=null;
		ResultSet rs=null;
		ResourceBundle resource=null;
		public boolean adminPassRecovery(SetPass sp) throws SQLException
		{
			
			resource=ResourceBundle.getBundle("query");
			DBConnect connect=new DBConnect();
			connect.initializeDriver();
			con=connect.getConnect();
			int i=0;
			boolean result=false;
			try {
				
				smt= con.prepareStatement(resource.getString("SET_ADMIN_PASSWORD"));
				smt.setString(1,sp.getPass());
				smt.setString(2, sp.getUid());
				i=smt.executeUpdate();
				
				if(i!=0)
				{
					
					result=true;
				}
				
			}
			catch (SQLException e) {
				
				 Logger.getLogger(PasswordRecovery.class.getName()).error(e.toString());
			}
			return result;
				
		}			
		public boolean userPassRecovery(SetPass sp) throws SQLException
		{
			
			resource=ResourceBundle.getBundle("query");
			DBConnect connect=new DBConnect();
			connect.initializeDriver();
			con=connect.getConnect();
			int i=0;
			boolean result=false;
			try {
				
				smt= con.prepareStatement(resource.getString("SET_USER_PASSWORD"));
				smt.setString(1,sp.getPass());
				smt.setString(2, sp.getUid());
				i=smt.executeUpdate();
				
				if(i!=0)
				{
					
					result=true;
				}
				
			}
			catch (SQLException e) {
				
				 Logger.getLogger(PasswordRecovery.class.getName()).error(e.toString());
			}
			return result;
				
		}			

}
