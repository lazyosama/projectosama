package com.cts.model;

public class DefaulterVO {
private String uid,status,name,bankno,comment,dot;
private int rating,accrstatus,dpd;
private long accno;
public String getUid() {
	return uid;
}
public void setUid(String uid) {
	this.uid = uid;
}

public String getDot() {
	return dot;
}
public void setDot(String dot) {
	this.dot = dot;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getBankno() {
	return bankno;
}
public void setBankno(String bankno) {
	this.bankno = bankno;
}
public String getComment() {
	return comment;
}
public void setComment(String comment) {
	this.comment = comment;
}
public int getRating() {
	return rating;
}
public void setRating(int rating) {
	this.rating = rating;
}
public int getAccrstatus() {
	return accrstatus;
}
public void setAccrstatus(int accrstatus) {
	this.accrstatus = accrstatus;
}
public int getDpd() {
	return dpd;
}
public void setDpd(int dpd) {
	this.dpd = dpd;
}
public long getAccno() {
	return accno;
}
public void setAccno(long accno) {
	this.accno = accno;
}

}
