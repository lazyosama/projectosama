package com.cts.model;

public class UpdateManualVO {
	private String uid,status,name,bno,comments,dot;
	private int dpd,accrstatus,rating;
	private long accno;
	
	public String getDot() {
		return dot;
	}
	public void setDot(String dot) {
		this.dot = dot;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBno() {
		return bno;
	}
	public void setBno(String bno) {
		this.bno = bno;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public int getDpd() {
		return dpd;
	}
	public void setDpd(int dpd) {
		this.dpd = dpd;
	}
	public int getAccrstatus() {
		return accrstatus;
	}
	public void setAccrstatus(int accrstatus) {
		this.accrstatus = accrstatus;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public long getAccno() {
		return accno;
	}
	public void setAccno(long accno) {
		this.accno = accno;
	}
	

}
