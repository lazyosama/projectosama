package com.cts.model;

import java.util.Date;

public class UserExlVO {
	private String uname,name,defalt,fromB;
	private int amount;
	long fromA,toA;
	private Date dot;
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDefalt() {
		return defalt;
	}
	public void setDefalt(String defalt) {
		this.defalt = defalt;
	}
	public String getFromB() {
		return fromB;
	}
	public void setFromB(String fromB) {
		this.fromB = fromB;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public long getFromA() {
		return fromA;
	}
	public void setFromA(long fromA) {
		this.fromA = fromA;
	}
	public long getToA() {
		return toA;
	}
	public void setToA(long toA) {
		this.toA = toA;
	}
	public Date getDOT() {
		return dot;
	}
	public void setDOT(Date dot) {
		this.dot = dot;
	}
	
}
