package com.cts.junit;

import static org.junit.Assert.*;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cts.dao.UserRegisterDAO;
import com.cts.model.UserRegisterVo;

public class UserRegisterDAOTest {
	UserRegisterDAO ldao;

	  UserRegisterVo lvo;
	@Before
	public void setUp() throws Exception {

      ldao=new UserRegisterDAO();

      lvo=new UserRegisterVo();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testRegisterPass() {


      lvo.setLog("U1111");
      lvo.setPass("User1111");
      lvo.setFname("kalai");
      lvo.setLname("Ravi");
      lvo.setGender("female");
      lvo.setCum(Long.parseLong("9015383819"));
      lvo.setAdd("Salem");
      lvo.setAge(Integer.parseInt("25"));
      lvo.setEmail("kalai@gmail.com");
      lvo.setCountry("India");
      lvo.setCity("Chennai");
      lvo.setZip(Integer.parseInt("457564"));

      assertEquals(true, ldao.validateLogin(lvo));	
	}
	@Test
	public void testRegisterFail() {


    lvo.setLog("U1111");
      lvo.setPass("Admi1111");
      lvo.setFname("Jerry");
      lvo.setLname("ranji");
      lvo.setGender("male");
      lvo.setCum(Long.parseLong("9003434321254"));
      lvo.setAdd("namakkal");
      lvo.setAge(Integer.parseInt("19"));
      lvo.setEmail("dhasdrew@gmail.com");
      lvo.setCountry("Japi");
      lvo.setCity("Fukuo");
      lvo.setZip(Integer.parseInt("9552432"));

      assertEquals(false, ldao.validateLogin(lvo));	
	}
	@Test
	public void testRegisterEmpty() {


      lvo.setLog("");
      lvo.setPass("");
      lvo.setFname("");
      lvo.setLname("");
      lvo.setGender("");
      lvo.setCum(0);
      lvo.setAdd("");
      lvo.setAge(0);
      lvo.setEmail("");
      lvo.setCountry("");
      lvo.setCity("");
      lvo.setZip(0);

      assertEquals(false, ldao.validateLogin(lvo));	
	}


}
