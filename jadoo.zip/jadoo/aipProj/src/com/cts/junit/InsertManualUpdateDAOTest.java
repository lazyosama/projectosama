package com.cts.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cts.dao.InsertManualUpdateDAO;
import com.cts.model.InsertManualUpdateVO;

public class InsertManualUpdateDAOTest {
InsertManualUpdateVO lvo;
InsertManualUpdateDAO ldao;
	@Before
	public void setUp() throws Exception {
		lvo=new InsertManualUpdateVO();
		ldao=new InsertManualUpdateDAO();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void insertManualUpdatePass() {
		lvo.setUid("U4444");
		lvo.setDot("2016-05-11");
		lvo.setStatus("AUTO_WEAVER");
		lvo.setAccrstatus(Integer.parseInt("7"));
		lvo.setName("Subrato");
		lvo.setBno("HDFC124");
		lvo.setRating(Integer.parseInt("4"));
		lvo.setDpd(Integer.parseInt("167"));
		lvo.setComments("No dues");
lvo.setAccno(Long.parseLong("1234562"));
assertEquals(true, ldao.insertManualUpdate(lvo));
		
	}
	
	@Test
	public void insertManualUpdateFail() {
		lvo.setUid("U4443");
		lvo.setDot("2016-03-23");
		lvo.setStatus("VALIDATE_ERROR");
		lvo.setAccrstatus(Integer.parseInt("1"));
		lvo.setName("Subrato");
		lvo.setBno("IDBI124");
		lvo.setRating(Integer.parseInt("8"));
		lvo.setDpd(Integer.parseInt("45"));
		lvo.setComments("Dues pending");
lvo.setAccno(Long.parseLong("123456245"));
assertEquals(false, ldao.insertManualUpdate(lvo));
		
	}

	@Test
	public void insertManualUpdateEmpty() {
		lvo.setUid("");
		lvo.setDot("");
		lvo.setStatus("");
		lvo.setAccrstatus(0);
		lvo.setName("");
		lvo.setBno("");
		lvo.setRating(0);
		lvo.setDpd(0);
		lvo.setComments("");
lvo.setAccno(0);
assertEquals(false, ldao.insertManualUpdate(lvo));
		
	}


}
