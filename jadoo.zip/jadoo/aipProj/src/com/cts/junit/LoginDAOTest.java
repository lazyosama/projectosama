package com.cts.junit;

import static org.junit.Assert.*;


import java.sql.SQLException;

import org.junit.After;

import org.junit.Before;

import org.junit.Test;

import com.cts.dao.LoginDAO;
import com.cts.model.LoginVO;

public class LoginDAOTest {

	LoginDAO ldao;

	LoginVO lvo;

	@Before

	public void setUp() throws Exception {

		ldao = new LoginDAO();

		lvo = new LoginVO();

	}

	@After

	public void tearDown() throws Exception {

	}

	@Test

	public void testPass() {
		
		lvo.setUname("A7539");

		lvo.setPass("Admin7539");

		assertEquals(lvo, ldao.validateLogin(lvo));

	}

	@Test
	public void testFail() {

		lvo.setUname("U8698");

		lvo.setPass("Admi8698");

		assertEquals(lvo, ldao.validateLogin(lvo));

	}

	@Test

	public void testEmptyu() {

		lvo.setUname("");

		lvo.setPass("Admin7539");

		assertEquals(lvo, ldao.validateLogin(lvo));

	}

	@Test
	public void testEmptyp() {

		lvo.setUname("A7539");

		lvo.setPass("");

		assertEquals(lvo, ldao.validateLogin(lvo));

	}

	@Test
	public void testEmpty() {

		lvo.setUname("");

		lvo.setPass("");

		assertEquals(lvo, ldao.validateLogin(lvo));

	}

}
