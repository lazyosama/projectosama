package com.cts.junit;

import static org.junit.Assert.*;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cts.dao.RandomDAO;
import com.cts.model.RandomVO;

public class UserRandomDAOTest {
	RandomVO lvo;
	RandomDAO ldao;

	@Before
		public void setUp() throws Exception {
		lvo=new RandomVO();
		ldao=new RandomDAO();
		}

		@After
		public void tearDown() throws Exception {
		}

		@Test
		public void randomPass() {
	lvo.setId("U3333");
		assertEquals(true, ldao.random(lvo));
		}

		@Test
		public void randomFail() {
	lvo.setId("U3160");
		assertEquals(false, ldao.random(lvo));
		}

		@Test
		public void randomEmpty() {
	lvo.setId(null);
		assertEquals(false, ldao.random(lvo));
		}

	}
