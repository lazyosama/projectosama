package com.cts.junit;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.After;

import org.junit.Before;

import org.junit.Test;

import com.cts.dao.UserLoginDAO;
import com.cts.model.LoginVO;
import com.cts.model.UserLoginVO;

public class UserLoginDAOTest {

        UserLoginDAO ldao;

        UserLoginVO lvo;

        @Before

        public void setUp() throws Exception {

                ldao=new UserLoginDAO();

                lvo=new UserLoginVO();

                

        }

        @After

        public void tearDown() throws Exception {

                

        }

        @Test

        public void testPass() throws SQLException {

                lvo.setUname("U3333");

                lvo.setPass("User3333");

					assertEquals(true,ldao.validateLogin(lvo));
				
        }
               @Test

        public void testFail() throws SQLException {

                lvo.setUname("A3333");

                lvo.setPass("User");

					assertEquals(false,ldao.validateLogin(lvo));
				
        }
        @Test

        public void testEmptyu() throws SQLException {

                lvo.setUname("");

                lvo.setPass("User3333");

					assertEquals(false,ldao.validateLogin(lvo));
				
        }
        @Test

        public void testEmptyp() throws SQLException {

                lvo.setUname("U3333");

                lvo.setPass("");

					assertEquals(false,ldao.validateLogin(lvo));
				
        }
        @Test

        public void testEmpty() throws SQLException {

                lvo.setUname("");

                lvo.setPass("");

					assertEquals(false,ldao.validateLogin(lvo));
				
        }
                     }

