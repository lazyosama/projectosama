package com.cts.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cts.dao.DefaulterDAO;
import com.cts.model.DefaulterVO;

public class DefaulterDAOTest {
	DefaulterDAO ldao;

	  DefaulterVO lvo;
	@Before
	public void setUp() throws Exception {
		
	      ldao=new DefaulterDAO();

	      lvo=new DefaulterVO();
	}

	@After
	public void tearDown() throws Exception {
	}
	@Test
	public void testsetDefaultPass() {
		lvo.setUid("U6890");
		lvo.setDot("2016-06-08");
		lvo.setStatus("AUTO_DEFAULT");
		lvo.setAccrstatus(Integer.parseInt("9"));
		lvo.setName("Ranji");
		lvo.setBankno("IDBI25");
		lvo.setRating(Integer.parseInt("3"));
		lvo.setDpd(Integer.parseInt("84"));
		lvo.setComment("Amount paid");
lvo.setAccno(Long.parseLong("50345020125"));
assertEquals(true, ldao.setDefault(lvo));
		
	}
	
	@Test
	public void testsetDefaultFail() {
		lvo.setUid("U6890");
		lvo.setDot("2016-04-13");
		lvo.setStatus("AUTO_WEAVER");
		lvo.setAccrstatus(Integer.parseInt("5"));
		lvo.setName("RAMYA");
		lvo.setBankno("IDBI87");
		lvo.setRating(Integer.parseInt("8"));
		lvo.setDpd(Integer.parseInt("98"));
		lvo.setComment("Amount not paid");
lvo.setAccno(Long.parseLong("50345020128"));
assertEquals(false, ldao.setDefault(lvo));
		
	}
	@Test
	public void testsetDefaultEmpty() {
		lvo.setUid("");
		lvo.setDot("");
		lvo.setStatus("");
		lvo.setAccrstatus(0);
		lvo.setName("");
		lvo.setBankno("");
		lvo.setRating(0);
		lvo.setDpd(0);
		lvo.setComment("");
lvo.setAccno(0);
assertEquals(false, ldao.setDefault(lvo));
		
	}

}
