package com.cts.junit;

import static org.junit.Assert.*;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cts.dao.InsertAutoUpdateDAO;
import com.cts.model.InsertAutoUpdateVO;

public class InsertAutoUpdateDAOTest {
	InsertAutoUpdateVO lvo;
	InsertAutoUpdateDAO ldao;
		@Before
		public void setUp() throws Exception {
			lvo=new InsertAutoUpdateVO();
			ldao=new InsertAutoUpdateDAO();
		}

		@After
		public void tearDown() throws Exception {
		}
		
		@Test
		public void insertAutoUpdatePass() {
			lvo.setUid("U9919");
			lvo.setDot("2016-02-24");
			lvo.setStatus("AUTO_WEAVER");
			lvo.setAccrstatus(Integer.parseInt("9"));
			lvo.setName("ranji");
			lvo.setBno("IDBI123");
			lvo.setRating(Integer.parseInt("4"));
			lvo.setDpd(Integer.parseInt("167"));
			lvo.setComments("Not paid");
	lvo.setAccno(Long.parseLong("5342345234"));
	assertEquals(true, ldao.insertAutoUpdate(lvo));
			
		}
		
		@Test
		public void insertAutoUpdateFail() {
			lvo.setUid("U9918");
			lvo.setDot("2016-03-23");
			lvo.setStatus("VALIDATE_ERROR");
			lvo.setAccrstatus(Integer.parseInt("1"));
			lvo.setName("ranji");
			lvo.setBno("IDBI124");
			lvo.setRating(Integer.parseInt("8"));
			lvo.setDpd(Integer.parseInt("45"));
			lvo.setComments("Dues pending");
	lvo.setAccno(Long.parseLong("123456245"));
	assertEquals(false, ldao.insertAutoUpdate(lvo));
			
		}

		@Test
		public void insertAutoUpdateEmpty() {
			lvo.setUid("");
			lvo.setDot("");
			lvo.setStatus("");
			lvo.setAccrstatus(0);
			lvo.setName("");
			lvo.setBno("");
			lvo.setRating(0);
			lvo.setDpd(0);
			lvo.setComments("");
	lvo.setAccno(0);
	assertEquals(false, ldao.insertAutoUpdate(lvo));
			
		}


	}
