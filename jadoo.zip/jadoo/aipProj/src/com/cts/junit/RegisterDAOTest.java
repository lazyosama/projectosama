package com.cts.junit;

import static org.junit.Assert.*;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cts.dao.RegisterDAO;
import com.cts.model.RegisterVo;

public class RegisterDAOTest {
	  RegisterDAO ldao;

	  RegisterVo lvo;
	@Before
	public void setUp() throws Exception {

        ldao=new RegisterDAO();

        lvo=new	RegisterVo();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testRegisterPass() {


        lvo.setLog("A4551");
        lvo.setPass("Admin4551");
        lvo.setFname("Preethi");
        lvo.setLname("Ravi");
        lvo.setGender("female");
        lvo.setCum(Long.parseLong("9034567892"));
        lvo.setAdd("Salem");
        lvo.setAge(Integer.parseInt("24"));
        lvo.setEmail("preethir@gmail.com");
        lvo.setCountry("Japan");
        lvo.setCity("Fukuoka");
        lvo.setZip(Integer.parseInt("955221"));

        assertEquals(true, ldao.validateLogin(lvo));	
	}
	@Test
	public void testRegisterFail() {


     lvo.setLog("A4551");
        lvo.setPass("Admi9394");
        lvo.setFname("Jerry");
        lvo.setLname("ranji");
        lvo.setGender("male");
        lvo.setCum(Long.parseLong("9003434321254"));
        lvo.setAdd("salem");
        lvo.setAge(Integer.parseInt("19"));
        lvo.setEmail("dhasdrew@gmail.com");
        lvo.setCountry("Japi");
        lvo.setCity("Fukuo");
        lvo.setZip(Integer.parseInt("9552432"));

        assertEquals(false, ldao.validateLogin(lvo));	
	}
	@Test
	public void testRegisterEmpty() {


        lvo.setLog("");
        lvo.setPass("");
        lvo.setFname("");
        lvo.setLname("");
        lvo.setGender("");
        lvo.setCum(0);
        lvo.setAdd("");
        lvo.setAge(0);
        lvo.setEmail("");
        lvo.setCountry("");
        lvo.setCity("");
        lvo.setZip(0);

        assertEquals(false, ldao.validateLogin(lvo));	
	}


}
