package com.cts.junit;

import static org.junit.Assert.*;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cts.dao.AdminRandomDAO;
import com.cts.model.AdminRandomVO;

public class AdminRandomDAOTest {
AdminRandomVO lvo;
AdminRandomDAO ldao;

@Before
	public void setUp() throws Exception {
	lvo=new AdminRandomVO();
	ldao=new AdminRandomDAO();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void randomPass() {
lvo.setId("A3169");
	assertEquals(true, ldao.random(lvo));
	}

	@Test
	public void randomFail() {
lvo.setId("A3160");
	assertEquals(false, ldao.random(lvo));
	}

	@Test
	public void randomEmpty() {
lvo.setId(null);
	assertEquals(false, ldao.random(lvo));
	}

}
