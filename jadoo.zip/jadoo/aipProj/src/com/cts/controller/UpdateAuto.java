package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.bo.UpdateAutoBO;
import com.cts.model.UpdateAutoVO;

public class UpdateAuto extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		String uid;
		PrintWriter out = response.getWriter();
		uid = request.getParameter("lan");
		HttpSession session = request.getSession(); 							// calling session object
		UpdateAutoVO umvo = new UpdateAutoVO();
		UpdateAutoBO umbo = new UpdateAutoBO();									 // Calling BO and VO objects
		try {
			umvo = umbo.searchAuto(uid);
		} catch (SQLException e) {
			 Logger.getLogger(UpdateAuto.class.getName()).error(e.toString());
		}
		out.println("<html><head><title>Update Auto Defaulters</title>");
		out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
		out.println("<link rel='stylesheet' href='css/ind1.css' type='text/css' media='all'>");
		out.println("<link rel='stylesheet' href='css/form1.css' type='text/css' media='all'>");
		out.println("<link rel='stylesheet' href='css/footer.css' type='text/css' media='all'>");
		out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js'></script>");
		out.println("<script src='http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js'></script>");
		out.println("<script src='http://ajax.microsoft.com/ajax/jquery.validate/1.7/additional-methods.js'></script>");
		out.println("<script src='JQuery/edit.js'></script>");
		out.println("<link rel='stylesheet' href='css/mark.css' type='text/css' media='all'>");
		out.println("<script type = 'text/javascript'>");
		out.println("function preventBack() { window.history.forward(0); }");
		out.println("setTimeout('preventBack()', 0);");							//Function to Prevent going back
		out.println("window.onunload = function () { null };");
		out.println("</script>");
		out.println("<script>");
		out.println("function myFunction() {");									//Function to display Name and Logout
		out.println("document.getElementById('myDropdown1').classList.toggle('show');");
		out.println("}window.onclick = function(event) {");
		out.println("if (!event.target.matches('.dropbtn1')) {");
		out.println("var dropdowns = document.getElementsByClassName('dropdown-content1');var i;");
		out.println("for (i = 0; i < dropdowns.length; i++) {");
		out.println("var openDropdown = dropdowns[i];");
		out.println("if (openDropdown.classList.contains('show')) {");
		out.println("openDropdown.classList.remove('show');");
		out.println("}} }}</script>");
		out.println("</head><body><header><div id='main'><ul id='menu'>");
		/*out.println("<ul id='menu'><li><a href='indexa.jsp'>HOME&nbsp;&nbsp;&nbsp;&nbsp;</a></li><li><a href='Alogin.html'>&nbsp;&nbsp;ADMIN&nbsp;&nbsp;&nbsp;&nbsp;</a></li>");
		out.println("<li><a href='Ulogin.html'>&nbsp;&nbsp;USER&nbsp;&nbsp;&nbsp;</a></li><li><a href='AboutUs.html''>&nbsp;&nbsp;ABOUT US&nbsp;&nbsp;&nbsp;</a></li>");
		out.println("<li><a href='ContactUs.jsp'>&nbsp;&nbsp;CONTACT US&nbsp;&nbsp;&nbsp;</a></li></ul>");*/
		out.println("</div><BR> </header>");
		out.println("<div class='dropdown1'>");
		out.println("<button onmouseover='myFunction()' class='dropbtn1'>");
		out.println("Welcome  " + session.getAttribute("name"));					//Using Session to get Name
		out.println("</button>");
		out.println("<div id='myDropdown1' class='dropdown-content1'>");
		out.println("<a href='logout'>Log Out</a> </div> </div>");
		out.println("<img src='images/left.png' width='60px' height='60px' id='imb1'><a href='DisplayAuto'><div class='R2'><h4>BACK</h4></div></a>");
		out.println("<div class='admin'><center>");
		out.println("<table><tr><td> <img src='images/userr.png' width='50px' height='50px'></td>");
		out.println("<td><h1 style='color:#FFFFFF'>Update Auto Defaulters</h1></td></tr></table><center></div>");
		out.println("<div id='secnd'></br>");
		out.println("<center><form action='InsertAutoUpdate' id='defForm' method='get'>");	//Printing details
		out.println("<table style='color:white;' class='tble1' cellspacing='10'>");
		out.println("<tr><td>User ID</td><td><input type='text' name='uid' readonly='readonly' value=" + umvo.getUid()+ "></td></tr>");
		out.println("<tr><td>Name</td><td><input type='text' name='name' readonly='readonly' value=" + umvo.getName()+ "></td></tr>");
		out.println("<tr><td>Borrower Rating</td><td><input type='text' name='rating' readonly='readonly' value="+ umvo.getRating() + "></td></tr>");
		out.println("<tr><td>Accural Status</td><td><input type='text' name='accrstatus' readonly='readonly' value="+ umvo.getAccrstatus() + "></td></tr>");
		out.println("<tr><td>Status   *</td><td><select name='status' id='status'><option value=''>-Select Status-</option>");
		out.println("<option value='AUTO_DEFAULT'>AUTO_DEFAULT</option>");
		out.println("<option value='AUTO_WEAVER'>AUTO_WEAVER</option><option value='VALIDATE_ERROR'>VALIDATE_ERROR</option><option value='RE_DEFAULT'>RE_DEFAULT</option></select></td>");
		out.println("<tr><td>Bank Number</td><td><input type='text' name='bno' readonly='readonly' value="+ umvo.getBno() + "></td></tr>");
		out.println("<tr><td>Account Number</td><td><input type='text' name='accno' readonly='readonly' value="+ umvo.getAccno() + "></td></tr>");
		out.println("<tr><td>Days Past Due</td><td><input type='text' name='dpd' readonly='readonly' value="+ umvo.getDpd() + "><br></td></tr>");
		out.println("<tr><td>Comments   *</td><td><textarea rows='2' cols='21' name='comments' value="+ umvo.getComments() + "></textarea></td></tr>");
		out.println("<tr><td>Last Transaction Date  *</td><td><input type='date' id='dot1' name='dot'></td></tr>");
		out.println("</table>");
		out.println("<input type='submit' value='Complete' id='subm' >");
		out.println("</form><center></div>");
		 out.println("<div class='footer7'>");
		 out.println("<div class='ft-bottom2'>");
	     out.println("<p id='foot2'>&copy; 2016 AIP. All Rights Reserved. </p>");
	   	 out.println("</div> </div></body></html>");

	}

}
