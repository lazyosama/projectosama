package com.cts.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class Demo extends HttpServlet {
	private static final long serialVersionUID = 1L;
          
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	Document pdf = null;											//Creating object of Document
	pdf = new Document();
	String uname=request.getParameter("uname");
	String name=request.getParameter("name");
	String fileName="Aip.pdf";											//Setting File Name				
	ArrayList<String> alist=new ArrayList<String>();
	try {
		PdfWriter printw = PdfWriter.getInstance((com.itextpdf.text.Document) pdf, new FileOutputStream(fileName));
	} catch (DocumentException e1) {
		 Logger.getLogger(Demo.class.getName()).error(e1.toString());
	}
	pdf.open();															//Opening Pdf and Writing Details
	Paragraph preface = new Paragraph("User Transaction",
			FontFactory.getFont(FontFactory.TIMES_BOLD, 18, Font.BOLD, BaseColor.BLUE));
	preface.setAlignment(Element.ALIGN_CENTER);
	try {
	pdf.add(preface);
	
	pdf.add(new Paragraph(
			"Generated on:" + new SimpleDateFormat("dd-MMM-yyy hh:MM a").format(new Date()).toString()));    //Addoing Date to pdf
	pdf.add(new Paragraph(
			"---------------------------------------------------------------------------------------------------------------------------"));
	pdf.add(Chunk.NEWLINE);
	pdf.add(new Paragraph("Customer Name:"+name));
	pdf.add(Chunk.NEWLINE);
	} catch (DocumentException e1) {
		 Logger.getLogger(Demo.class.getName()).error(e1.toString());
	}

	com.itextpdf.text.pdf.PdfPTable table = new PdfPTable(6);
	Connection con=null;
	PreparedStatement stmt=null;
	ResultSet rs=null;																//Creating Connection And Result set for getting Details from Database
	try {	
		Class.forName("com.mysql.jdbc.Driver");  									//Setting MySql driver
		con = DriverManager.getConnection("jdbc:mysql://localhost/auto","root","root");
		stmt=con.prepareStatement("select t.User_ID,t.DOT,t.Ammount,t.To_Acc,t.From_Acc,t.From_Bank from transaction_details t join User u on t.User_ID=u.User_ID where t.DOT>DATE_SUB(now(),INTERVAL 3 MONTH) and u.User_ID=? order by t.DOT;");  
		stmt.setString(1, uname);
 		rs=stmt.executeQuery();
 		int i=1,count=0;
		while(rs.next()) 																//Writing Transactions of User
		{	
			
			if(count==0){
				PdfPCell cell1 = new PdfPCell(new Phrase("User_Id"));
				cell1.setBackgroundColor(BaseColor.GRAY);
				PdfPCell cell2 = new PdfPCell(new Phrase("DOT"));
				cell2.setBackgroundColor(BaseColor.GRAY);
				PdfPCell cell3 = new PdfPCell(new Phrase("Ammount"));
				cell3.setBackgroundColor(BaseColor.GRAY);
				PdfPCell cell4 = new PdfPCell(new Phrase("To_acc"));
				cell4.setBackgroundColor(BaseColor.GRAY);
				PdfPCell cell5 = new PdfPCell(new Phrase("From_Acc"));
				cell5.setBackgroundColor(BaseColor.GRAY);
				PdfPCell cell6 = new PdfPCell(new Phrase("From_Bank"));
				cell6.setBackgroundColor(BaseColor.GRAY);
				table.addCell(cell1);
				table.addCell(cell2);
				table.addCell(cell3);
				table.addCell(cell4);
				table.addCell(cell5);
				table.addCell(cell6);
				count=1;
			}
			alist.add(rs.getString("User_ID"));
			alist.add(rs.getString("DOT"));
			alist.add(rs.getString("Ammount"));
		    alist.add(rs.getString("To_Acc"));
		    alist.add(rs.getString("From_Acc"));
			alist.add(rs.getString("From_Bank"));
			i++;
		}
		int row=alist.size()/6;										//Adjusting Cells
		int j=0;
		for(j=0;j<row*6;j++){
			table.addCell(alist.get(j));
		}
		if(i==1)
		{															//If No relevant data
			pdf.add(Chunk.NEWLINE);
			pdf.add(new Paragraph("No Transactions Details"));
		}
		} catch (ClassNotFoundException e) {
			 Logger.getLogger(Demo.class.getName()).error(e.toString());
		}
	catch (SQLException e) {
			 Logger.getLogger(Demo.class.getName()).error(e.toString());
	}
		
		catch (DocumentException e) {
		 Logger.getLogger(Demo.class.getName()).error(e.toString());
	}  
	try {
		pdf.add(table);
		pdf.close();
		String contextPath ="D://303,304,305,306/CopyPaste soft/SDE_7.0_Express/eclipse/";		//Setting Path for Downloading
		File pdfFile = new File(contextPath +fileName);							//Giving File Display name and attributes
		response.setContentType("application/pdf");
		response.addHeader("Content-Disposition", "attachment; fileName=" + fileName);
		response.setContentLength((int) pdfFile.length());

		@SuppressWarnings("resource")
		FileInputStream fileInputStream = new FileInputStream(pdfFile);
		OutputStream responseOutputStream = response.getOutputStream();
		int bytes;
		while ((bytes = fileInputStream.read()) != -1) {
			responseOutputStream.write(bytes);
		}}
		catch (DocumentException e) {
			 Logger.getLogger(Demo.class.getName()).error(e.toString());
		}
	}

}
