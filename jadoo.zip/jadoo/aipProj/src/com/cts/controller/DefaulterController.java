package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.bo.DefaulterBO;
import com.cts.model.DefaulterVO;
/*
 * 
 */
public class DefaulterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DefaulterVO defvo=new DefaulterVO();											//creating VO object
		defvo.setUid(request.getParameter("uid"));									//Setting user defaulter details in VO object
		defvo.setName(request.getParameter("name"));
		int rate=Integer.parseInt(request.getParameter("rating"));
		int accrstat=Integer.parseInt(request.getParameter("accrstatus"));
		defvo.setRating(rate);
		defvo.setAccrstatus(accrstat);
		defvo.setBankno(request.getParameter("bankno"));
		defvo.setAccno(Long.parseLong(request.getParameter("accno")));
		defvo.setComment(request.getParameter("comment"));
		int dpd=Integer.parseInt(request.getParameter("dpd"));
		defvo.setDpd(dpd);
		String dot=request.getParameter("dot");
		defvo.setDot(dot);
		String status=null;															//Checking Defaulter Conditions
		if(rate>=8||accrstat==2||accrstat==3||accrstat==4||accrstat==5)
		{
			status="AUTO";
		}
		if(((rate>=5&&rate<8)||(accrstat==1||accrstat==6||accrstat==7))&& dpd>=90)
		{
			status="NULL";
		}
		defvo.setStatus(status);
		DefaulterBO defdbo=new DefaulterBO();												//creating BO object and Calling Function to update Database											
		boolean result=defdbo.setDefault(defvo);
		PrintWriter out=response.getWriter();
		out.println("<html><head><title>Defaulter Controller</title>");
		out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
		out.println("<link rel='stylesheet' href='css/ind1.css' type='text/css' media='all'>");
		out.println("</head><body><div class='admin'><center>");
		if(result==true){																//Printing Successful Message
			out.println("</br><center><h2 id='va1' style='color:#FFFFFF'>You have Successfully Entered the Data</h2>");
      	  	out.println("<a href='status.jsp'><input type='button' id='v2'name='but' value='Make Another Entry'></a>");
      	  	out.println("<a href='admin.jsp'><input type='button' id='v3'name='but' value='Back to Admin'></a>");
		}
		else																			//Printing Failure Message				
		{
			out.println("</br><center><h2 style='color:white'>Invalid Data Entered..</h2>");
			out.println("<h4 id='cl1'><u><a id='cl1' href='Status.jsp'>Click here </u></a>to Enter again..</h4></center>");
		}
		out.println("</div></body></html>");
	}

}
