package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.bo.AdminRandomBO;
import com.cts.bo.UserRegisterBo;
import com.cts.model.AdminRandomVO;
import com.cts.model.UserRegisterVo;

public class UserValidateRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,NumberFormatException {
		
		AdminRandomBO   adminBO = new AdminRandomBO();
		
	String strNumber=	adminBO.generateRandomNumber(1000,9999);
		
	strNumber="U"+strNumber;
	String param=request.getParameter("param");
	RequestDispatcher    reqDisp = request.getRequestDispatcher("UserForm.jsp");
	
	request.setAttribute("strNumber", strNumber);
	request.setAttribute("param",param);
	reqDisp.forward(request, response);
		
		
	}
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,NumberFormatException {
		UserRegisterVo login=new UserRegisterVo();							//Calling VO object
		login.setLog(request.getParameter("log"));							//setting values in Vo object
		login.setPass(request.getParameter("pass"));
		login.setFname(request.getParameter("fname"));
		login.setLname(request.getParameter("lname"));
		login.setGender(request.getParameter("gender"));
		login.setCum(Long.parseLong(request.getParameter("cum")));
		login.setAdd(request.getParameter("add"));
		login.setAge(Integer.parseInt(request.getParameter("age")));
		login.setEmail(request.getParameter("email"));
		login.setCountry(request.getParameter("country"));
		login.setCity(request.getParameter("city"));
		login.setZip(Integer.parseInt(request.getParameter("zip")));
		UserRegisterBo lbo=new UserRegisterBo();
		boolean result=lbo.validateLogin(login);
		String msg=" ";
		PrintWriter pw=response.getWriter();
		if(result==true)
		{
			request.setAttribute("login", login.getLog());							//Setting Login Id and name as attributes
			request.setAttribute("name", login.getFname());
			if(result==true)
			{
				pw.println("<html><head><title>Validate Register</title></head><body>");
			       pw.println("<link rel='stylesheet' href='css/ind1.css' type='text/css' media='all'>");
			       pw.println("</head><body>");
			       msg="Successfully Record has been inserted "+login.getLog();				//printing Success Message
			       pw.println("<center><h1 id='v1' style='color:white'>");
			       pw.println(msg);
			       pw.println("</h1></center>");
			       pw.println("<a href='UserValidateRegister'><input type='button' id='v2'name='but' value='Another Registration'></a>");
			       pw.println("<a href='Ulogin.html'><input type='button' id='v3'name='but' value='Login'></a>");
			       pw.println("</body></html>");
			}  
			else{  																		//if Email already exists
			     	pw.println("<html><head></head><body>");
					pw.println("<link rel='stylesheet' href='css/ind1.css' type='text/css' media='all'>");
					pw.println("</head><body>");
					msg="Email is already exists";
					pw.println("<center><h1 id='t1' style='color:white'>");
					pw.println(msg);													//displaying message
					pw.println("</h1></center>");
					pw.println("<a href='UserForm.jsp'><input type='button' id='t2'name='but' value='ReTry!!!'></a>");
					pw.println("</body></html>");

			    }  
       }  
			
	}
}
		
