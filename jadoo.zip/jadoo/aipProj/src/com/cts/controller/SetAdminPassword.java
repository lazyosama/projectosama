package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cts.model.SetPass;
import com.cts.util.PasswordRecovery;

public class SetAdminPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
           
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String p1=request.getParameter("pass1");						//Getting the passwords values 
		String p2=request.getParameter("pass2"); 
		String uid=request.getParameter("uid");
		PrintWriter out=response.getWriter();
		out.println("<html><head><title>Set Password</title>");
		out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
		out.println("<link rel='stylesheet' href='css/ind1.css' type='text/css' media='all'>");
		out.println("<link rel='stylesheet' href='css/footer.css' type='text/css' media='all'>");
		out.println("</head><body><header><div id='main'><ul id='menu'>");
		out.println(" <ul id='menu'><li><a href='indexa.jsp'>HOME&nbsp;&nbsp;&nbsp;&nbsp;</a></li><li><a href='Alogin.html'>&nbsp;&nbsp;ADMIN&nbsp;&nbsp;&nbsp;&nbsp;</a></li>");
        out.println("<li><a href='Ulogin.html'>&nbsp;&nbsp;USER&nbsp;&nbsp;&nbsp;</a></li><li><a href='AboutUs.html''>&nbsp;&nbsp;ABOUT US&nbsp;&nbsp;&nbsp;</a></li>");
        out.println("<li><a href='ContactUs.jsp'>&nbsp;&nbsp;CONTACT US&nbsp;&nbsp;&nbsp;</a></li></ul>");
		out.println("</div><BR> </header><div class='admin'><center>");
        out.println("<table><tr><td> <img src='images/s6.png' width='50px' height='50px'></td>");
		if(p1.equals(p2))
		{
			SetPass sp=new SetPass();														//calling object setpass and settig values
			sp.setPass(p1);
			sp.setUid(uid);
			boolean result=false;
			int flag=0;
			PasswordRecovery pr=new PasswordRecovery();
			if(uid.charAt(0)=='A'){															//Checking for Admin and User Ids
				flag=1;
			try {
				 result=pr.adminPassRecovery(sp);											//calling function to recover password 
			} catch (SQLException e) {
				 Logger.getLogger(SetAdminPassword.class.getName()).error(e.toString());
			}
			}
			else
			{
				try {
					 result=pr.userPassRecovery(sp);
				} catch (SQLException e) {
					 Logger.getLogger(SetAdminPassword.class.getName()).error(e.toString());
				}
			}
			
			if(result==true && flag==1)									//if result is true and ID is of Admin, direct it to Admin login
			{
				out.println("<center><h4 style='color:#FFFFFF'>Password Successfully Changed....</center>");
				out.println("<center><a href='Alogin.html'><h4 style='color:#FFFFFF'><u>Click here</u></h4> </a><h4 style='color:#FFFFFF'>to login again..</h4></center>");
				out.println("  <div class='footer2'>");
				out.println(" <div class='ft-bottom2'>");
			    out.println("<p id='foot2'>&copy; 2016 AIP. All Rights Reserved. </p>");
			    out.println("</div> </div>");
			}
			else if(result==true && flag==0)							//if result is true and ID is of User, direct it to User login
			{
				out.println("<center><h4 style='color:#FFFFFF'>Password Successfully Changed....</center>");
				out.println("<center><a href='Ulogin.html'><h4 style='color:#FFFFFF'><u>Click here</u></h4> </a><h4 style='color:#FFFFFF'>to login again..</h4></center>");
				out.println("<div class='footer2'>");
				out.println("<div class='ft-bottom2'>");
			    out.println("<p id='foot2'>&copy; 2016 AIP. All Rights Reserved. </p>");
			    out.println("</div> </div>");
			}
			else
			{
				out.println("<center><h4 style='color:#FFFFFF'>Sorry Password Cannot be updated....</center>");				
				out.println("<center><a href='AdminPassRecovery.html'><h4 style='color:#FFFFFF'>Click here</a>to try again..</h4></center>");
				out.println("<div class='footer2'>");
				out.println("<div class='ft-bottom2'>");
			    out.println("<p id='foot2'>&copy; 2016 AIP. All Rights Reserved. </p>");
			    out.println("</div> </div>");
			}
			
		}
		else
		{
			 	out.println("<center><h4 style='color:red'>Sorry your Passwords doesnot match....</center>");
			 	out.println("<center><a href='AdminPassRecovery.html'>Click here</a>to retry..</center>");
			 	out.println("<div class='footer2'>");
			 	out.println("<div class='ft-bottom2'>");
		      	out.println("<p id='foot2'>&copy; 2016 AIP. All Rights Reserved. </p>");
		      	out.println("</div> </div>");
		}
		
	}

}
