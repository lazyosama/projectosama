package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.bo.DisplayManualBO;
import com.cts.model.DisplayManualVO;

public class DisplayManual extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();									//Calling session object
		DisplayManualVO defmvo=new DisplayManualVO();									//creating VO and BO objects
		DisplayManualBO defmbo=new DisplayManualBO();
		ArrayList<DisplayManualVO> list1=new ArrayList<DisplayManualVO>();
		int flag=0;
		try {
			list1=defmbo.displayManual();												//Calling Method to display Auto Redefaults in DAO
			Iterator<DisplayManualVO> eiter= list1.iterator();
			out.println("<html><head><title>Manual Defaulters</title>");
			out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
			out.println("<link rel='stylesheet' href='css/ind1.css' type='text/css' media='all'>");
			out.println("<link rel='stylesheet' href='css/footer.css' type='text/css' media='all'>");
			out.println("<script type = 'text/javascript'>");
			out.println("function preventBack() { window.history.forward(0); }");
			out.println("setTimeout('preventBack()', 0);");										//Function to Prevent going back
			out.println("window.onunload = function () { null };");
			out.println("</script>");
			out.println("<link rel='stylesheet' href='css/mark.css' type='text/css' media='all'>");
			out.println("<script type = 'text/javascript'>");
			out.println("function preventBack() { window.history.forward(0); }");
			out.println("setTimeout('preventBack()', 0);");
			out.println("window.onunload = function () { null };");
			out.println("</script>");
			out.println("<script>");
			out.println("function myFunction() {");												//Function to display Name and Logout
			out.println("document.getElementById('myDropdown1').classList.toggle('show');");
			out.println("}window.onclick = function(event) {");
			out.println("if (!event.target.matches('.dropbtn1')) {");
		    out.println("var dropdowns = document.getElementsByClassName('dropdown-content1');var i;");
			out.println("for (i = 0; i < dropdowns.length; i++) {");
			out.println("var openDropdown = dropdowns[i];");
			out.println("if (openDropdown.classList.contains('show')) {");
			out.println("openDropdown.classList.remove('show');");
			out.println("}} }}</script>");
			out.println("</head><body><header><div id='main'><ul id='menu'>");
			/*out.println("<ul id='menu'><li><a href='indexa.jsp'>HOME&nbsp;&nbsp;&nbsp;&nbsp;</a></li><li><a href='Alogin.html'>&nbsp;&nbsp;ADMIN&nbsp;&nbsp;&nbsp;&nbsp;</a></li>");
	        out.println("<li><a href='Ulogin.html'>&nbsp;&nbsp;USER&nbsp;&nbsp;&nbsp;</a></li><li><a href='AboutUs.html'>&nbsp;&nbsp;ABOUT US&nbsp;&nbsp;&nbsp;</a></li>");
	        out.println("<li><a href='ContactUs.jsp'>&nbsp;&nbsp;CONTACT US&nbsp;&nbsp;&nbsp;</a></li></ul>");*/
			out.println("</div><BR> </header>");
			out.println("<div class='dropdown1'>");
			out.println("<button onmouseover='myFunction()' class='dropbtn1'>");
			out.println("Welcome  "+session.getAttribute("name"));										//Using Session to get Name
			out.println("</button>");
			out.println("<div id='myDropdown1' class='dropdown-content1'>");
			out.println("<a href='logout.jsp'>Log Out</a> </div> </div>");
		    out.println("<a href='admin.jsp'><img src='images/left.png' width='60px' height='60px' id='imb'></a><div class='R1'><h4>BACK</h4></div>");
			out.println("<div class='admin'><center>");
	        out.println("<table><tr><td> <img src='images/s6.png' width='50px' height='50px'></td>");
	        out.println("<td><h1 style='color:#FFFFFF'>Manual Defaulters</h1></td></tr></table><center></div>");
	        out.println("<div id='second2'>");
	        out.println("<div class='c5'><img src='images/s4.png' width='40px' height='40px'></div>");
	        out.println("<form action='ManualRedefault' method='get'><input type='submit' value='REDEFAULTS' id='de'></form>");	
			int f=1;
	        while(eiter.hasNext()){
			defmvo=eiter.next();
			flag=1;
			if(f==1){ 
				out.println("</br><center><h3 style='color:#FFFFFF'>The following are the Manual Defaulters.. </h3>");
				out.println("<br><div style='height: 235px; width: 900px; text-align:center; overflow-y:auto;'><table border='1' id='upd'><tr><th>UserID</th><th>Name</th>");
				out.println("<th>Status</th>");
				out.println("<th>Borrower Rating</th><th>Accrual Status</th>");
		        out.println("<th>Bank No</th><th>Account Number</th>");
		        out.println("<th>Days Past Due</th><th>Comments</th>");
		        out.println("<th>Last Transaction Date</th><th>Edit/Update</th></tr>");
			}    																		//Printing Data
			out.println("<tr><td>"+defmvo.getUid()+"</td>");
			out.println("<td align='center'>"+defmvo.getName()+"</td>");
			out.println("<td align='center'>"+defmvo.getStatus()+"</td>");
			out.println("<td align='center'>"+defmvo.getRating()+"</td>");
			out.println("<td align='center'>"+defmvo.getAccrstatus()+"</td>");
			out.println("<td align='center'>"+defmvo.getBno()+"</td>");
			out.println("<td align='center'>"+defmvo.getAccno()+"</td>");
			out.println("<td align='center'>"+defmvo.getDpd()+"</td>");
			out.println("<td align='center'>"+defmvo.getComments()+"</td>");
			out.println("<td align='center'>"+defmvo.getDot()+"</td>");
			out.println("<td align='center'><form action='UpdateManual' method='get'><input type='submit' id='upd' value='Update' name="+defmvo.getUid()+" ><input type='hidden' name='lan' value="+defmvo.getUid()+"></form></td></tr>");
			
			f=0;
			
			}
	        out.println("</table></div></form>");
	        out.println("<div class='footer2'>");
	        out.println("<div class='ft-bottom2'>");
	        out.println("<p id='foot2'>&copy; 2016 AIP. All Rights Reserved. </p>");
	        out.println("</div></div></body></html>");
		} catch (SQLException e) {
			 Logger.getLogger(DisplayManual.class.getName()).error(e.toString());
		}

		if(flag==0){
			 out.println("<center><h4 style='color:#FFFFFF'>Search Found No Relevant Results</center>");
		     out.println("<div class='footer2'>");
			 out.println("<div class='ft-bottom2'>");
		     out.println("<p id='foot2'>&copy; 2016 AIP. All Rights Reserved. </p>");
		     out.println("</div> </div>");
			
		 }
	
	}

}
