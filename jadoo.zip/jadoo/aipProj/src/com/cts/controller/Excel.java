package com.cts.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

public class Excel extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uname = request.getParameter("uname"); // Setting User Id and
														// Name
		String name = request.getParameter("name");
		String excelFileName = "AipSheet12.xls"; // name of excel file
		String now = new Date().toString();
		String sheetName = "Sheet1"; // name of sheet

		HSSFWorkbook wb = new HSSFWorkbook(); // Creating workBook
		HSSFSheet sheet = wb.createSheet(sheetName);
		HSSFCellStyle style = wb.createCellStyle();
		style.setFillBackgroundColor(HSSFColor.GREY_25_PERCENT.index);
		
		HSSFCellStyle style1 = wb.createCellStyle();
		style1.setFillBackgroundColor(HSSFColor.GREY_25_PERCENT.index);
		HSSFFont font = wb.createFont();
		font.setFontName(HSSFFont.FONT_ARIAL);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		font.setColor(HSSFColor.BLUE.index);
		style.setFont(font);
		HSSFFont font1 = wb.createFont();
		font1.setFontName(HSSFFont.FONT_ARIAL);
		font1.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		font1.setColor(HSSFColor.RED.index);
		style1.setFont(font1);
		HSSFRow rowhead1 = sheet.createRow(0);
		
		HSSFCell c = rowhead1.createCell(0);
		c.setCellValue("Customer Name"); // Writing Customer name and Details

		c.setCellStyle(style1);
		c = rowhead1.createCell(1);
		c.setCellValue(name);
		c.setCellStyle(style1);

		c = rowhead1.createCell(2);
		c.setCellValue(now);
		c.setCellStyle(style1);
		HSSFRow row1 = sheet.createRow(1);
		row1.createCell(0).setCellValue("");
		int a = 2;
		HSSFRow rowhead = sheet.createRow(a);
		HSSFCell cell = rowhead.createCell(0);

		cell.setCellValue("User_Id");
		cell.setCellStyle(style);
		cell = rowhead.createCell(1);

		cell.setCellValue("DOT");
		cell.setCellStyle(style);
		cell = rowhead.createCell(2);

		cell.setCellValue("Ammount");
		cell.setCellStyle(style);
		cell = rowhead.createCell(3);

		cell.setCellValue("To_Acc");
		cell.setCellStyle(style);
		cell = rowhead.createCell(4);
		cell.setCellValue("From_Acc");
		cell.setCellStyle(style);
		cell = rowhead.createCell(5);

		cell.setCellValue("From_Bank");
		cell.setCellStyle(style);

		HSSFRow row2 = sheet.createRow(3);
		row2.createCell(0).setCellValue("");
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			Class.forName("com.mysql.jdbc.Driver"); // Setting Connection with
													// MySql Database
			con = DriverManager.getConnection("jdbc:mysql://localhost/auto", "root", "root");
			stmt = con.prepareStatement(
					"select t.User_ID,t.DOT,t.Ammount,t.To_Acc,t.From_Acc,t.From_Bank from transaction_details t join User u on t.User_ID=u.User_ID where t.DOT>DATE_SUB(now(),INTERVAL 3 MONTH) and u.User_ID=? order by t.DOT;");
			stmt.setString(1, uname);
			rs = stmt.executeQuery();
			int i = 4;
			while (rs.next()) {
				HSSFRow row = sheet.createRow(i); // Writing Values in File
				row.createCell(0).setCellValue(rs.getString("User_ID"));
				row.createCell(1).setCellValue(rs.getString("DOT"));
				row.createCell(2).setCellValue(rs.getInt("Ammount"));
				row.createCell(3).setCellValue(rs.getLong("To_Acc"));
				row.createCell(4).setCellValue(rs.getLong("From_Acc"));
				row.createCell(5).setCellValue(rs.getString("From_Bank"));
				i++;
			}
		} catch (ClassNotFoundException  e1) {
			Logger.getLogger(Excel.class.getName()).error(e1.toString());
		}
		catch (SQLException e1) {
			Logger.getLogger(Excel.class.getName()).error(e1.toString());
		}
		for (int j = 0; j < 6; j++) // Adjusting Cells
		{
			sheet.autoSizeColumn(j);
		}
		try {
			FileOutputStream fileOut = new FileOutputStream(excelFileName);
			wb.write(fileOut);
			fileOut.flush();
			fileOut.close();
			String contextPath = "D://303,304,305,306/CopyPaste soft/SDE_7.0_Express/eclipse"; // Setting
																					// Path
																					// For
																					// Download
			File xlFile = new File(contextPath + excelFileName);
			response.setContentType("application/vnd.ms-excel"); // Setting File
																	// Attributes
			response.addHeader("Content-Disposition", "attachment; filename=" + excelFileName);

			@SuppressWarnings("resource")
			FileInputStream fileInputStream = new FileInputStream(xlFile);
			OutputStream responseOutputStream = response.getOutputStream();
			int bytes;
			while ((bytes = fileInputStream.read()) != -1) {
				responseOutputStream.write(bytes);
			}
		} catch (IOException e) {
			Logger.getLogger(Excel.class.getName()).error(e.toString());
		}
	}

}
