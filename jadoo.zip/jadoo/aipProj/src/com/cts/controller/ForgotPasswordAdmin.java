package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.bo.RegisterBo;
import com.cts.bo.UserRegisterBo;

public class ForgotPasswordAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String email=request.getParameter("email");								//Getting email Id and user ID 
		String uid=request.getParameter("uid");
		String email1=null;
		
		
		RegisterBo rbo=new RegisterBo();										//creating BO object
		if(uid.charAt(0)=='A'){													//Checking For  Admin User_ID
		 email1=rbo.searchAdminEmail(uid);
		}
		
		
		UserRegisterBo urbo=new UserRegisterBo();								//Checking For  User User_ID
		if(uid.charAt(0)=='U')
		{
		 email1=urbo.searchUserEmail(uid);
		}
		out.println("<html><head><title>Forgot Password</title>");
		out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
		out.println("<link rel='stylesheet' href='css/ind1.css' type='text/css' media='all'>");
		out.println("<link rel='stylesheet' href='css/footer.css' type='text/css' media='all'>");
		out.println("</head><body><header><div id='main'><ul id='menu'>");
		out.println(" <ul id='menu'><li><a href='indexa.jsp'>HOME&nbsp;&nbsp;&nbsp;&nbsp;</a></li><li><a href='Alogin.html'>&nbsp;&nbsp;ADMIN&nbsp;&nbsp;&nbsp;&nbsp;</a></li>");
        out.println("<li><a href='Ulogin.html'>&nbsp;&nbsp;USER&nbsp;&nbsp;&nbsp;</a></li><li><a href='AboutUs.html'>&nbsp;&nbsp;ABOUT US&nbsp;&nbsp;&nbsp;</a></li>");
        out.println("<li><a href='ContactUs.jsp'>&nbsp;&nbsp;CONTACT US&nbsp;&nbsp;&nbsp;</a></li></ul>");
		out.println("</div><BR> </header><div class='admin'><center>");
        out.println("<table><tr><td> <img src='images/s6.png' width='50px' height='50px'></td>");
        out.println("<td><h1 style='color:#FFFFFF'>Recover Password</h1></td></tr></table><center></div>");
        out.println("<div id='second'>");
        if(email.equals(email1))
		{
			RequestDispatcher rd=request.getRequestDispatcher("NewPassword.jsp");			//Directing to NewPassword.jsp Page
			rd.forward(request, response);
			
		}
        else
        {    	
			 out.println("<center><h4 style='color:red'>Sorry your e-mail id is not registered..</center>");
			 out.println("<center><a href='AdminPassRecovery.html'>Click here</a>to retry..</center>");
			 out.println("<div class='footer2'>");
			 out.println("<div class='ft-bottom2'>");
		     out.println("<p id='foot2'>&copy; 2016 AIP. All Rights Reserved. </p>");
		   	 out.println("</div> </div></body></html>");        	
        }
		out.println("</div></body></html>");
	}

}
