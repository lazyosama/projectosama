package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.bo.InsertManualUpdateBO;
import com.cts.model.InsertManualUpdateVO;

public class InsertManualUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String uid=request.getParameter("uid");											//Getting Details From Form
		String name=request.getParameter("name");
		int rating=Integer.parseInt(request.getParameter("rating"));
		int accrstatus=Integer.parseInt(request.getParameter("accrstatus"));
		String status=request.getParameter("status");
		String bno=request.getParameter("bno");
		long accno=Long.parseLong(request.getParameter("accno"));
		int dpd=Integer.parseInt(request.getParameter("dpd"));
		String comments=request.getParameter("comments");
		String dot=request.getParameter("dot");
		InsertManualUpdateVO imuvo=new InsertManualUpdateVO();							//Calling Vo Object and setting values
		imuvo.setUid(uid);
		imuvo.setName(name);
		imuvo.setRating(rating);
		imuvo.setAccrstatus(accrstatus);
		imuvo.setStatus(status);
		imuvo.setAccno(accno);
		imuvo.setBno(bno);
		imuvo.setDpd(dpd);
		imuvo.setComments(comments);
		imuvo.setDot(dot);
		InsertManualUpdateBO imubo=new InsertManualUpdateBO();									//Calling BO and session object
		boolean i = imubo.insertManualUpdate(imuvo);
		HttpSession session=request.getSession();

		if(i==true)
		{
			out.println("<html><head><title>Update Details</title>");
			out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
			out.println("<link rel='stylesheet' href='css/ind1.css' type='text/css' media='all'>");
			out.println("<link rel='stylesheet' href='css/form1.css' type='text/css' media='all'>");
			out.println("<link rel='stylesheet' href='css/footer.css' type='text/css' media='all'>");

			out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js'></script>");
			out.println("<script src='http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js'></script>");
			out.println("<script src='http://ajax.microsoft.com/ajax/jquery.validate/1.7/additional-methods.js'></script>");
			out.println("<script src='JQuery/edit.js'></script>");
			out.println("<link rel='stylesheet' href='css/mark.css' type='text/css' media='all'>");
			out.println("<script type = 'text/javascript'>");							//Method To prevent Back Transition
			out.println("function preventBack() { window.history.forward(0); }");
			out.println("setTimeout('preventBack()', 0);");
			out.println("window.onunload = function () { null };");
			out.println("</script>");
			out.println("<script>");
			out.println("function myFunction() {");
			out.println("document.getElementById('myDropdown1').classList.toggle('show');");
			out.println("}window.onclick = function(event) {");								//Method to display name and Logout
			out.println("if (!event.target.matches('.dropbtn1')) {");
			out.println("var dropdowns = document.getElementsByClassName('dropdown-content1');var i;");
			out.println("for (i = 0; i < dropdowns.length; i++) {");
			out.println("var openDropdown = dropdowns[i];");
			out.println("if (openDropdown.classList.contains('show')) {");
			out.println("openDropdown.classList.remove('show');");
			out.println("}} }}</script>");
			out.println("</head><body><header><div id='main'><ul id='menu'>");
			out.println("<ul id='menu'><li><a href='indexa.jsp'>HOME&nbsp;&nbsp;&nbsp;&nbsp;</a></li><li><a href='Alogin.html'>&nbsp;&nbsp;ADMIN&nbsp;&nbsp;&nbsp;&nbsp;</a></li>");
			out.println("<li><a href='Ulogin.html'>&nbsp;&nbsp;USER&nbsp;&nbsp;&nbsp;</a></li><li><a href='AboutUs.html''>&nbsp;&nbsp;ABOUT US&nbsp;&nbsp;&nbsp;</a></li>");
			out.println("<li><a href='ContactUs.jsp'>&nbsp;&nbsp;CONTACT US&nbsp;&nbsp;&nbsp;</a></li></ul>");
			out.println("</div><BR> </header>");
			out.println("<div class='dropdown1'>");
			out.println("<button onmouseover='myFunction()' class='dropbtn1'>");
			out.println("Welcome  "+session.getAttribute("name"));								//Getting Name from session Object 
			out.println("</button>");
			out.println("<div id='myDropdown1' class='dropdown-content1'>");
			out.println("<a href='logout.jsp'>Log Out</a> </div> </div>");
			out.println("<img src='images/left.png' width='60px' height='60px' id='imb1'><a href='DisplayAuto'><div class='R2'><h4>BACK</h4></div></a>");
			out.println("<div class='admin'><center>");
	        out.println("<table><tr>");
	        out.println("<td><h1 style='color:#FFFFFF'>Updated Details</h1></td></tr></table><center></div>");
	        out.println("<script type='text/javascript'>");
			out.println("function ConfirmSave(){");        
			out.println("var Ok = alert('Are you sure want to save the changes?');");			//Displaying Alert Message
			out.println("document.location.href='DisplayManual';");       
			out.println("}");
			out.println("</script></head><body><div id='sec'>");								//Printing table
			out.println("<table id='color' align='center'><tr><td>User ID:</td><td>"+imuvo.getUid()+"</td></tr>");
			out.println("<tr><td>Name:</td><td>"+imuvo.getName()+"</td></tr>");
			out.println("<tr><td>Status:</td><td>"+imuvo.getStatus()+"</td></tr>");
			out.println("<tr><td>Borrow Rating:</td><td>"+imuvo.getRating()+"</td></tr>");
			out.println("<tr><td>Accrual Status:</td><td >"+imuvo.getAccrstatus()+"</td></tr>");
			out.println("<tr><td>Bank number:</td><td >"+imuvo.getBno()+"</td></tr>");
			out.println("<tr><td>Account number:</td><td>"+imuvo.getAccno()+"</td></tr>");
			out.println("<tr><td>Days past due:</td><td>"+imuvo.getDpd()+"</td></tr>");
			out.println("<tr><td>Comments:</td><td>"+imuvo.getComments()+"</td></tr>");
			out.println("<tr><td>Last Transaction Date:</td><td>"+imuvo.getDot()+"</td></tr>");
			out.println("<tr><td></td><td><input type='submit' id='sv' value='Save' onclick='ConfirmSave();'></td></tr></table></div>");
			 out.println("<div class='footer7'>");
			 out.println("<div class='ft-bottom2'>");
		     out.println("<p id='foot2'>&copy; 2016 AIP. All Rights Reserved. </p>");
		   	 out.println("</div> </div>");
			out.println("</body></html>");
		}
	}
}