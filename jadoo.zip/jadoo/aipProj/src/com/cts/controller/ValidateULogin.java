package com.cts.controller;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cts.bo.UserLoginBO;
import com.cts.model.UserLoginVO;

public class ValidateULogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
	response.sendRedirect("Ulogin.html");
	
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		UserLoginVO login = new UserLoginVO();								//Calling vo Object and Setting values
		login.setUname(request.getParameter("uname"));
		login.setPass(request.getParameter("pass"));
		UserLoginBO ulbo = new UserLoginBO();	

		boolean result = false;
		try {
			result = ulbo.validateLogin(login);								//calling Method to validate login 
		} catch (SQLException e) {
			 Logger.getLogger(ValidateULogin.class.getName()).error(e.toString());

		}
		if (result == true)

		{
			RequestDispatcher rd;
			String uname = request.getParameter("uname");
			request.setAttribute("uname", uname);
			rd = request.getRequestDispatcher("UserTrans");					//Redirect to User Transaction Page
			rd.forward(request, response);
		} else {
			response.sendRedirect("UserFailure.jsp");							//Redirect to Failure Page
		}
	}

}
