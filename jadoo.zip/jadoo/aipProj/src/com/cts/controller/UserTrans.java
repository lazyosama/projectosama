package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cts.bo.UStatusBO;
import com.cts.bo.UserTransBO;
import com.cts.model.UStatusVO;
import com.cts.model.UserTransacts;

public class UserTrans extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String uname=request.getParameter("uname");	
		UserTransacts ut=new UserTransacts();								//Calling VO and BO Objects
		UStatusVO uvo=new UStatusVO();
		UStatusBO ubo=new UStatusBO();
		uvo.setUname(uname);												//setting user Id and name			
		uvo=ubo.uStatus(uvo);
		ArrayList<UserTransacts> l1=new ArrayList<UserTransacts>();
		
		int flag=0;
		ut.setUname(uname);	
		UserTransBO utbo=new UserTransBO();
		try {
		l1=utbo.userTransactions(uname);									//calling method to get user transactions
		Iterator<UserTransacts> e= l1.iterator();
		out.println("<html><head><title>User Transactions</title>");
		out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
		out.println("<link rel='stylesheet' href='css/ind1.css' type='text/css' media='all'>");
		out.println("<link rel='stylesheet' href='css/mark.css' type='text/css' media='all'>");
		out.println("<link rel='stylesheet' href='css/footer.css' type='text/css' media='all'>");	
		out.println("<script type = 'text/javascript'>");
		out.println("function preventBack() { window.history.forward(0); }");
		out.println("setTimeout('preventBack()', 0);");
		out.println("window.onunload = function () { null };");
		out.println("</script>");
		out.println("<script>");
		out.println("function myFunction() {");									//Logout Display Function
		out.println("document.getElementById('myDropdown1').classList.toggle('show');");
		out.println("}window.onclick = function(event) {");
		out.println("if (!event.target.matches('.dropbtn1')) {");
	    out.println("var dropdowns = document.getElementsByClassName('dropdown-content1');var i;");
		out.println("for (i = 0; i < dropdowns.length; i++) {");
		out.println("var openDropdown = dropdowns[i];");
		out.println("if (openDropdown.classList.contains('show')) {");
		out.println("openDropdown.classList.remove('show');");
		out.println("}} }}</script>");
		out.println("</head><body><header><div id='main'><ul id='menu'>");
		/*out.println("<ul id='menu'><li><a href='indexa.jsp'>HOME&nbsp;&nbsp;&nbsp;&nbsp;</a></li><li><a href='#'>&nbsp;&nbsp;ADMIN&nbsp;&nbsp;&nbsp;&nbsp;</a></li>");
        out.println("<li><a href='Ulogin.html'>&nbsp;&nbsp;USER&nbsp;&nbsp;&nbsp;</a></li><li><a href='AboutUs.html'>&nbsp;&nbsp;ABOUT US&nbsp;&nbsp;&nbsp;</a></li>");
        out.println("<li><a href='ContactUs.jsp'>&nbsp;&nbsp;CONTACT US&nbsp;&nbsp;&nbsp;</a></li></ul>");*/
		out.println("</div><BR> </header>");
		out.println("<div class='dropdown1'>");
		out.println("<button onmouseover='myFunction()' class='dropbtn1'>");
		out.println("Welcome  "+uvo.getName());	  //Printing  User Name
		out.println("</button>");
		out.println("<div id='myDropdown1' class='dropdown-content1'>");
		out.println("<a href='logout.jsp'>Log Out</a> </div> </div>");
		out.println("<div class='admin'><center>");
        out.println("<table><tr><td><img src='images/userr.png' width='50px' height='50px'></td>");
        out.println("<td><h1 style='color:#FFFFFF'>Transactions Details</h1></td></tr></table><center></div>");
        out.println("<div id='second'>");
        out.println("</br><center><h2 style='color:#FFFFFF'>Welcome "+uvo.getName()+"</h2>");
        if(uvo.getStatus()==null|| uvo.getStatus().equals("null")){							//Checking for User Status
        	out.println("</br><center><h3 style='color:#FFFFFF'>You are not a Defaulter.</h3>");
        }
        else{
		out.println("</br><center><h3 style='color:#FFFFFF'>Your Default status is "+uvo.getStatus()+"</h3>");
        }		
		out.println("<img src='images/pdf.png' width='40px' height='40px' id='pdfimg'><form action='Demo'><input type='hidden' name='uname' value="+uname+"><input type='hidden' name='name' value="+uvo.getName()+"><input type='submit' name='sub' value='PDF' id='pdf1'></form>");
		out.println("<img src='images/excel.png' width='60px' height='100px' id='pdfex'><form action='Excel'><input type='hidden' name='uname' value="+uname+"><input type='hidden' name='name' value="+uvo.getName()+"><input type='submit' name='sub' value='Excel' id='ex1'></form>");
		int f=1;
        while(e.hasNext()){
		ut=e.next();
		flag=1;
		if(f==1){ 										//Printing Transaction details in table
			out.println("<br><center><table cellspacing='10'><tr><th>Date of Transaction</th><th>Amount</th>");
	        out.println("<th>To Account</th><th>From Account</th>");
	        out.println("<th>From Bank</th></tr>");		
		}    
		out.println("<tr><td>"+ut.getDot()+"</td>");
		out.println("<td>"+ut.getAmount()+"</td>");
		out.println("<td>"+ut.getToA()+"</td>");
		out.println("<td>"+ut.getFromA()+"</td>");
		out.println("<td>"+ut.getFromB()+"</td></tr>");		
		f=0;		
		}
       
		} catch (SQLException e) {
			 Logger.getLogger(UserTrans.class.getName()).error(e.toString());
		}		 
		out.println("</table></center>");		
		if(flag==0){
			 out.println("<center><h4 style='color:#FFFFFF'>Sorry you have not performed any transactions in last 3 months</center>");
		 
		}
		
		out.println("</div>");
		out.println("<div class='footer2'>");
		out.println("<div class='ft-bottom2'>");
	    out.println("<p id='foot2'>&copy; 2016 AIP. All Rights Reserved. </p>");
	    out.println("</div> </div>");
	    out.println("</body></html>");			
	}

}
