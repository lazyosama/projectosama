package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.bo.DisplayManualBO;
import com.cts.model.DisplayManualVO;

public class ManualRedefault extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		DisplayManualVO dmvo=new DisplayManualVO();							//Creating VO and BO Objects
		DisplayManualBO dmbo=new DisplayManualBO();
		ArrayList<DisplayManualVO> l1=new ArrayList<DisplayManualVO>();
		int flag=0;
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();							//calling session object
		try {
			l1=dmbo.manualRedefault();										//calling function to get Manual defaulters
			Iterator<DisplayManualVO> e= l1.iterator();
			out.println("<html><head><title>Re Defaulters</title>");
			out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
			out.println("<link rel='stylesheet' href='css/ind1.css' type='text/css' media='all'>");
			out.println("<link rel='stylesheet' href='css/mark.css' type='text/css' media='all'>");
			out.println("<link rel='stylesheet' href='css/footer.css' type='text/css' media='all'>");
			out.println("<script type = 'text/javascript'>");
			out.println("function preventBack() { window.history.forward(0); }");
			out.println("setTimeout('preventBack()', 0);");							//Method To prevent Back Transition
			out.println("window.onunload = function () { null };");
			out.println("</script>");
			out.println("<script>");
			out.println("function myFunction() {");									//Method To display name and Logout 
			out.println("document.getElementById('myDropdown1').classList.toggle('show');");
			out.println("}window.onclick = function(event) {");
			out.println("if (!event.target.matches('.dropbtn1')) {");
		    out.println("var dropdowns = document.getElementsByClassName('dropdown-content1');var i;");
			out.println("for (i = 0; i < dropdowns.length; i++) {");
			out.println("var openDropdown = dropdowns[i];");
			out.println("if (openDropdown.classList.contains('show')) {");
			out.println("openDropdown.classList.remove('show');");
			out.println("}} }}</script>");
			out.println("</head><body><header><div id='main'><ul id='menu'>");
			/*out.println("<ul id='menu'><li><a href='indexa.jsp'>HOME&nbsp;&nbsp;&nbsp;&nbsp;</a></li><li><a href='Alogin.html'>&nbsp;&nbsp;ADMIN&nbsp;&nbsp;&nbsp;&nbsp;</a></li>");
	        out.println("<li><a href='Ulogin.html'>&nbsp;&nbsp;USER&nbsp;&nbsp;&nbsp;</a></li><li><a href='AboutUs.html'>&nbsp;&nbsp;ABOUT US&nbsp;&nbsp;&nbsp;</a></li>");
	        out.println("<li><a href='ContactUs.jsp'>&nbsp;&nbsp;CONTACT US&nbsp;&nbsp;&nbsp;</a></li></ul>");*/
			out.println("</div><BR> </header>");
			out.println("<div class='dropdown1'>");			
			out.println("<button onmouseover='myFunction()' class='dropbtn1'>");
			out.println("Welcome  "+session.getAttribute("name"));				//calling session to get name
			out.println("</button>");
			out.println("<div id='myDropdown1' class='dropdown-content1'>");
			out.println("<a href='logout.jsp'>Log Out</a> </div> </div>");
			out.println("<a href='DisplayManual'><img src='images/left.png' width='60px' height='60px' id='imb1'></a><div class='R2'><h4>BACK</h4></div>");
			out.println("<div class='admin'><center>");
	        out.println("<table><tr><td> <img src='images/s6.png' width='50px' height='50px'></td>");
	        out.println("<td><h1 style='color:#FFFFFF'>Re-Defaulters</h1></td></tr></table><center></div>");
	        out.println("<div id='second'>");
	      
			int f=1;
	        while(e.hasNext()){
			dmvo=e.next();
			flag=1;
			if(f==1){ 																	//Printing defaulters in table
				out.println("</br><center><h3 style='color:#FFFFFF'>The following are the Auto Re-Defaulters.. </h3>");
				out.println("<br><div style='height: 235px; width: 900px; text-align:center; overflow-y:auto;'><table border='1' id='upd'><tr><th>UserID</th><th>Name</th>");
			    out.println("<th>Status</th>");
				out.println("<th>Borrower Rating</th><th>Accrual Status</th>");
		        out.println("<th>Bank No</th><th>Account Number</th>");
		        out.println("<th>Days Past Due</th><th>Comments</th>");
		        out.println("<th>Last Transaction Date</th></tr>");			
			}    
			out.println("<tr><td>"+dmvo.getUid()+"</td>");
			out.println("<td align='center'>"+dmvo.getName()+"</td>");
			out.println("<td align='center'>"+dmvo.getStatus()+"</td>");
			out.println("<td align='center'>"+dmvo.getRating()+"</td>");
			out.println("<td align='center'>"+dmvo.getAccrstatus()+"</td>");
			out.println("<td align='center'>"+dmvo.getBno()+"</td>");
			out.println("<td align='center'>"+dmvo.getAccno()+"</td>");
			out.println("<td align='center'>"+dmvo.getDpd()+"</td>");
			out.println("<td align='center'>"+dmvo.getComments()+"</td>");
			out.println("<td align='center'>"+dmvo.getDot()+"</td>");			
			f=0;			
			}
	        out.println("</table></div></div>");
	        out.println("<div class='footer2'>");
			out.println("<div class='ft-bottom2'>");
		    out.println("<p id='foot2'>&copy; 2016 AIP. All Rights Reserved. </p>");
		    out.println("</div> </div></html>");					
		 } catch (SQLException e) {
			 Logger.getLogger(ManualRedefault.class.getName()).error(e.toString());

		}
		if(flag==0){															//if no results Found
			 out.println("<center><h1 id='error' style='color:#FFFFFF'>Search Found No Relevant Results</h1></center>");
			 out.println("<div class='footer2'>");
			 out.println("<div class='ft-bottom2'>");
		     out.println("<p id='foot2'>&copy; 2016 AIP. All Rights Reserved. </p>");
		     out.println("</div> </div>");			 
		}
			
	}

}