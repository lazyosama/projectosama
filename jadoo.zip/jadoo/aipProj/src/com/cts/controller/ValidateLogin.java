package com.cts.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.bo.LoginBO;
import com.cts.model.LoginVO;

public class ValidateLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LoginVO lvo=new LoginVO();
		 
		lvo.setUname(request.getParameter("uName"));
		lvo.setPass(request.getParameter("uPass"));
		lvo.setName("null");
		LoginBO lbo=new LoginBO();										//calling BO and VO object
		lvo=lbo.validateLogin(lvo);
		String name=lvo.getName();
		HttpSession session=request.getSession();						//calling session object and setting name as attribute
		session.setAttribute("name", name);
		if(lvo.getName().equals("null"))								//If condition not true redirect to Failure page
		{	
			response.sendRedirect("Failure.jsp");			
		}
		else															//direct to admion page
		{
			  
			response.sendRedirect("admin.jsp");			
		}
			
	}

}
