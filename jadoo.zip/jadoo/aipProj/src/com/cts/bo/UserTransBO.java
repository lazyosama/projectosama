package com.cts.bo;

import java.sql.SQLException;
import java.util.ArrayList;
import com.cts.dao.UserTranDAO;
import com.cts.model.UserTransacts;

public class UserTransBO {
public  ArrayList<UserTransacts> userTransactions(String uname) throws SQLException {		//Method to get User Transactions
		
		ArrayList<UserTransacts> list1=new ArrayList<UserTransacts>();
		UserTranDAO usertd=new UserTranDAO();
		list1=usertd.userTransactions(uname);
		return list1;
	}
}
