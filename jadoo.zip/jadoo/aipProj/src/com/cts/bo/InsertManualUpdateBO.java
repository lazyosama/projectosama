package com.cts.bo;

import com.cts.dao.InsertManualUpdateDAO;

import com.cts.model.InsertManualUpdateVO;

public class InsertManualUpdateBO {														//Method to Insert Manual Defaulters
public boolean insertManualUpdate(InsertManualUpdateVO imuvo)
{
	InsertManualUpdateDAO imudao=new InsertManualUpdateDAO();
	boolean result=imudao.insertManualUpdate(imuvo);
			
	return result;
}
}
