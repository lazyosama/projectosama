package com.cts.bo;

import com.cts.dao.UStatusDAO;

import com.cts.model.UStatusVO;

public class UStatusBO {
public UStatusVO uStatus(UStatusVO uservo)		//Method to get User Status
{
	UStatusDAO udao=new UStatusDAO();
	UStatusVO uservo1=new UStatusVO();
	uservo1=uservo;
	uservo1=udao.uStatus(uservo);
	return uservo1;
}

}
