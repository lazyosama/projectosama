package com.cts.bo;

import com.cts.dao.DefaulterDAO;
import com.cts.model.DefaulterVO;

public class DefaulterBO {
public boolean setDefault(DefaulterVO defvo)					
{
	boolean result=false;
	DefaulterDAO defdao=new DefaulterDAO();
	result=defdao.setDefault(defvo);
	return result;
	
	
}
}
