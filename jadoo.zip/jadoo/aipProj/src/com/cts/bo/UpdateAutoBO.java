package com.cts.bo;

import java.sql.SQLException;

import com.cts.dao.UpdateAutoDAO;
import com.cts.model.UpdateAutoVO;

public class UpdateAutoBO {
public UpdateAutoVO searchAuto(String uid) throws SQLException{			//Method to Update Auto Defaulters
	UpdateAutoDAO umdao=new UpdateAutoDAO();
	UpdateAutoVO umanvo=umdao.searchAuto(uid);
	return umanvo;
	
}
}
