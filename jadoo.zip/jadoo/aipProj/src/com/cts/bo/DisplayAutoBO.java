
package com.cts.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cts.dao.DisplayAutoDAO;
import com.cts.model.DisplayAutoVO;



public class DisplayAutoBO {
	public ArrayList<DisplayAutoVO> displayAuto() throws SQLException{			//Method to display auto defaulters
	ArrayList<DisplayAutoVO> list1=new ArrayList<DisplayAutoVO>();
	DisplayAutoDAO dmandao=new DisplayAutoDAO();
	list1=dmandao.displayAuto();															

	return list1;
	}
	public ArrayList<DisplayAutoVO> autoRedefault() throws SQLException{			//Method to display Redefaulters
		ArrayList<DisplayAutoVO> list1=new ArrayList<DisplayAutoVO>();
		DisplayAutoDAO dmandao=new DisplayAutoDAO();
		list1=dmandao.autoRedefault();

		return list1;
		}
}
