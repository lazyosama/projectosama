package com.cts.bo;

import com.cts.dao.InsertAutoUpdateDAO;
import com.cts.model.InsertAutoUpdateVO;

public class InsertAutoUpdateBO {								//Method to Insert Auto Defaulters
public boolean insertAutoUpdate(InsertAutoUpdateVO imuvo)
{
	InsertAutoUpdateDAO imudao=new InsertAutoUpdateDAO();
	boolean result=imudao.insertAutoUpdate(imuvo);
			
	return result;
}
}
