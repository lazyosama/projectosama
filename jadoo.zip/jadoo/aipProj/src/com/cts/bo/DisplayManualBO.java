
package com.cts.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cts.dao.DisplayManualDAO;
import com.cts.model.DisplayManualVO;



public class DisplayManualBO {																//Method to display Manual Defaulters
	public ArrayList<DisplayManualVO> displayManual() throws SQLException{
	ArrayList<DisplayManualVO> list1=new ArrayList<DisplayManualVO>();
	DisplayManualDAO dmandao=new DisplayManualDAO();
	list1=dmandao.displayManual();

	return list1;
	}
	public ArrayList<DisplayManualVO> manualRedefault() throws SQLException{				//Method to display Manual Re-Defaulters
		ArrayList<DisplayManualVO> list1=new ArrayList<DisplayManualVO>();
		DisplayManualDAO dmandao=new DisplayManualDAO();
		list1=dmandao.manualRedefault();

		return list1;
		}
}
