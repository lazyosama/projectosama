package com.cts.bo;


import com.cts.dao.UserRegisterDAO;
import com.cts.model.UserRegisterVo;

public class UserRegisterBo {

		public boolean validateLogin(UserRegisterVo login) {		//Method to register User
			boolean result=false;
			UserRegisterDAO logindao=new UserRegisterDAO();
			result=logindao.validateLogin(login);
			return result;
		}
	/*public String searchAdminEmail(String uid)						//method to check for already present Admin Email
	{
		UserRegisterDAO logindao=new UserRegisterDAO();
		String email=logindao.searchAdminEmail(uid);
		return email;
	}*/

	public String searchUserEmail(String uid)						//method to check for already present User Email
	{
		UserRegisterDAO logindao=new UserRegisterDAO();
		String email=logindao.searchUserEmail(uid);
		return email;
	}

}
