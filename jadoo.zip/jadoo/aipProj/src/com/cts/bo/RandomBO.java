package com.cts.bo;

import com.cts.dao.RandomDAO;
import com.cts.model.RandomVO;

public class RandomBO {				
public boolean random(RandomVO randmvo)					//Method to check Random No already exits or not
{
	RandomDAO randmdo=new RandomDAO();
	boolean result=randmdo.random(randmvo);
	return result;
}
}
