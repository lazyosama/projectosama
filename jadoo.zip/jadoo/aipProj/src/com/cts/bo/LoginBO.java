package com.cts.bo;

import com.cts.dao.LoginDAO;
import com.cts.model.LoginVO;

public class LoginBO {								
public LoginVO validateLogin(LoginVO loginvo)				//Method to Validate Admin Login
{
	LoginVO loginvo1=new LoginVO();
	LoginDAO logindao=new LoginDAO();
	loginvo1=logindao.validateLogin(loginvo);
	return loginvo1;
}
}
