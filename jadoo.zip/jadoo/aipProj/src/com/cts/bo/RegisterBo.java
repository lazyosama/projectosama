package com.cts.bo;


import com.cts.dao.RegisterDAO;
import com.cts.dao.UserRegisterDAO;
import com.cts.model.RegisterVo;

public class RegisterBo {

	public boolean validateLogin(RegisterVo login) {				//Method to validate Login Id and Password
		boolean result=false;
		RegisterDAO logindao=new RegisterDAO();
		result=logindao.validateLogin(login);
		return result;
	}
	public String searchAdminEmail(String uid)						//method to check for already present Admin Email
	{
		RegisterDAO logindao=new RegisterDAO();
		String email=logindao.searchAdminEmail(uid);
		return email;
	}
}
