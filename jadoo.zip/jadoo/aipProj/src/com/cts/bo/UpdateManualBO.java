package com.cts.bo;

import java.sql.SQLException;

import com.cts.dao.UpdateManualDAO;
import com.cts.model.UpdateManualVO;

public class UpdateManualBO {
public UpdateManualVO searchManual(String uid) throws SQLException{			//Method to Update Manual Defaulters 
	UpdateManualDAO umdao=new UpdateManualDAO();
	UpdateManualVO umanvo=umdao.searchManual(uid);
	return umanvo;
	
}
}
