package com.cts.bo;

import java.sql.SQLException;


import com.cts.dao.UserLoginDAO;
import com.cts.model.UserLoginVO;

public class UserLoginBO {
	public  boolean validateLogin(UserLoginVO login) throws SQLException{		//Method to validate User Login Id and Password
		
		boolean result=false;
		if(login.getUname().length()>4)
		{
			
		UserLoginDAO uldao=new UserLoginDAO();
		result=uldao.validateLogin(login);
		}
		return result;
	}
}
