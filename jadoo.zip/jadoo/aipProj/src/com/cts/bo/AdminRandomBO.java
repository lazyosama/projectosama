package com.cts.bo;


import java.util.Random;

import com.cts.dao.AdminRandomDAO;

import com.cts.model.AdminRandomVO;

public class AdminRandomBO {
public boolean random(AdminRandomVO regvo)							//Method to check for Random No already exists or not
{
	AdminRandomDAO regdo=new AdminRandomDAO();
	boolean result=regdo.random(regvo);
	return result;
}

public String generateRandomNumber(int start, int end ){
	String s;	
	boolean result=true;
        do{
        	Random random = new Random();
        long fraction = (long) ((end - start + 1 ) * random.nextDouble());
        String a=Long.toString((fraction + start));
        
         StringBuffer sb=new StringBuffer();
         sb.append(a);
         
      	s=sb.toString();
      	AdminRandomVO rvo= new AdminRandomVO();
      	rvo.setId(s);
      //	AdminRandomBO rbo=new AdminRandomBO();
        result=random(rvo);
        
        }
        while(result==true);
      	return s;
      	
    }
}
