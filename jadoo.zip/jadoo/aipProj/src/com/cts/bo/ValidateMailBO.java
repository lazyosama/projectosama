package com.cts.bo;

import java.sql.SQLException;


import com.cts.dao.ValidateMailDAO;
import com.cts.model.ValidateMailVO;

public class ValidateMailBO {
	public  boolean validateMail(ValidateMailVO login) throws SQLException{		//Method to validate Email
		
	boolean result=false;	
	ValidateMailDAO ulogdao=new ValidateMailDAO();
	result=ulogdao.validateMail(login);
	
	return result;

}
}
