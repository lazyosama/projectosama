package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;
import com.cts.model.DefaulterVO;
import com.cts.util.DBConnect;

public class DefaulterDAO {
	Connection con = null;
	PreparedStatement smt = null;
	ResultSet rs = null;
	ResourceBundle res = null;

	public boolean setDefault(DefaulterVO dvo) {										//Method to set Defaulters
		boolean result = false;
		res = ResourceBundle.getBundle("query");
		DBConnect connect = new DBConnect();
		connect.initializeDriver();
		con = connect.getConnect();

		try {

			smt = con.prepareStatement(res.getString("SET_DEFAULT_TABLE"));				//Query to set Defaulter table
			smt.setString(1, dvo.getUid());
			smt.setString(2, dvo.getStatus());
			smt.setString(3, dvo.getName());
			smt.setInt(4, dvo.getRating());
			smt.setInt(5, dvo.getAccrstatus());
			smt.setString(6, dvo.getBankno());
			smt.setLong(7, dvo.getAccno());
			smt.setInt(8, dvo.getDpd());
			smt.setString(9, dvo.getComment());
			smt.setString(10, dvo.getDot());
			int i;
			i = smt.executeUpdate();

			if (i != 0) {
				result = true;
			}
		}
		catch (SQLException e) {
			 Logger.getLogger(DefaulterDAO.class.getName()).error(e.toString());
		}
		return result;
	}
}
