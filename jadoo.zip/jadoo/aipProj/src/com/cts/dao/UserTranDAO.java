package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.cts.model.UserTransacts;
import com.cts.util.DBConnect;

public class UserTranDAO {
	Connection con = null;									//setting and initialing connection 
	PreparedStatement smt = null;
	ResultSet rs = null;
	ResourceBundle resource = null;

	public ArrayList<UserTransacts> userTransactions(String uname) throws SQLException {
		resource = ResourceBundle.getBundle("query");
		DBConnect connect = new DBConnect();
		connect.initializeDriver();
		con = connect.getConnect();
		ArrayList<UserTransacts> l1 = new ArrayList<UserTransacts>();
		try {

			smt = con.prepareStatement(resource.getString("GET_TRANS_DETAILS"));		//Query to get User Transactions
			smt.setString(1, uname);
			rs = smt.executeQuery();

			while (rs.next()) {
				UserTransacts ut = new UserTransacts();
				ut.setUname(rs.getString(1));
				ut.setDot(rs.getDate(2));
				ut.setAmount(rs.getInt(3));
				ut.setToA(rs.getLong(4));
				ut.setFromA(rs.getLong(5));
				ut.setFromB(rs.getString(6));
				l1.add(ut);
			}

		} catch (SQLException e) {

			 Logger.getLogger(UserTranDAO.class.getName()).error(e.toString());
		} finally {

			try {
				rs.close();										//closing connection result set and statement
				smt.close();
				con.close();
			} catch (SQLException e) {
				 Logger.getLogger(UserTranDAO.class.getName()).error(e.toString());

			}
		}
		return l1;

	}
}
