package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.cts.model.UpdateAutoVO;
import com.cts.util.DBConnect;

public class UpdateAutoDAO {
	Connection con = null;
	PreparedStatement smt = null;
	ResultSet rs = null;
	ResourceBundle resource = null;												//setting and initialing connection 

	public UpdateAutoVO searchAuto(String uid) throws SQLException {

		resource = ResourceBundle.getBundle("query");
		DBConnect connect = new DBConnect();
		connect.initializeDriver();
		con = connect.getConnect();
		UpdateAutoVO umvo = new UpdateAutoVO();
		try {

			smt = con.prepareStatement(resource.getString("GET_SEARCH_AUTO_DEFAULTER"));	//Query to search for Auto Defaulters
			smt.setString(1, uid);
			rs = smt.executeQuery();

			while (rs.next()) {
				umvo.setUid(rs.getString(1));
				umvo.setStatus(rs.getString(2));
				umvo.setName(rs.getString(3));
				umvo.setRating(rs.getInt(4));
				umvo.setAccrstatus(rs.getInt(5));
				umvo.setBno(rs.getString(6));
				umvo.setAccno(rs.getLong(7));
				umvo.setDpd(rs.getInt(8));
				umvo.setComments(rs.getString(9));
			}

		} catch (SQLException e) {

			 Logger.getLogger(UpdateAutoDAO.class.getName()).error(e.toString());

		} finally {

			try {
				rs.close();										//closing connection result set and statement
				smt.close();
				con.close();
			} catch (SQLException e) {
				 Logger.getLogger(UpdateAutoDAO.class.getName()).error(e.toString());

			}
		}
		return umvo;

	}

}
