package com.cts.dao;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.cts.model.AdminRandomVO;
import com.cts.util.DBConnect;

public class AdminRandomDAO {
	Connection con=null;				
	PreparedStatement smt=null;
	ResultSet rs=null;
	ResourceBundle resource=null;
	public boolean random(AdminRandomVO rvo)  								//Method to check non repeatation of User_ID
	{
		boolean result=false;
		resource=ResourceBundle.getBundle("query");
		DBConnect connect=new DBConnect();
		connect.initializeDriver();
		con=connect.getConnect();
	
try {
			
		smt= con.prepareStatement(resource.getString("GET_ARANDOM"));			//Setting Query to check User_ID
		smt.setString(1, rvo.getId());
		rs=smt.executeQuery();			
		while(rs.next())
		{
			result=true;
		}				
	}
catch (SQLException e) {
	
	 Logger.getLogger(AdminRandomDAO.class.getName()).error(e.toString());

}finally {		
		try {																	//closing connection result set and statement
			rs.close();
			smt.close();
			con.close();
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				 Logger.getLogger(AdminRandomDAO.class.getName()).error(e.toString());
			}
		}
return result;
}
}
