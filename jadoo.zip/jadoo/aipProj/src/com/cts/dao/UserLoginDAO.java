package com.cts.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import java.sql.*;

import com.cts.model.UserLoginVO;
import com.cts.util.DBConnect;

public class UserLoginDAO {
	Connection con = null;
	PreparedStatement smt = null;
	ResultSet rs = null;
	ResourceBundle resource = null; 										// setting and initialing connection

	public boolean validateLogin(UserLoginVO login) throws SQLException {
		resource = ResourceBundle.getBundle("query");
		boolean result = false;
		DBConnect connect = new DBConnect();
		connect.initializeDriver();
		con = connect.getConnect();
		try {
			smt = con.prepareStatement(resource.getString("SET_USER_LOGIN_DETAILS"));	//Query to set login Details
			smt.setString(1, login.getUname());
			smt.setString(2, login.getPass());
			rs = smt.executeQuery();
			while (rs.next()) {
				result = true;
			}
		} catch (SQLException e) {

			 Logger.getLogger(UserLoginDAO.class.getName()).error(e.toString());
		} finally {

			try {
				rs.close();																//closing connection result set and statement
				smt.close();
				con.close();
			} catch (SQLException e) {
				 Logger.getLogger(UserLoginDAO.class.getName()).error(e.toString());

			}
		}
		return result;
	}

}
