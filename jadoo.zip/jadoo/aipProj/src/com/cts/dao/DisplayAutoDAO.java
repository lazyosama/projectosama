package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;
import com.cts.model.DisplayAutoVO;
import com.cts.util.DBConnect;

public class DisplayAutoDAO {
	Connection con = null;
	PreparedStatement smt = null;
	ResultSet rs = null;
	ResourceBundle resource = null;

	public ArrayList<DisplayAutoVO> displayAuto() throws SQLException {				//Method to Display Auto Defaulters 

		resource = ResourceBundle.getBundle("query");
		DBConnect connect = new DBConnect();										//setting and initialing connection 
		connect.initializeDriver();
		con = connect.getConnect();
		ArrayList<DisplayAutoVO> l1 = new ArrayList<DisplayAutoVO>();
		try {
			smt = con.prepareStatement(resource.getString("GET_AUTO_DEFAULTERS"));		//Query to get Auto Defaulters
			rs = smt.executeQuery();
			while (rs.next()) {
				DisplayAutoVO dmvo = new DisplayAutoVO();
				dmvo.setUid(rs.getString(1));
				dmvo.setStatus(rs.getString(2));
				dmvo.setName(rs.getString(3));
				dmvo.setRating(rs.getInt(4));
				dmvo.setAccrstatus(rs.getInt(5));
				dmvo.setBno(rs.getString(6));
				dmvo.setAccno(rs.getLong(7));
				dmvo.setDpd(rs.getInt(8));
				dmvo.setComments(rs.getString(9));
				dmvo.setDot(rs.getString(10));
				l1.add(dmvo);
			}

		} catch (SQLException e) {

			 Logger.getLogger(DisplayAutoDAO.class.getName()).error(e.toString());
		}
		return l1;

	}

	public ArrayList<DisplayAutoVO> autoRedefault() throws SQLException {					//Method to Display Auto Defaulters

		resource = ResourceBundle.getBundle("query");										//setting and initialing connection 
		DBConnect connect = new DBConnect();
		connect.initializeDriver();
		con = connect.getConnect();
		ArrayList<DisplayAutoVO> l1 = new ArrayList<DisplayAutoVO>();
		try {

			smt = con.prepareStatement(resource.getString("SET_AUTO_RE_DEFAULTERS"));		//Query to set Auto Redefaulters
			int i = smt.executeUpdate();
			if (i != 0) {
				smt = con.prepareStatement(resource.getString("GET_AUTO_RE_DEFAULTERS"));	//Query to get Auto Redefaulters
				rs = smt.executeQuery();
				while (rs.next()) {
					DisplayAutoVO dmvo = new DisplayAutoVO();
					dmvo.setUid(rs.getString(1));
					dmvo.setStatus(rs.getString(2));
					dmvo.setName(rs.getString(3));
					dmvo.setRating(rs.getInt(4));
					dmvo.setAccrstatus(rs.getInt(5));
					dmvo.setBno(rs.getString(6));
					dmvo.setAccno(rs.getLong(7));
					dmvo.setDpd(rs.getInt(8));
					dmvo.setComments(rs.getString(9));
					dmvo.setDot(rs.getString(10));
					l1.add(dmvo);
				}

			}
		} catch (SQLException e) {

			 Logger.getLogger(DisplayAutoDAO.class.getName()).error(e.toString());
		} finally {											//closing connection result set and statement

			try {
				rs.close();
				smt.close();
				con.close();
			} catch (SQLException e) {
				 Logger.getLogger(DisplayAutoDAO.class.getName()).error(e.toString());
			}
		}
		return l1;

	}

}
