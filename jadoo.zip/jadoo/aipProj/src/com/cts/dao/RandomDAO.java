package com.cts.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.cts.model.RandomVO;
import com.cts.util.DBConnect;

public class RandomDAO {
	Connection con = null;
	PreparedStatement smt = null;
	ResultSet rs = null;
	ResourceBundle resource = null;

	public boolean random(RandomVO rvo) {
		boolean result = false;									//setting connection 
		resource = ResourceBundle.getBundle("query");
		DBConnect connect = new DBConnect();
		connect.initializeDriver();
		con = connect.getConnect();
		try {

			smt = con.prepareStatement(resource.getString("GET_URANDOM"));	//Query to Check non repeatation of User_ID
			smt.setString(1, rvo.getId());
			rs = smt.executeQuery();
			while (rs.next()) {
				result = true;
			}
		} catch (SQLException e) {

			 Logger.getLogger(RandomDAO.class.getName()).error(e.toString());
		} finally {

			try {
				rs.close();												//closing connection result set and statement
				smt.close();
				con.close();
			} catch (SQLException e) {
				
				 Logger.getLogger(RandomDAO.class.getName()).error(e.toString());
			}
		}
		return result;
	}
}
