package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.cts.model.DisplayManualVO;
import com.cts.util.DBConnect;

public class DisplayManualDAO {
	Connection con = null;										//setting and initialing connection 
	PreparedStatement smt = null;
	ResultSet rs = null;
	ResourceBundle resource = null;

	public ArrayList<DisplayManualVO> displayManual() throws SQLException {			//Method to Display Manual Defaulters

		resource = ResourceBundle.getBundle("query");
		DBConnect connect = new DBConnect();
		connect.initializeDriver();
		con = connect.getConnect();
		ArrayList<DisplayManualVO> l1 = new ArrayList<DisplayManualVO>();
		try {
			smt = con.prepareStatement(resource.getString("GET_MANUAL_DEFAULTERS"));		//Query to Display Manual Defaulters
			rs = smt.executeQuery();
			while (rs.next()) {
				DisplayManualVO dmvo = new DisplayManualVO();
				dmvo.setUid(rs.getString(1));
				dmvo.setStatus(rs.getString(2));
				dmvo.setName(rs.getString(3));
				dmvo.setRating(rs.getInt(4));
				dmvo.setAccrstatus(rs.getInt(5));
				dmvo.setBno(rs.getString(6));
				dmvo.setAccno(rs.getLong(7));
				dmvo.setDpd(rs.getInt(8));
				dmvo.setComments(rs.getString(9));
				dmvo.setDot(rs.getString(10));
				l1.add(dmvo);
			}

		} catch (SQLException e) {

			 Logger.getLogger(DisplayManualDAO.class.getName()).error(e.toString());
		}
		return l1;

	}

	public ArrayList<DisplayManualVO> manualRedefault() throws SQLException {		//Method to Display Manual ReDefaulters

		resource = ResourceBundle.getBundle("query");
		DBConnect connect = new DBConnect();
		connect.initializeDriver();
		con = connect.getConnect();
		ArrayList<DisplayManualVO> l1 = new ArrayList<DisplayManualVO>();
		try {

			smt = con.prepareStatement(resource.getString("SET_MANUAL_RE_DEFAULTERS"));			//Query to Set Re-Defaulters
			int i = smt.executeUpdate();
			if (i != 0) {
				smt = con.prepareStatement(resource.getString("GET_MANUAL_RE_DEFAULTERS"));		//Query to Get Re-Defaulters
				rs = smt.executeQuery();
				while (rs.next()) {
					DisplayManualVO dmvo = new DisplayManualVO();
					dmvo.setUid(rs.getString(1));
					dmvo.setStatus(rs.getString(2));
					dmvo.setName(rs.getString(3));
					dmvo.setRating(rs.getInt(4));
					dmvo.setAccrstatus(rs.getInt(5));
					dmvo.setBno(rs.getString(6));
					dmvo.setAccno(rs.getLong(7));
					dmvo.setDpd(rs.getInt(8));
					dmvo.setComments(rs.getString(9));
					dmvo.setDot(rs.getString(10));
					l1.add(dmvo);
				}

			}
		} catch (SQLException e) {

			 Logger.getLogger(DisplayManualDAO.class.getName()).error(e.toString());
		} finally {
			try {																	//closing connection result set and statement
				rs.close();
				smt.close();
				con.close();
			} catch (SQLException e) {
				 Logger.getLogger(DisplayManualDAO.class.getName()).error(e.toString());

			}
		}
		return l1;

	}

}
