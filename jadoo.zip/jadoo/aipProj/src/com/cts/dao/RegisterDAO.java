package com.cts.dao;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.cts.model.RegisterVo;
import com.cts.util.DBConnect;


public class RegisterDAO {
	Connection con=null;
	PreparedStatement smt=null;
	ResultSet rs=null;
	ResourceBundle resource=null;														//setting and initialing connection 
	public boolean validateLogin(RegisterVo login)
	{
		resource=ResourceBundle.getBundle("query");
		boolean result=false;
		DBConnect connect=new DBConnect();
		connect.initializeDriver();
		con=connect.getConnect();
		try{
		smt=con.prepareStatement(resource.getString("GET_REG_DETAILS"));				//Query to get Registration details
		smt.setString(1,login.getLog());
		smt.setString(2, login.getPass());
		smt.setString(3, login.getFname());
		smt.setString(4, login.getLname());
		smt.setString(6, login.getGender());
		smt.setLong(7, login.getCum());
		smt.setString(9, login.getAdd());
		smt.setInt(5, login.getAge());
		smt.setString(8, login.getEmail());
		smt.setString(10, login.getCountry());
		smt.setString(11, login.getCity());
		smt.setInt(12, login.getZip());
		int i=0;
		i=smt.executeUpdate();
		if(i!=0)
		{
			result=true;
		}
		
	} catch (SQLException e) {
		 Logger.getLogger(RegisterDAO.class.getName()).error(e.toString());

	}finally {
		
		try {																	//closing connection result set and statement
			smt.close();
			con.close();
		} catch (SQLException e) {
			 Logger.getLogger(RegisterDAO.class.getName()).error(e.toString());

		}
	}
	return result;
}
	
	
	public String searchAdminEmail(String uid) {									//Method to Get Admin Email
		resource = ResourceBundle.getBundle("query");
		String email = null;
		DBConnect connect = new DBConnect();
		connect.initializeDriver();
		con = connect.getConnect();
		try {
			smt = con.prepareStatement(resource.getString("GET_ADMIN_EMAIL"));		//Query to Get Admin Email
			smt.setString(1, uid);
			rs = smt.executeQuery();
			while (rs.next()) {
				email = rs.getString("Email");

			}
		} catch (SQLException e) {
			 Logger.getLogger(RegisterDAO.class.getName()).error(e.toString());

		}
		return email;
	}
}
