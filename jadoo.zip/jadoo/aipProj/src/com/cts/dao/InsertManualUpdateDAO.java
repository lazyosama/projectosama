package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.cts.model.InsertManualUpdateVO;
import com.cts.util.DBConnect;

public class InsertManualUpdateDAO {
	Connection con = null;												//setting and initialing connection
	PreparedStatement smt = null;
	ResultSet rs = null;
	ResourceBundle resource = null;

	public boolean insertManualUpdate(InsertManualUpdateVO imuvo) {		//setting and initialing connection
		resource = ResourceBundle.getBundle("query");
		boolean result = false;
		DBConnect connect = new DBConnect();
		connect.initializeDriver();
		con = connect.getConnect();
		try {
			smt = con.prepareStatement(resource.getString("INSERT_MANUAL_UPDATE"));		//Query to insert Manual Update
			int i = 0;
			smt.setString(1, imuvo.getStatus());
			smt.setString(2, imuvo.getComments());
			smt.setString(3, imuvo.getDot());
			smt.setString(4, imuvo.getUid());
			i = smt.executeUpdate();
			if (i != 0) {																//check for valid condition
				result = true;
			}
		} catch (SQLException e) {
			 Logger.getLogger(InsertManualUpdateDAO.class.getName()).error(e.toString());

		} finally {
			try {
				smt.close();
				con.close();
			} catch (SQLException e) {
				 Logger.getLogger(InsertManualUpdateDAO.class.getName()).error(e.toString());

			}
		}
		return result;

	}

}
