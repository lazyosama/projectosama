package com.cts.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.cts.model.LoginVO;
import com.cts.util.DBConnect;

public class LoginDAO {
	Connection con = null;
	PreparedStatement smt = null;											//setting connection 
	ResultSet rs = null;
	ResourceBundle res = null;

	public LoginVO validateLogin(LoginVO lvo) {	
		res = ResourceBundle.getBundle("query");
		DBConnect connect = new DBConnect();
		connect.initializeDriver();											//Initialing connection 
		con = connect.getConnect();

		try {
			smt = con.prepareStatement(res.getString("SET_LOGIN_DETAILS"));		//Query to Set Login Details
			smt.setString(1, lvo.getUname());
			smt.setString(2, lvo.getPass());
			rs = smt.executeQuery();
			while (rs.next()) {
				lvo.setName(rs.getString(1));
				lvo.setUname(rs.getString(2));
				lvo.setPass(rs.getString(3));
			}
		} catch (SQLException e) {
			 Logger.getLogger(LoginDAO.class.getName()).error(e.toString());

		} finally {

			try {																//closing connection result set and statement
				rs.close();

				smt.close();
				con.close();
			} catch (SQLException e) {
				 Logger.getLogger(LoginDAO.class.getName()).error(e.toString());

			}
		}

		return lvo;
	}
}
