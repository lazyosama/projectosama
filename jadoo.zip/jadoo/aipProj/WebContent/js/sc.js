var zip_arr = new Array("select","382120","462021","560085","600013","110020","122001","500002","700001","400099",
		"226001","201301","411057","302005","453115","695010","531022","737135");
var s_a = new Array();
s_a[0]="";
s_a[2]="Ahemdabad";
s_a[3]="Bhopal";
s_a[4]="Banglore";
s_a[5]="Chennai";
s_a[6]="Delhi";
s_a[7]="Gurgaon";
s_a[8]="Hyderabad";
s_a[9]="Kolkata";
s_a[10]="Mumbai";
s_a[11]="Lucknow";
s_a[12]="Noida";
s_a[13]="Pune";
s_a[14]="Jaipur";
s_a[15]="Indore";
s_a[16]="Thiruvananthapuram";
s_a[17]="Visakhapatnam";
s_a[18]="Sikkim";

function print_zip(zip){
	// given the id of the <select> tag as function argument, it inserts <option> tags
	var option_str = document.getElementById(zip);
	var x, i=0;
	for(x in zip_arr){
		option_str.options[i++] = new Option(zip_arr[x],zip_arr[x]);
	}
}

function print_city(city, city_index){
	var option_str = document.getElementById(city);
	var x, i=0; city_index++;
	var city_arr = s_a[city_index].split("|");
	for(x in city_arr){
            option_str.options[i++] = new Option(city_arr[x],city_arr[x]);
	}
}










