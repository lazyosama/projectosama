$(document).ready(function() {
     $("#defForm").validate({
    	rules:
    		{
    		status:
    			{
    			required:true
    		
    			},
    			comments:
    		{
    				
    				required:true
    		},
    		dot:
			{
			required:true
		
			}
    		
      		},
    
    	messages:{
    		status:
    			{
    			 required:"   Mandatory field",
    			    			
    			},
           comments:{ 
            required:"   Mandatory field",
            
            },
            dot:
			{
			 required:"   Mandatory field",
			    			
			},
            
    	},  
    	 
         submitHandler: function(form) {
                form.submit();
            }
    });
});
