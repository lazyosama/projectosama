
jQuery.validator.addMethod("check", function(value, element) 
        {
 var str=value;
 if(str.match(/^([a-zA-Z0-9]{8,})$/))
	
         return true;
 else
         return  false;},"*password check");
jQuery.validator.addMethod("small", function(value, element) 
		{
	
	var s=value;
	if(s.match(/^(.*[a-z].*)$/))

        return true;
else
        return  false;},"*password check");
jQuery.validator.addMethod("large", function(value, element) 
		{
	
	var s1=value;
	if(s1.match(/^(.*[A-Z].*)$/))

        return true;
else
        return  false;},"*password check");
jQuery.validator.addMethod("num", function(value, element) 
        		{
        	
        	var s2=value;
        	if(s2.match(/^(.*[0-9].*)$/))

                return true;
        else
                return  false;},"*password check");

jQuery.validator.addMethod("recheck", function(value, element) 
		{
	var repass=value;
	var pass=$("input[name='pass1']").val();
	
	if(pass===repass)
	
		return true;
		else
			return false;
		},"*password check");
		

$(document).ready(function() {
     $("#Passwordform").validate({
    	 debug:true,
    	 errorElement:"em",
    	rules:
    		{
    		pass1:
    			{
    			required:true,
   			 small:true,
   			 large:true,
   			 num:true,
   			 minlength:8,
   			check:true
    			},
    			pass2:
    			{
    				required:true,
    	   			 small:true,
    	   			 large:true,
    	   			 num:true,
    	   			 minlength:8,
    	   			check:true,
    			 recheck:true
    			}
    		},
    		messages:{
        		pass1:
        			{
        			required:"  Mandatory field",
   				 small:"Atlest 1 small Character",
       			 large:"Atlest 1 capital Character",
       			 num:"Atlest 1 number",
       			  minlength:"Atleast 8 characters",
       			check:"No special characters"
       			
        			},
        			pass2:
        			{
        				required:"  Mandatory field",
          				 small:"Atlest 1 small Character",
              			 large:"Atlest 1 capital Character",
              			 num:"Atlest 1 number",
              			 minlength:"Atleast 8 characters",
              			check:"No special characters", 
            				 recheck:"Mis-match Password"
        			}
    		},

            submitHandler: function(form) {
            	
                form.submit();
            }
    });



    });