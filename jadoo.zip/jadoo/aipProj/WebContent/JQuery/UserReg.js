jQuery.validator.addMethod("lettersonly", function(value, element) 
		{
		return this.optional(element) || /^[a-z ]+$/i.test(value);}, "*Letters only please"); 
jQuery.validator.addMethod("numberonly", function(value, element) 
		{
		return this.optional(element) || /^[0-9]+$/i.test(value);}, "*Numbers  only please"); 
jQuery.validator.addMethod("emailid", function(value, element) 
		{
		return this.optional(element) ||/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i.test(value);}, "*Enter Valid Email Id"); 

jQuery.validator.addMethod("check", function(value, element) 
        {
 var str=value;
 if(str.match(/^([a-zA-Z0-9]{8,})$/))
	
         return true;
 else
         return  false;},"*password check");
jQuery.validator.addMethod("small", function(value, element) 
		{
	
	var s=value;
	if(s.match(/^(.*[a-z].*)$/))

        return true;
else
        return  false;},"*password check");
jQuery.validator.addMethod("large", function(value, element) 
		{
	
	var s1=value;
	if(s1.match(/^(.*[A-Z].*)$/))

        return true;
else
        return  false;},"*password check");
jQuery.validator.addMethod("num", function(value, element) 
        		{
        	
        	var s2=value;
        	if(s2.match(/^(.*[0-9].*)$/))

                return true;
        else
                return  false;},"*password check");

jQuery.validator.addMethod("agecheck", function(value, element) 
		{
	var a=value;
	if(a>=20)
		{
		return true;
		}
	else
		{
		return false;
		}
	
		},"*Age should be atleast 21");
jQuery.validator.addMethod("ageabove", function(value, element) 
		{
	var a=value;
	if(a<=100)
		{
		return true;
		}
	else
		{
		return false;
		}
	
		},"*Age should not exceed 100");

jQuery.validator.addMethod("capcheck", function(value, element) 
		{
	var repass=value;
	var pass=$("input[name='maincap']").val();
	
	
	if(pass==repass)
	
		return true;
		else
			return false;
		},"*Incorrect");
		
$(document).ready(function() {
     $("#regexpForm").validate({
    	rules:
    		{
    		pass:
    			{
    			required:true,
    			 small:true,
    			 large:true,
    			 num:true,
    			 check:true,
    			 minlength:8
    			},
    		fname:
    		{
          required:true,
          minlength:5,
               maxlength:20,
    		lettersonly:true	
           },
     lname:{
     	required:true,
 
         maxlength:20,
 		lettersonly:true
                  },
                  age:
                	  {
                	  required:true,
                	  numberonly:true,
                	  agecheck:true,
                	  ageabove:true
                	  },
         email:
        	 {
        	 required:true,
        	 emailid:true
        	 },
        	 cum:
             {
             	required:true,
				maxlength:10,
				minlength:10,
             	numberonly:true
             },
             add:
            	 {
            	 required:true
            	             	 },
             country:
            	 {
            	 required:true
            	 },
            	 city:
            	 {
            	 required:true
            	 },
            	 zip:
            	 {
                	 required:true
                	 },
                	 
                	 cap:
                		 {
                		 required:true,
                		 capcheck:true
                		 }
    		},
    
    	messages:{
    		pass:
    			{
    			 required:"  Mandatory field",
    				 small:"Atlest 1 small Character",
        			 large:"Atlest 1 capital Character",
        			 num:"Atlest 1 number",
        			 check:"No special characters", 
        			 minlength:"Atleast 8 characters"

        			
    			},
            fname:{ 
            required:"  Mandatory field",
            minlength:"  Atleast 5 characters",
             maxlength:"  Not more than 20 characters",
            lettersonly:" Alphabets Only  "
            	
            },
           
            lname:{
                required:"  Mandatory field",
           maxlength:"  Not more than 20 characters",
                lettersonly:"  Alphabets Only"
            },
            age:
    		{
    		required:"  Mandatory field",
    		 numberonly:"  Numbers Only",
    		agecheck:"  Age should be atleast 21",
    		ageabove:"Age should not exceed 100"
    		},
                        cum:
            	{
            	 required:"  Mandatory field",
				 maxlength:"  10 digit number",
				 minlength:"  10 digit number",
            	 numberonly:"  Numbers Only"
            	},
            	
            	
            email:"  Enter valid Email-ID",
    	
    	add:
     {
    		required:"  Please enter Address"
    		
     },
     country:
    	 {
    	 required:"  Please select country"
    	 
    	 },
     city:
	 {
	 required:"  Please select city"
	 
	 },
     zip:
	 {
	 required:"  Please select zip"
	 
	 },
	 cap:
		 {
		 
		 required:"  Mandatory field",
		 capcheck:" Incorrect Captcha"
		 }
    	},
     
            submitHandler: function(form) {
                form.submit();
            }
       	
          });    	
});
