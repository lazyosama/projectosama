$(document).ready(function() {
     $("#form").validate({
    	rules:
    		{
    		uPass:
    			{
    			required:true
    		
    			},
    			uname:
    		{
    				
    				required:true
    		},
    		pass:
			{
			required:true
		
			},
    		uName:
    		{
          required:true
         
           },
           uid:
           {
        	   required:true
           },
           email:
           {required:true
           }
        	   
           
      		},
    
    	messages:{
    		uPass:
    			{
    			 required:"   Mandatory field"
    			
    			
    			},
           uName:{ 
            required:"   Mandatory field"
            
            },
            pass:
			{
			 required:"   Mandatory field"
			
			
			},
       uname:{ 
        required:"   Mandatory field"
        
        },
        uid:
        {
     	   required:"   Mandatory field"
        },
        email:
        {required:"   Mandatory field"
        }
    	},  
    	 
         submitHandler: function(form) {
                form.submit();
            }
    });
});
