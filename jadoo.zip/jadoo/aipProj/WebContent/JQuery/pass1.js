jQuery(function(){
        $("#s5").click(function(){
        $(".error").hide();
        var hasError = false;
        var passwordVal = $("#ps1").val();
        var checkVal = $("#ps2").val();
        if (passwordVal == '') {
            $("#ps1").after('<span class="error" style="position:absolute; color:red; left:777px;top: 300px;"><br><br>Please enter a password.</span>');
            hasError = true;
        }if (checkVal == '') {
            $("#ps2").after('<span class="error" style="position:absolute; color:red; left:777px;top: 357px;"><br>Please re-enter your password.</span>');
            hasError = true;
        } 
        if (passwordVal != checkVal ) {
            $("#ps2").after('<span class="error"style="position:absolute; color:red;left: 560px;top: 407px;">Passwords do not match.</span>');
            hasError = true;
        }
        if(hasError == true) {return false;}
    });
});