jQuery.validator.addMethod("number", function(value, element) 
		{
		return this.optional(element) || /^[0-9]+$/i.test(value);}, "*Numbers  only please"); 

jQuery.validator.addMethod("no", function(value, element) 
		{
	return this.optional(element) || /^[a-zA-Z0-9]+$/i.test(value);}, "*mixed with letters and numbers"); 
jQuery.validator.addMethod("check", function(value, element) 
		{
		return this.optional(element) || /^[0-9]+$/i.test(value);}, "*enter numbers only"); 
jQuery.validator.addMethod("letter", function(value, element) 
		{
		return this.optional(element) || /^[a-z ]+$/i.test(value);}, "*Letters only please");
jQuery.validator.addMethod("numcheck", function(value, element) 
		{
		return this.optional(element) || /^[a-z]+$/i.test(value);}, "*enter letters only");
jQuery.validator.addMethod("uidcheck", function(value, element) 
		{
		return this.optional(element) || /^[U][0-9]+$/i.test(value);}, "*enter number");

$(document).ready(function() {
	$("#defForm").validate({
		rules : {
			uid : {
				required : true,
				uidcheck:true,
				 minlength:5,
				 maxlength:5

			},
			name : {
				required : true,
				letter:true,
				 minlength:5
	              			},
			rating : {
				required : true,
				  minlength:1,
				number:true

			},
			accrstatus : {
				required : true,
				  minlength:1,
				number:true
			},
			bankno : {
				required : true,
				no:true
				

			},
			acc_no : {
				required : true,
				number:true

			},
			dpd : {
				required : true,
				number:true

			},
			comment : {
				required : true

			},
			dot : {
				required : true

			}
		},

		messages : {
			uid : {
				required : "   Mandatory field",
			uidcheck:"Invalid userId",
			 minlength:"  Atleast 5 characters",
			 maxlength:"  Not more than 5 characters"

			},
			name : {
				required : "   Mandatory field",
				letter:" Alphabets only",
				 minlength:" length should be 5",
	          
			},
			rating : {
				required : "   Mandatory field",
				 minlength:"  Enter valid Rating",
				number:"  Numbers only allowed"

			},
			accrstatus : {
				required : "   Mandatory field",
				 minlength:"  Enter valid Rating",
				number:"  Numbers only allowed"
			},
			bankno : {
				required : "   Mandatory field",
				check:"Valid Bank Number",
				
			},
			acc_no : {
				required : "   Mandatory field",
				number:"  Numbers only"

			},
			dpd : {
				required : "   Mandatory field",
				number:"  letters not allowed"

			},
			comment : {
				required : "   Mandatory field",

			},
			dot : {
				required : "   Mandatory field",

			},
		},

		submitHandler : function(form) {
			form.submit();
		}
	});
});

