﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessObject
{

    //User
    public class UserRegistrationBO
    {
        private string U_Fname;

        public string UFname
        {
            get { return U_Fname; }
            set { U_Fname = value; }
        }

        
        private string U_Lname;

        public string ULname
        {
            get { return U_Lname; }
            set { U_Lname = value; }
        }
        private string U_Password;

        public string UPassword
        {
            get { return U_Password; }
            set { U_Password = value; }
        }
        private int U_Age;

        public int UAge
        {
            get { return U_Age; }
            set { U_Age = value; }
        }
        private string U_gender;

        public string Ugender
        {
            get { return U_gender; }
            set { U_gender = value; }
        }
        private string U_contact;

        public string Ucontact
        {
            get { return U_contact; }
            set { U_contact = value; }
        }
        private string U_email;

        public string Uemail
        {
            get { return U_email; }
            set { U_email = value; }
        }
        private string U_address;

        public string Uaddress
        {
            get { return U_address; }
            set { U_address = value; }
        }
        private string U_state;

        public string Ustate
        {
            get { return U_state; }
            set { U_state = value; }
        }
        private string U_city;

        public string Ucity
        {
            get { return U_city; }
            set { U_city = value; }
        }
        private int U_zip;

        public int Uzip
        {
            get { return U_zip; }
            set { U_zip = value; }
        }
 

    }
    //Admin

    public class AdminRegistrationBO
    {
        private string A_Fname;

        public string AFname
        {
         get { return A_Fname; }
        set { A_Fname = value; }
        }
       

        private string A_Lname;

        public string ALname
        {
          get { return A_Lname; }
          set { A_Lname = value; }
        }

        
        private string A_Password;

        public string APassword
        {
          get { return A_Password; }
          set { A_Password = value; }
        }

       
        private int A_Age;

        public int AAge
        {
          get { return A_Age; }
          set { A_Age = value; }
        }

        
        private string A_gender;

        public string Agender
        {
          get { return A_gender; }
          set { A_gender = value; }
        }

       
        private string A_contact;

            public string Acontact
            {
              get { return A_contact; }
              set { A_contact = value; }
            }

      
        private string A_email;

            public string Aemail
            {
              get { return A_email; }
              set { A_email = value; }
            }

        
        private string A_address;

        public string Aaddress
        {
          get { return A_address; }
          set { A_address = value; }
        }


        private string A_state;

        public string Astate
        {
            get { return A_state; }
            set { A_state = value; }
        }


        private string A_city;

        public string Acity
        {
            get { return A_city; }
            set { A_city = value; }
        }


        private int A_zip;

        public int Azip
        {
            get { return A_zip; }
            set { A_zip = value; }
        }

     
 
    }
    //USER Login 

    public class userLoginBO
    {
        private string U_Name;

        public string UName
        {
            get { return U_Name; }
            set { U_Name = value; }
        }
        private string U_logPass;

        public string UlogPass
        {
            get { return U_logPass; }
            set { U_logPass = value; }
        }
    }
    //admin login

    public class adminLoginBO
    {
        private string A_Name;

        public string AName
        {
            get { return A_Name; }
            set { A_Name = value; }
        }
        private string A_logPass;

        public string AlogPass
        {
            get { return A_logPass; }
            set { A_logPass = value; }
        }
    }

}
