﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace AIP
{
    public partial class Login : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;
        string constr = ConfigurationManager.ConnectionStrings["AIP_DataBase"].ConnectionString;

        public string strloginid;
        public string strstatus;
        public string strcomment;

        protected void Page_Load1(object sender, EventArgs e)
        {

        }
        //public void Bind_loginid()
        //{

        //    try
        //    {
        //        con.Open();
        //        SqlCommand com = new SqlCommand("SELECT * FROM Borrowerdetails WHERE Default_Status = '" + status + "'", con);
        //        SqlDataReader dr = com.ExecuteReader();
        //        ddcustid.DataSource = dr;
        //        ddcustid.Items.Clear();
        //        ddcustid.Items.Add("Please select item");
        //        //ddcustid.DataTextField = "country_name";
        //        ddcustid.DataValueField = "Login_Id";
        //        ddcustid.DataBind();
        //        con.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }

        //}   
        protected void BindData_borrower()
        {
            // string login_id = Session["User_Id"].ToString();
            con = new SqlConnection(constr);      
            try
            {
                con.Open();
                DataTable FromTable = new DataTable();
                SqlDataAdapter adp = new SqlDataAdapter();
                adp.SelectCommand = new SqlCommand("SELECT * FROM Borrowerdetails", con);
                DataSet ds = new DataSet();
                adp.Fill(ds);
                FromTable = ds.Tables[0];
                if (FromTable.Rows.Count > 0)
                {
                    borrowerGridView.DataSource = FromTable;
                    borrowerGridView.DataBind();
                }
                else
                {
                    FromTable.Rows.Add(FromTable.NewRow());
                    borrowerGridView.DataSource = FromTable;
                    borrowerGridView.DataBind();
                    int TotalColumns = borrowerGridView.Rows[0].Cells.Count;
                    borrowerGridView.Rows[0].Cells.Clear();
                    borrowerGridView.Rows[0].Cells.Add(new TableCell());
                    borrowerGridView.Rows[0].Cells[0].ColumnSpan = TotalColumns;
                    borrowerGridView.Rows[0].Cells[0].Text = "No records Found";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
                
        }

        protected void Imgbtnborrower_Click(object sender, ImageClickEventArgs e)
        {
            MultiView1.SetActiveView(View1);
            BindData_borrower();
            Bind_ddautodefaulter();
        }

        protected void BindData_autodefault()
        {
            // string login_id = Session["User_Id"].ToString();
            con = new SqlConnection(constr);
            try
            {
                string status = "Auto_Default";
                DataSet ds = new DataSet();
                DataTable FromTable = new DataTable();

                SqlDataAdapter adp = new SqlDataAdapter("SELECT * FROM Borrowerdetails WHERE Default_Status = '" + status + "'", con);
                adp.Fill(ds);
                FromTable = ds.Tables[0];
                if (FromTable.Rows.Count > 0)
                {
                    autodefaultgridview.DataSource = FromTable;
                    autodefaultgridview.DataBind();
                }
                else
                {
                    FromTable.Rows.Add(FromTable.NewRow());
                    autodefaultgridview.DataSource = FromTable;
                    autodefaultgridview.DataBind();
                    int TotalColumns = borrowerGridView.Rows[0].Cells.Count;
                    autodefaultgridview.Rows[0].Cells.Clear();
                    autodefaultgridview.Rows[0].Cells.Add(new TableCell());
                    autodefaultgridview.Rows[0].Cells[0].ColumnSpan = TotalColumns;
                    autodefaultgridview.Rows[0].Cells[0].Text = "No records Found";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        protected void Imgbtnautodefault_Click(object sender, ImageClickEventArgs e)
        {
            //Response.Redirect("~/AutoDefaultsPage.aspx", false);
            MultiView1.SetActiveView(View2);
            BindData_autodefault();
            Bind_ddautodefaulter();
        }

        protected void BindData_manual()
        {

            // string login_id = Session["User_Id"].ToString();
            con = new SqlConnection(constr);
            try
            {
            con.Open();
            string status = "Manual_Default";
            DataSet ds = new DataSet();
            DataTable FromTable = new DataTable();

            SqlDataAdapter adp = new SqlDataAdapter("SELECT * FROM Borrowerdetails WHERE Default_Status = '" + status + "'", con);
            adp.Fill(ds);
            FromTable = ds.Tables[0];
            if (FromTable.Rows.Count > 0)
            {
                mannualgridview.DataSource = FromTable;
                mannualgridview.DataBind();
            }
            else
            {
                FromTable.Rows.Add(FromTable.NewRow());
                mannualgridview.DataSource = FromTable;
                mannualgridview.DataBind();
                int TotalColumns = borrowerGridView.Rows[0].Cells.Count;
                mannualgridview.Rows[0].Cells.Clear();
                mannualgridview.Rows[0].Cells.Add(new TableCell());
                mannualgridview.Rows[0].Cells[0].ColumnSpan = TotalColumns;
                mannualgridview.Rows[0].Cells[0].Text = "No records Found";
            }
         }
             catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        protected void Imgbtnmannualdefault_Click(object sender, ImageClickEventArgs e)
        {
            MultiView1.SetActiveView(View3);
            BindData_manual();
            Bind_ddmannualdefaulter();
        }

        protected void BindData_redefault()
        {

            // string login_id = Session["User_Id"].ToString();
            con = new SqlConnection(constr);
            try
            {
                string status = "Re_Default";
                DataSet ds = new DataSet();
                DataTable FromTable = new DataTable();

                SqlDataAdapter adp = new SqlDataAdapter("SELECT * FROM Borrowerdetails WHERE Default_Status = '" + status + "'", con);
                adp.Fill(ds);
                FromTable = ds.Tables[0];
                if (FromTable.Rows.Count > 0)
                {
                    redefaultgridview.DataSource = FromTable;
                    redefaultgridview.DataBind();
                }
                else
                {
                    FromTable.Rows.Add(FromTable.NewRow());
                    redefaultgridview.DataSource = FromTable;
                    redefaultgridview.DataBind();
                    int TotalColumns = borrowerGridView.Rows[0].Cells.Count;
                    redefaultgridview.Rows[0].Cells.Clear();
                    redefaultgridview.Rows[0].Cells.Add(new TableCell());
                    redefaultgridview.Rows[0].Cells[0].ColumnSpan = TotalColumns;
                    redefaultgridview.Rows[0].Cells[0].Text = "No records Found";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        protected void Imgbtnredefault_Click(object sender, ImageClickEventArgs e)
        {
            MultiView1.SetActiveView(View4);
            BindData_redefault();
            Bind_ddredefaulter();
        }

        public void Bind_ddautodefaulter()
        {
            con = new SqlConnection(constr);
            
            try
            {
                string status = "Auto_Default";
                con.Open();
                SqlCommand com = new SqlCommand("Select Login_Id from Borrowerdetails where Default_Status='" + status + "'", con);
                SqlDataReader dr = com.ExecuteReader();
                DropDownList1_auto.DataSource = dr;
                DropDownList1_auto.Items.Clear();
                DropDownList1_auto.Items.Add("Please select item");
                DropDownList1_auto.DataTextField = "Login_Id";
                DropDownList1_auto.DataValueField = "Login_Id";
                DropDownList1_auto.DataBind();
                strloginid = DropDownList1_auto.Text;
                strstatus = DropDownList2_auto.Text;
                strcomment = TextBox1_auto.Text;
                //SqlCommand com1 = new SqlCommand("update Borreowerdeftails Default_status ,Comment")
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }
        public void Bind_ddmannualdefaulter()
        {
            con = new SqlConnection(constr);
            
            try
            {
                string status = "Manual_Default";
                con.Open();
                SqlCommand com = new SqlCommand("Select Login_Id from Borrowerdetails where Default_Status='" + status + "'", con);
                SqlDataReader dr = com.ExecuteReader();
                ddloginid_mannual.DataSource = dr;
                ddloginid_mannual.Items.Clear();
                ddloginid_mannual.Items.Add("Please select item");
                //ddloginid.DataTextField = "ct_name";
                ddloginid_mannual.DataValueField = "Login_Id";
                ddloginid_mannual.DataBind();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }
        public void Bind_ddredefaulter()
        {
            con = new SqlConnection(constr);            
            try
            {
                string status = "Re_Default";
                con.Open();
                SqlCommand com = new SqlCommand("Select Login_Id from Borrowerdetails where Default_Status='" + status + "'", con);
                SqlDataReader dr = com.ExecuteReader();
                DropDownList1_redefault.DataSource = dr;
                DropDownList1_redefault.Items.Clear();
                DropDownList1_redefault.Items.Add("Please select item");
                //ddloginid.DataTextField = "ct_name";
                DropDownList1_redefault.DataValueField = "Login_Id";
                DropDownList1_redefault.DataBind();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void Bind_ddManualdefaulter()
        {
            con = new SqlConnection(constr);
            try
            {
                string status1 = "Manual Default";
                con.Open();
                SqlCommand com = new SqlCommand("Select Login_Id from Borrowerdetails where Default_Status='" + status1 + "'", con);
                SqlDataReader dr = com.ExecuteReader();
                DropDownList1_redefault.DataSource = dr;
                DropDownList1_redefault.Items.Clear();
                DropDownList1_redefault.Items.Add("Please select item");
                //ddloginid.DataTextField = "ct_name";
                DropDownList1_redefault.DataValueField = "Login_Id";
                DropDownList1_redefault.DataBind();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        protected void ddstatus_mannual_SelectedIndexChanged(object sender, EventArgs e)
        {
            Bind_ddManualdefaulter();
        }

        protected void DropDownList2_auto_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void ImageButton1_auto_Click(object sender, ImageClickEventArgs e)
        {
          //  MessageBox.Show(strcomment);

            try
            {
                con = new SqlConnection(constr);
                con.Open();
                SqlCommand com1 = new SqlCommand("sp_update_admin", con);
                com1.CommandType = System.Data.CommandType.StoredProcedure;
                com1.Parameters.AddWithValue("@loginid", DropDownList1_auto.Text.Trim());
                com1.Parameters.AddWithValue("@default_status", DropDownList2_auto.Text.Trim());
                com1.Parameters.AddWithValue("@Comment", TextBox1_auto.Text.Trim());


                //com = new SqlCommand("update Borrowerdetails set Default_Status='" + DropDownList2_auto.Text.Trim()+ "',Comment='" + TextBox1_auto.Text.Trim() + "' where Login_Id='" + DropDownList1_auto.Text.Trim()+ "'", con);
                com1.ExecuteNonQuery();
                MessageBox.Show("Record Updated");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

    
        protected void ImageButton2_mannual_Click(object sender, ImageClickEventArgs e)
        {

            try
            {
                con = new SqlConnection(constr);
                con.Open();
                SqlCommand com1 = new SqlCommand("sp_update_admin", con);
                com1.CommandType = System.Data.CommandType.StoredProcedure;
                com1.Parameters.AddWithValue("@loginid", ddloginid_mannual.Text.Trim());
                com1.Parameters.AddWithValue("@default_status", ddstatus_mannual.Text.Trim());
                com1.Parameters.AddWithValue("@Comment", TextBox2_mannual.Text.Trim());
                //com = new SqlCommand("update Borrowerdetails set Default_Status='" + DropDownList2_auto.Text.Trim()+ "',Comment='" + TextBox1_auto.Text.Trim() + "' where Login_Id='" + DropDownList1_auto.Text.Trim()+ "'", con);
                com1.ExecuteNonQuery();
                MessageBox.Show("Record Updated");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }


        protected void ImageButton1_redefault_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                con = new SqlConnection(constr);
                con.Open();
                SqlCommand com1 = new SqlCommand("sp_update_admin", con);
                com1.CommandType = System.Data.CommandType.StoredProcedure;
                com1.Parameters.AddWithValue("@loginid", DropDownList1_redefault.Text.Trim());
                com1.Parameters.AddWithValue("@default_status", DropDownList2_redefault.Text.Trim());
                com1.Parameters.AddWithValue("@Comment", TextBox1_redefault.Text.Trim());
                //com = new SqlCommand("update Borrowerdetails set Default_Status='" + DropDownList2_auto.Text.Trim()+ "',Comment='" + TextBox1_auto.Text.Trim() + "' where Login_Id='" + DropDownList1_auto.Text.Trim()+ "'", con);
                com1.ExecuteNonQuery();
                MessageBox.Show("Record Updated");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        protected void Iblogout_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/AIP_Home.aspx");
        }

        


    }


}