﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AIP
{
    public partial class AIP_Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }
       

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            iblogin.Visible = true;
            ibregister.Visible = true;
            ibuserlogin.Visible = false;
            ibuserreg.Visible = false;
        }

        protected void ibregister_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/admin_registration.aspx");
        }

        protected void ibuserreg_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/user_registration.aspx");
        }

        protected void ibuser_Click(object sender, ImageClickEventArgs e)
        {
            ibregister.Visible = false;
            iblogin.Visible = false;
            ibuserlogin.Visible = true;
            ibuserreg.Visible = true;

        }

        protected void iblogin_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/Admin_Login.aspx");
        }

        protected void ibuserlogin_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/User_Login.aspx");
        }

        
    }
}