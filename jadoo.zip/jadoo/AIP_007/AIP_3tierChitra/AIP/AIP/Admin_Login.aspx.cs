﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BussinessObject;
using Bussinesslogic;
using System.Windows.Forms;

namespace AIP
{
    public partial class Login : System.Web.UI.Page
    {
        adminLoginBO adminBO = new adminLoginBO();
        UsingBL adminBl = new UsingBL();


        /*---Admin login Page Load---*/
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None; 

        }

        /*---Admin Login Buttton ---*/
        protected void ImgBtn_login_Click(object sender, ImageClickEventArgs e)
        {
             adminBO.AName = TextBox_loginid.Text;
            adminBO.AlogPass = TextBox_pwd.Text;

            int status = adminBl.AdminLoginBL(adminBO);
            if (status > 0)
            {
                Session["User_Id"] = adminBO.AName;
                Response.Redirect("~/Admin_home.aspx");
            }
            else
            {
                MessageBox.Show("Invalid Password");
            }
           
          
        }

      }
  }
