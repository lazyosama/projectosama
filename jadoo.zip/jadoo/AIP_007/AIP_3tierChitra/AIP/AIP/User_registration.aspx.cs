﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using BussinessObject;
using Bussinesslogic;

namespace AIP
{
    public partial class User_registration : System.Web.UI.Page
    {

        UserRegistrationBO userBO = new UserRegistrationBO();
        UsingBL userBl = new UsingBL();
        string gender;
        SqlConnection con;
        
        /*----------Method for binding User State---------*/
        public void Bind_ddlState()
        {
            string constr = ConfigurationManager.ConnectionStrings["AIP_DataBase"].ConnectionString;
            con = new SqlConnection(constr);

            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("Select st_id,st_name from Aip_state1", con);
                SqlDataReader dr = com.ExecuteReader();
                ddUserState.DataSource = dr;
                ddUserState.Items.Clear();
                ddUserState.Items.Add("Please select item");
                ddUserState.DataTextField = "st_name";
                ddUserState.DataValueField = "st_id";
                ddUserState.DataBind();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }
        /*--------Method for binding  User City----------*/
        public void Bind_ddlCity()
        {
            string constr = ConfigurationManager.ConnectionStrings["AIP_DataBase"].ConnectionString;
            con = new SqlConnection(constr);
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("Select ct_id,ct_name from aip_city1 where st_id='" + ddUserState.SelectedValue + "'", con);
                SqlDataReader dr = com.ExecuteReader();
                ddUserCity.DataSource = dr;
                ddUserCity.Items.Clear();
                ddUserCity.Items.Add("Please select item");
                ddUserCity.DataTextField = "ct_name";
                ddUserCity.DataValueField = "ct_id";
                ddUserCity.DataBind();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }
        /*--------Binding Method for User Zip------------*/
        public void Bind_ddlZip()
        {
            string constr = ConfigurationManager.ConnectionStrings["AIP_DataBase"].ConnectionString;
            con = new SqlConnection(constr);
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("Select zip_code from aip_zip1 where ct_id='" + ddUserCity.SelectedValue + "'", con);
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    //ddUserCity.DataSource = dr;
                    // ddUserCity.Items.Clear();
                    // ddUserCity.Items.Add("Please select item");
                    //ddUserCity.DataTextField = "zip_code";
                    //ddUserCity.DataValueField = "zip_id";
                    // ddUserCity.DataBind();

                    txtUserZip.Text = dr[0].ToString();
                }
                dr.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        /*-------Page Load for usre Registraion-------*/
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Bind_ddlState();
            }
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            gender = "";
            if (Rbluser.SelectedIndex == 0)
            {
                gender = " Male";
            }
            else
            {
                gender = "Female";
            }
        }



      /*-------User Reset button-----*/
        protected void ibUserReset_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/User_registration.aspx");
        }


        /*-----User Register Button-----*/
         protected void ibUserRegister_Click(object sender, ImageClickEventArgs e)
        {
           int a= Convert.ToInt32(txtUserAge.Text);
            userBO.UFname = txtUserFname.Text;
            userBO.ULname = txtUserLname.Text;
            userBO.Uemail = txtUserEmail.Text;
            userBO.Uaddress = txtUserAdd.Text;
            userBO.Ugender = gender;
            userBO.Ustate = ddUserState.Text;
            userBO.Ucity = ddUserCity.Text;
            userBO.UAge = Convert.ToInt32(txtUserAge.Text);
            userBO.Ucontact = txtUserCon.Text;
            userBO.UPassword = txtUserPass.Text;
            userBO.Uzip = Convert.ToInt32(txtUserZip.Text);
            if (a <= 21)
            {
                MessageBox.Show("Age should be greater than 21.Sorry! you cannot Register ");
                Response.Redirect("~/AIP_Home.aspx");
            }

            int status = userBl.SaveUserRegistrationBL(userBO);
            if (status > 0)
            {
                Response.Redirect("~/AIP_Home.aspx");
            }
            else
            {
                MessageBox.Show("Not Registered Please try again");
            }

        }
        
        /*--------Drop Down Button for State------*/
        protected void ddUserState_SelectedIndexChanged(object sender, EventArgs e)
        {
            Bind_ddlCity();

        }
       
        /*---- Drop down Button for City-----*/
        protected void ddUserCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            Bind_ddlZip();
        }

       
    }
}