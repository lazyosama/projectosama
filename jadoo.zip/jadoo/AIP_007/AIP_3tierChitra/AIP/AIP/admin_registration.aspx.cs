﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Configuration;
using BussinessObject;
using Bussinesslogic;


namespace AIP
{
    public partial class admin_registration : System.Web.UI.Page
    {
        AdminRegistrationBO AdminBO = new AdminRegistrationBO();
        UsingBL AdminBl = new UsingBL();
        SqlConnection con;
        string gender;


        /*-----Bind Method for admin State-----*/
        public void Bind_ddlState()
        {
            string constr = ConfigurationManager.ConnectionStrings["AIP_DataBase"].ConnectionString;
            con = new SqlConnection(constr);
            
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("Select st_id,st_name from Aip_state1", con);
                SqlDataReader dr = com.ExecuteReader();
                ddState.DataSource = dr;
                ddState.Items.Clear();
                ddState.Items.Add("Please select item");
                ddState.DataTextField = "st_name";
                ddState.DataValueField = "st_id";
                ddState.DataBind();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }
        /*-----Bind Method for admin City-----*/
        public void Bind_ddlCity()
        {
            string constr = ConfigurationManager.ConnectionStrings["AIP_DataBase"].ConnectionString;
            con = new SqlConnection(constr);
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("Select ct_id,ct_name from aip_city1 where st_id='" + ddState.SelectedValue + "'", con);
                SqlDataReader dr = com.ExecuteReader();
                ddCity.DataSource = dr;
                ddCity.Items.Clear();
                ddCity.Items.Add("Please select item");
                ddCity.DataTextField = "ct_name";
                ddCity.DataValueField = "ct_id";
                ddCity.DataBind();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        /*-----Bind Method for admin Zip-----*/
        public void Bind_ddlZip()
        {
            string constr = ConfigurationManager.ConnectionStrings["AIP_DataBase"].ConnectionString;
            con = new SqlConnection(constr);
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("Select zip_code from aip_zip1 where ct_id='" + ddCity.SelectedValue + "'", con);
                SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    //ddUserCity.DataSource = dr;
                    // ddUserCity.Items.Clear();
                    // ddUserCity.Items.Add("Please select item");
                    //ddUserCity.DataTextField = "zip_code";
                    //ddUserCity.DataValueField = "zip_id";
                    // ddUserCity.DataBind();

                    txtZip.Text = dr[0].ToString();
                }
                dr.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        /*-----Admin Page Load-----*/
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            if (!IsPostBack)
            {
                Bind_ddlState();
            }
            gender = "";
            if (RblAdmin.SelectedIndex == 0)
            {
                gender = " Male";
            }
            else
            {
                gender = "Female";
            }

        }

        /*-----Admin Reset Button-----*/
        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/admin_registration.aspx");

        }

       

        /*-----Admin Register Button-----*/
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

            int a = Convert.ToInt32(txtAge.Text);

            AdminBO.Aaddress = txtAdd.Text;
            AdminBO.AAge = Convert.ToInt32(txtAge.Text);
            AdminBO.Acity = ddCity.Text;
            AdminBO.Acontact = txtcontact.Text;
            AdminBO.Aemail = txtEmail.Text;
            AdminBO.AFname = txtFname.Text;
            AdminBO.Agender = gender;
            AdminBO.ALname = txtLname.Text;
            AdminBO.APassword = txtPass.Text;
            AdminBO.Astate = ddState.Text;
            AdminBO.Azip = Convert.ToInt32(txtZip.Text);
            if (a <= 24)
            {
                MessageBox.Show("Age should be greater than 24.Sorry! you cannot Register ");
                Response.Redirect("~/AIP_Home.aspx");
            }
            int status = AdminBl.SaveAdminRegistrationBL(AdminBO);
            if (status > 0)
            {
                Response.Redirect("~/AIP_Home.aspx");
            }
            else
            {
                MessageBox.Show("Not Registered Please try again");
            }


          

           
        }
        /*-----Drop Down Button for State-----*/
        protected void ddState_SelectedIndexChanged(object sender, EventArgs e)
        {
            Bind_ddlCity();
        }

        /*-----Drop Down Button for City-----*/
        protected void ddCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            Bind_ddlZip();
        }

      
        
    }
}