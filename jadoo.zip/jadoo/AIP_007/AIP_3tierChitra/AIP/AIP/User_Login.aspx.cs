﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using BussinessObject;
using Bussinesslogic;
namespace AIP
{
    public partial class User_Login : System.Web.UI.Page
    {
        userLoginBO userBO = new userLoginBO();
        UsingBL userBl = new UsingBL();
        
        
        /*------User login Page Load-------*/
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;

        }

        /*------User Login button-------*/
        protected void ibuserlogin_login_Click(object sender, ImageClickEventArgs e)
        {

            userBO.UName = txt_userlogin_id.Text;
            userBO.UlogPass = txtuserlogin_pass.Text;

            int status = userBl.UserLoginBL(userBO);
            if (status > 0)
            {
                Session["User_Id"] = userBO.UName;
                Response.Redirect("~/User_after_login.aspx");
            }
            else
            {
                MessageBox.Show("Invalid Password");
            }
           
          
        }

       
    }
}