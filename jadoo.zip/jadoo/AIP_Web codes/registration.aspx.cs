﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


public partial class registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        LoginIdTextBox.Text = string.Empty;
        PasswordTextBox.Text = string.Empty;
        FirstNameTextBox.Text = string.Empty;
        LastNameTextBox.Text = string.Empty;
        AgeTextBox.Text = string.Empty;
        ContactNumberTextBox.Text = string.Empty;
        EmailTextBox.Text = string.Empty;
        AddressTextBox.Text = string.Empty;
        ZipCodeTextBox.Text = string.Empty;
        ReEnterPasswordTextBox.Text = string.Empty;
        AgeComparatorTextBox.Text = string.Empty;

    }
    
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    { 

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {

        Registration_businesslogiclayer.user u = new Registration_businesslogiclayer.user();
    
        u._LoginId = LoginIdTextBox.Text;
        
        u._Role = RoleRadioButtonList.Text;
        Response.Write(RoleRadioButtonList.Text);
       

        u._Password = PasswordTextBox.Text;
        u._FirstName = FirstNameTextBox.Text;
        u._LastName = LastNameTextBox.Text;



        u._Age = Convert.ToInt32(AgeTextBox.Text);

        if (MaleRadioButton.Checked)
        {
            u._Gender = MaleRadioButton.Text;
        }
        else if (FemaleRadioButton.Checked)
        {
            u._Gender = FemaleRadioButton.Text;
        }
        

        u._ContactNo =Convert.ToDouble(ContactNumberTextBox.Text);
        u._EmailId = EmailTextBox.Text;
        u._Address = AddressTextBox.Text;
        u._CityName = CityDropDownList.Text;
        u._ZipCode = Convert.ToInt32(ZipCodeTextBox.Text);



        Registration_businesslogiclayer.Registration_bal regiBalObj = new Registration_businesslogiclayer.Registration_bal();

        Session["Login_Id"]=regiBalObj.Generate_LoginId(u);
        //bool err = b.register(u);
        bool err = regiBalObj.register(u);
        if (AgeCompareValidator.IsValid  &&  err  == true)
        {

           //Response.Write("<script language='javascript'> alert('Congratulations!!!! You have successfully registered.Your Login ID is'"+u._LoginId+"');</script>");
           Response.Redirect("AfterRegistration.aspx");
        }
        else
        {       
            Response.Write("<script language='javascript'> alert('Registration Failed')");
        }
       
    }
    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {

        if (RoleRadioButtonList.Text=="Admin")
        {
            AgeComparatorTextBox.Text = "24";
        }
        else if (RoleRadioButtonList.Text == "User")
        {
            AgeComparatorTextBox.Text = "21";
        }
    }
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void CustomValidator1_ServerValidate1(object source, ServerValidateEventArgs args)
    {
    
    
    }
      
  
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
       
    }
    protected void AgeComparatorTextBox_TextChanged(object sender, EventArgs e)
    {

    }
    protected void AgeComparatorTextBox_TextChanged1(object sender, EventArgs e)
    {

    }
}