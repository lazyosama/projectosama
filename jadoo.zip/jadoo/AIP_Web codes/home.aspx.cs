﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



public partial class hom2:System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["username"] = "";
    }
    protected void Button1_Click(object sender, EventArgs e) 
    {
        Session["user_role"] = "Admin";
        Response.Redirect("~/login.aspx");
    }

    //public int Button1_Click1(object sender, EventArgs e)
    //{
    //    return 1;
    //}
    //public int Button2_Click(object sender, EventArgs e)
    //{
    //    return 2;
    //}
    protected void Button2_Click(object sender, EventArgs e)
    {

        Session["user_role"] = "User";
        Response.Redirect("~/Login.aspx");

    }
}