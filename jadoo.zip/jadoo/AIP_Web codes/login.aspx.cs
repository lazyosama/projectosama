﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using BAL_Login;

public partial class Login : System.Web.UI.Page
{
  

    LoginBal login = new LoginBal();
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["username"] = "";
        
       
    }


    protected void LinkButton1_Click(object sender, EventArgs e)
    {
       
    }


    protected void LinkButton1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("registration.aspx");
    }
    /// <summary>
    /// The button click event will verify the credentials entered by the user
    /// </summary>
 
    protected void Button1_Click(object sender, EventArgs e) 
    {
        string LoginId = LoginIdTextbox.Text;
        string Password = PasswordTextbox.Text;
        int Login_Check = login.LoginValidation(LoginId, Password, Session["user_role"].ToString());
      
        if (Login_Check == 1 )
        {
            Session["username"] = LoginId;
            Response.Redirect("AdminView.aspx");
        }

        else if (Login_Check == 2)
        {
            Session["username"] = LoginId;

            Response.Redirect("User.aspx");
        }
        else 
        {
            Response.Write("<script language='javascript'> alert('Invalid LoginID or Password. Please re-enter');</script>");
        }
       
    }
    protected void ForgotPasswordLinkButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("ForgotPassword.aspx");
    }
}