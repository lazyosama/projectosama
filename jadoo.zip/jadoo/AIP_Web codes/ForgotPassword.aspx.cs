﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ForgotPassword_BAL;

public partial class ForgotPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    /// <summary>
    /// the click event will allow to reset the password
    /// </summary>
  
    protected void SubmitForgotPassword_Click(object sender, EventArgs e)
    {
        ForgotPasswordBAL ForgotPassBAL_Obj = new ForgotPasswordBAL();


        if (ForgotPassBAL_Obj.get_Username(ForgotPasswordLoginIdTb.Text, ForgotPasswordEmailIdTb.Text))
        {
            string ResetPassword_Check = ForgotPassBAL_Obj.reset_Password(ForgotPasswordLoginIdTb.Text, NewPasswordTextBox.Text);
            if (ResetPassword_Check == "Reset Password Successfull")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                "alert('Reset Password is Successfull : Please Login with the New Password');window.location ='login.aspx';", true);

            }
            else
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
              "alert('Reset Password Unsuccessfull : Please Try Again');window.location ='ForgotPassword.aspx';", true);

        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                    "alert('Wrong Credentials: Please Re-Enter');window.location ='ForgotPassword.aspx';", true);
        }

    }
}