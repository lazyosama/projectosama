﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.IO;

using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;


public partial class User : System.Web.UI.Page
{
   
      public string GetConnection()
    {
        return ConfigurationManager.ConnectionStrings["mycon"].ConnectionString.ToString();
    }
    /// <summary>
    /// Page Load will check the session variable and return the default status of the user logged in
    /// </summary>
  

    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (Session["username"].ToString() == "")
        {
            Response.Redirect("~/login.aspx");
        }
        else
        {
            SqlConnection con = new SqlConnection(GetConnection());
            con.Open();
            SqlCommand cmd = new SqlCommand("select DefaultStatus from Borower where LoginId='" + Session["username"] + "'", con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            DefaultStatusLabel.Text = reader["DefaultStatus"].ToString();
            con.Close();
        }

        Label1.Text = Session["username"].ToString();

    }


  
        
   
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }

    /// <summary>
    /// download buton click event will download pdf of user transactions
    /// </summary>

    protected void DownloadButton_Click(object sender, EventArgs e)
    {
       

        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition",
         "attachment;filename=UserTransactions.pdf");
        Response.Cache.SetCacheability(HttpCacheability.Public);
        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        UserTransactionGridView.AllowPaging = false;
        UserTransactionGridView.DataBind();
        UserTransactionGridView.RenderControl(hw);
        UserTransactionGridView.HeaderRow.Enabled = true;
        UserTransactionGridView.HeaderRow.Style.Add("width", "50%");
        UserTransactionGridView.HeaderRow.Style.Add("font-size", "10px");
        UserTransactionGridView.Style.Add("text-decoration", "none");
        UserTransactionGridView.Style.Add("font-family", "Arial, Helvetica, sans-serif;");
        UserTransactionGridView.Style.Add("font-size", "8px"); 
        StringReader sr = new StringReader(sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        htmlparser.Parse(sr);
        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        return;
    }
}