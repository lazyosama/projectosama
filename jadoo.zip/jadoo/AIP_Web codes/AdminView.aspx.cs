﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
public partial class AdminView : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (!IsPostBack)
        //{
        //    gvbind();
        //}


        if (Session["username"].ToString() == "")
        {
            Response.Redirect("~/login.aspx");
        }

       Label2.Text=Session["username"].ToString();

    }


    public string GetConnection()
    {
        return ConfigurationManager.ConnectionStrings["mycon"].ConnectionString.ToString();
    }
    

    //Auto Default Edit and Update
    /// <summary>
    /// gvbind method to bind the gridview with database
    /// GridView1_RowEditing method will allow editing
    /// GridView1_RowUpdating method will allow updating the edited columns 
    /// </summary>
    protected void gvbind()
    {
        SqlConnection con = new SqlConnection(GetConnection());
        con.Open();
        SqlCommand cmd = new SqlCommand("Select * from Borower where BorrowerRating>=8 and AccrualStatus between 2 and 5", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
       
        gvbind();
    }


    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        

        try
        {
            SqlConnection con = new SqlConnection(GetConnection());
            //int userid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value.ToString());
            GridViewRow row = (GridViewRow)GridView1.Rows[e.RowIndex];


            //DropDownList textName = ((DropDownList)row.Cells[6].Controls[0]);
            DropDownList textName = (DropDownList)row.FindControl("DropDownList1");
            //   TextBox textName = CType((DropDownList)row.Cells[6].Controls[0], System.Web.UI.WebControls.TextBox);
            TextBox textc = (TextBox)row.Cells[7].Controls[0];


           
            con.Open();
            TextBox text1 = (TextBox)(row.Cells[0].Controls[0]);
            GridView1.EditIndex = -1;
            SqlCommand cmd = new SqlCommand("update Borower set DefaultStatus='" + textName.Text +
                "', Comment='" + textc.Text + "' where borrowername = '" + text1.Text + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            gvbind();
            Response.Write("<script language='javascript'> alert('User Details Updated successfully.');</script>");
        }
        catch (Exception ex)
        {
            Response.Write("<script language='javascript'> alert(' "+ ex+" ');</script>");
        }
        
    }

    
    
    //Manual Default Edit and Update
    /// <summary>
    /// gvbind2 method to bind the gridview with database
    /// GridView2_RowEditing method will allow editing
    /// GridView2_RowUpdating method will allow updating the edited columns 
    /// </summary>

    protected void gvbind2()
    {
        SqlConnection con = new SqlConnection(GetConnection());
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from borower join Transactions on Borower.LoginId=Transactions.LoginId where Borower.BorrowerRating between 5 and 7 and Borower.AccrualStatus=1 or Borower.AccrualStatus=6 or Borower.AccrualStatus=7 and Transactions.DateOfTransaction>= DATEADD(DAY, -90, GETDATE()) ", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView2.DataSource = ds;
            GridView2.DataBind();
        }

    }

    protected void GridView2_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView2.EditIndex = e.NewEditIndex;

        gvbind2();
    }


    protected void GridView2_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(GetConnection());

            GridViewRow row = (GridViewRow)GridView2.Rows[e.RowIndex];


            DropDownList textName = (DropDownList)row.FindControl("DropDownList2");

            TextBox textc = (TextBox)row.Cells[7].Controls[0];


            GridView2.EditIndex = -1;
            con.Open();
            TextBox text1 = (TextBox)(row.Cells[0].Controls[0]);

            SqlCommand cmd = new SqlCommand("update Borower set DefaultStatus='" + textName.Text +
                "', Comment='" + textc.Text + "' where borrowername = '" + text1.Text + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            gvbind2();
            Response.Write("<script language='javascript'> alert('User Details Updated successfully.');</script>");
        }
        catch (Exception)
        {
            Response.Write("<script language='javascript'> alert('Updation Failed.');</script>");
        }
    }
  

    //Re-Defaults
    
    //protected void gvbind3()
    //{
    //    SqlConnection con = new SqlConnection(GetConnection());
    //    con.Open();
    //    SqlCommand cmd = new SqlCommand("select * from borower join Transactions on Borower.LoginId=Transactions.LoginId where Transactions.DateOfTransaction>= DATEADD(DAY, -180, GETDATE()) ", con);
    //    SqlDataAdapter da = new SqlDataAdapter(cmd);
    //    DataSet ds = new DataSet();
    //    da.Fill(ds);
    //    con.Close();
    //    if (ds.Tables[0].Rows.Count > 0)
    //    {
    //        GridView3.DataSource = ds;
    //        GridView3.DataBind();
    //    }

    //}

    //protected void GridView3_RowEditing(object sender, GridViewEditEventArgs e)
    //{
    //    GridView3.EditIndex = e.NewEditIndex;

    //    gvbind3();
    //}


    //protected void GridView3_RowUpdating(object sender, GridViewUpdateEventArgs e)
    //{
    //    try
    //    {
    //        SqlConnection con = new SqlConnection(GetConnection());

    //        GridViewRow row = (GridViewRow)GridView3.Rows[e.RowIndex];


    //        DropDownList textName = (DropDownList)row.Cells[6].Controls[0];

    //        TextBox textc = (TextBox)row.Cells[7].Controls[0];


    //        GridView3.EditIndex = -1;
    //        con.Open();
    //        TextBox text1 = (TextBox)(row.Cells[0].Controls[0]);

    //        SqlCommand cmd = new SqlCommand("update Borower set DefaultStatus='" + textName.Text +
    //            "', Comment='" + textc.Text + "' where borrowername = '" + text1.Text + "'", con);
    //        cmd.ExecuteNonQuery();
    //        con.Close();
    //        gvbind3();
    //        Response.Write("<script language='javascript'> alert('User Details Updated successfully.');</script>");
    //    }
    //    catch (Exception)
    //    {
    //        Response.Write("<script language='javascript'> alert('Updation Failed.');</script>");
    //    }
    //}

    /// <summary>
    /// The linkbutton1 click event will show the auto defaulters list 
    /// </summary>


   protected void LinkButton1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(GetConnection());
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("Select * from Borower where BorrowerRating>=8 and AccrualStatus between 2 and 5", con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();
        MultiView1.ActiveViewIndex = 0;
    }

    /// <summary>
   /// The linkbutton1 click event will show the manual defaulters list 
    /// </summary>
  
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(GetConnection());
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("select * from borower where BorrowerRating between 5 and 7 and AccrualStatus=1 or AccrualStatus=6 or AccrualStatus=7 and DaysPastDue between 90 and 179  ", con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView2.DataSource = ds.Tables[0];
        GridView2.DataBind();
        MultiView1.ActiveViewIndex = 1;
    }

    /// <summary>
    /// The linkbutton1 click event will show the Re-defaulters list 
    /// </summary>
   
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(GetConnection());
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("select * from borower where DaysPastDue>=180", con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView3.DataSource = ds.Tables[0];
        GridView3.DataBind();
        MultiView1.ActiveViewIndex = 2;
    }




    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

       

    }     

        


    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
    protected void GridView4_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
            
        
    }

}