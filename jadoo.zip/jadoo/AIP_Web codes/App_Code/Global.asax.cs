﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.IO;

/// <summary>
/// Summary description for Global
/// </summary>
/// 
namespace AIP_Web
{
    public class Global : System.Web.HttpApplication
    {

        //
        // TODO: Add constructor logic here
        //
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup

        }

        void Application_End(object sender, EventArgs e)
        {
            //  Code that runs on application shutdown

        }

        void Application_Error(object sender, EventArgs e)
        {
            Exception exc = Server.GetLastError().GetBaseException();

            if (exc.Message == "File does not exist.")
            {
                string logFile = @"Logger\ErrorLog.txt";
                logFile = HttpContext.Current.Server.MapPath("~/" + logFile);

                StreamWriter sw = new StreamWriter(logFile, true);

                sw.Write("Exception Type: ");
                sw.WriteLine(exc.GetType().ToString());
                sw.WriteLine("Exception: " + exc.Message);
                sw.WriteLine("Source: " + exc.Source);
                sw.WriteLine("Stack Trace: " + exc.InnerException);
                sw.WriteLine("Stack Trace: " + exc.Data);
                sw.Flush();
                sw.Close();
                Server.ClearError();
            }
            Response.Redirect("ErrorPage.aspx");



        }

        void Session_Start(object sender, EventArgs e)
        {
            // Code that runs when a new session is started
            Session["username"] = "";
            Session["Login_Id"] = "";

        }

        void Session_End(object sender, EventArgs e)
        {
            Session["username"] = "";
            Session["user_role"] = "";
            Session["Login_Id"] = "";

            // Code that runs when a session ends. 
            // Note: The Session_End event is raised only when the sessionstate mode
            // is set to InProc in the Web.config file. If session mode is set to StateServer 
            // or SQLServer, the event is not raised.

        }

    }
}