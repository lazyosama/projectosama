﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Registration_DataLinkLayer;


namespace Registration_businesslogiclayer
{
/// <summary>
/// Recieves the values from presentation layer
/// </summary>
    public class user
    {
        int Age,ZipCode;

        double ContactNo;

        string Password, LoginId, FirstName, LastName, EmailId, Address, Role, Gender, CityName;

        public string _LoginId
        {

            get { return LoginId; }

            set { LoginId = value; }

        }

        public int _Age
        {

            get { return Age; }

            set { Age = value; }

        }

        public double _ContactNo
        {

            get { return ContactNo; }

            set { ContactNo = value; }

        }

        public int _ZipCode
        {

            get { return ZipCode; }

            set { ZipCode = value; }

        }

        public string _Role
        {

            get { return Role; }

            set { Role = value; }

        }
        public string _CityName
        {

            get { return CityName; }

            set { CityName = value; }

        }


        public string _Gender
        {

            get { return Gender; }

            set { Gender = value; }

        }

        public string _Password
        {

            get { return Password; }

            set { Password = value; }

        }

        public string _FirstName
        {

            get { return FirstName; }

            set { FirstName = value; }

        }
     
        public string _LastName
        {

            get { return LastName; }

            set { LastName = value; }

        }
        public string _EmailId
        {

            get { return EmailId; }

            set { EmailId = value; }

        }

        public string _Address
        {

            get { return Address; }

            set { Address = value; }

        }

    }
    /// <summary>
    /// register method passes the values to datalink layer
    /// </summary>
    public class Registration_bal
    {
       
        public bool register(user u)
        {

            try
            {

                Registration_DataLinkLayer.user daluser = new Registration_DataLinkLayer.user();
                string LoginId = Generate_LoginId(u);
               
                
                daluser._Role = u._Role;
               
                daluser._LoginId = LoginId;

                daluser._Password = u._Password;

                daluser._FirstName = u._FirstName;

                daluser._LastName = u._LastName;

                daluser._Age = u._Age;

                daluser._Gender = u._Gender;

                daluser._ContactNo = u._ContactNo;
                daluser._EmailId = u._EmailId;
                daluser._Address = u._Address;
                daluser._CityName = u._CityName;
                daluser._ZipCode = u._ZipCode;

                Registration_DataLinkLayer.Registration_dal dalreg = new Registration_DataLinkLayer.Registration_dal();

               // return daluser._LoginId;

                bool m = dalreg.register(daluser);
                if (m ==true)
                {

                    return true;
                  //  return "ok";
                }
                else
                    //return m;
                    return false;
            }
            catch (Exception)
            {
                //return exx.Message + "in bal regis" + Generate_LoginId(u) ;
                return false;
            }
        }
    
        /// <summary>
        /// Generate_LoginId method generates login id for admin and user
        /// </summary>
        
        public string Generate_LoginId(user u)
        {

            Registration_DataLinkLayer.Registration_dal d = new Registration_DataLinkLayer.Registration_dal();

            Registration_DataLinkLayer.user daluser = new Registration_DataLinkLayer.user();

            
            if (u._Role == "Admin")
            {
                int Count = Convert.ToInt32(d.Generate_LoginId_Admin(daluser));
                if (Count== 0)
                {
                   string LoginId = "A001";
                   return LoginId;
                }
                    else if(Count<=9)
                {
                    string LoginId = "A00" + (++Count);
                    return LoginId;
                }
                else if (Count >= 10 && Count<100)
                {
                    string LoginId = "A0" + (++Count);
                    return LoginId;
                }
                else if (Count >= 100 && Count<1000)
                {
                    string LoginId = "A" + (++Count);
                    return LoginId;
                }
            }
            
            else if (u._Role.ToString() == "User")
            {
                int Count = Convert.ToInt32(d.Generate_LoginId_User(daluser));
                if (Count == 0)
                {
                    string LoginId = "U001";
                    return LoginId;
                }
                    else if(Count<=9)
                {
                    string LoginId = "U00" + (++Count);
                    return LoginId;
                }
                else if (Count >= 10 && Count < 100)
                {
                    string LoginId = "U0" + (++Count);
                    return LoginId;
                }
                else if (Count >= 100 && Count < 1000)
                
                {
                    string LoginId = "U" + (++Count);
                    return LoginId;
                }
            }

            return "abcd";
        }


    }

}
