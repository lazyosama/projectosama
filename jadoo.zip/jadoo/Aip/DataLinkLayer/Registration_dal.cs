﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;



namespace Registration_DataLinkLayer
{
    /// <summary>
    /// Recieves the values from business logic layer
    /// </summary>
    public class user
    {


        int Age, ZipCode;
        double ContactNo;



        string Password, LoginId, FirstName, LastName, EmailId, Address, Role, Gender, CityName;

        public string _LoginId
        {

            get { return LoginId; }

            set { LoginId = value; }

        }

        public int _Age
        {

            get { return Age; }

            set { Age = value; }

        }

        public double _ContactNo
        {

            get { return ContactNo; }

            set { ContactNo = value; }

        }

        public int _ZipCode
        {

            get { return ZipCode; }

            set { ZipCode = value; }

        }

        public string _Role
        {

            get { return Role; }

            set { Role = value; }

        }
        public string _CityName
        {

            get { return CityName; }

            set { CityName = value; }

        }

        public string _Gender
        {

            get { return Gender; }

            set { Gender = value; }

        }

        public string _Password
        {

            get { return Password; }

            set { Password = value; }

        }

        public string _FirstName
        {

            get { return FirstName; }

            set { FirstName = value; }

        }

        public string _LastName
        {

            get { return LastName; }

            set { LastName = value; }

        }
        public string _EmailId
        {

            get { return EmailId; }

            set { EmailId = value; }

        }

        public string _Address
        {

            get { return Address; }

            set { Address = value; }

        }

    }


    public class Registration_dal
    {
        public string GetConnection()
        {
            return ConfigurationManager.ConnectionStrings["mycon"].ConnectionString.ToString();
        }
       
        /// <summary>
        /// the method will store the values entered by user to the database using the stored procedure Registerproc 
        /// </summary>
     
       

        public bool register(user u)
        {
            SqlConnection con = new SqlConnection(GetConnection());
            try
            {
                con.Open();
                 SqlCommand cmd = new SqlCommand("Registerproc", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@LoginId", u._LoginId);

                cmd.Parameters.AddWithValue("@Role", u._Role);
                cmd.Parameters.AddWithValue("@Password", u._Password);
                cmd.Parameters.AddWithValue("@FirstName", u._FirstName);
                cmd.Parameters.AddWithValue("@LastName", u._LastName);
                cmd.Parameters.AddWithValue("@Age", u._Age);
                cmd.Parameters.AddWithValue("@Gender", u._Gender);
                cmd.Parameters.AddWithValue("@ContactNo", u._ContactNo);
                cmd.Parameters.AddWithValue("@EmailId", u._EmailId);
                cmd.Parameters.AddWithValue("@Address", u._Address);
                cmd.Parameters.AddWithValue("@CityName", u._CityName);
                cmd.Parameters.AddWithValue("@ZipCode", u._ZipCode);

               
               cmd.ExecuteNonQuery();

                con.Close();
               // return "ok";
                return true;
                
            }
            catch (Exception)
            {
                con.Close();
              //  return exx.Message + "in dal regis" + Generate_LoginId_Admin(u);
                return false;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        /// <summary>
        /// the Generate_LoginId_Admin method will return the zeroth element in database for admin
        /// </summary>
       

        public string Generate_LoginId_Admin(user u)
        {
            SqlConnection con = new SqlConnection(GetConnection());
            
           
            con.Open();
            string max_ID;
            max_ID = "select isnull(MAX(SUBSTRING(LoginId,2,3)),0) from Register where Role='Admin'";
            SqlCommand cmd = new SqlCommand(max_ID, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            int c = ds.Tables[0].Rows.Count;
            if (c == 0)
                return "0";

            return (ds.Tables[0].Rows[0].ItemArray[0].ToString());
        }

        /// <summary>
        /// the Generate_LoginId_Admin method will return the zeroth element in database for user
        /// </summary>
       
        public string Generate_LoginId_User(user u)
        {
            SqlConnection con = new SqlConnection(GetConnection());
            con.Open();
            string max_ID;
            max_ID = "select isnull(MAX(SUBSTRING(LoginId,2,3)),0) from Register where Role='User'";
            SqlCommand cmd = new SqlCommand(max_ID, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            int c = ds.Tables[0].Rows.Count;
            if (c == 0)
                return "0";

            return (ds.Tables[0].Rows[0].ItemArray[0].ToString());
        }
    }
}

      

