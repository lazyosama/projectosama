﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AfterRegistration_DAL;
using Registration_businesslogiclayer;

namespace AfterRegistration_BAL
{
    public class AfterRegistrationBAL
    {
        

        //public string Get_LoginId()
        //{
        //   AfterRegistrationDAL AfterRgeDalobj = new AfterRegistrationDAL();
        //    businesslogiclayer.user u= new businesslogiclayer.user();
                    
        //    if (u._Role == "Admin")
        //    {
        //        return AfterRgeDalobj.Get_LoginId_Admin();
        //    }
            
        //    else if (u._Role.ToString() == "User")
        //    {
        //        return AfterRgeDalobj.Get_LoginId_User();
        //    }

        //    return "abcd";
        //}


    }


    }
