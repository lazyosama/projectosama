﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DAL_Login;


namespace BAL_Login
{
    public class LoginBal
    {
        DAL_Login.LoginDal login_validation = new DAL_Login.LoginDal();// creating an object of loginDAL class

        public int LoginValidation(string LoginId, string Password, string user_role)//checking the usename and password
        {
            try
            {
                int row_count = login_validation.userlogin(LoginId, Password,user_role);
                string user_type = login_validation.user_type_check(LoginId, Password);
                if (row_count == 1 && user_type == "Admin")
                {
                    return 1;
                }
                else if (row_count == 1 && user_type == "User")
                {
                    return 2;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ec)
            {
                ec.GetType();
            }
            return 0;
        }

        //checking the userType
        //public string usertype(string LoginId, string Password)
        //{
        //    try
        //    {
        //        return login_validation.user_type_check(LoginId,Password);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

 
    }
}
