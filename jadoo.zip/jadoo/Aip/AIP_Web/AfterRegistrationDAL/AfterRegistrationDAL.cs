﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace AfterRegistration_DAL
{
    public class AfterRegistrationDAL
    {

         public string GetConnection()
        {
            return ConfigurationManager.ConnectionStrings["mycon"].ToString();
        }

    //     public string GetLoginId()
    //     {
    //         SqlConnection con;
    //         SqlCommand cmd;
    //         SqlDataAdapter da;
    //         DataSet ds;

    //         con = new SqlConnection(GetConnection());
    //         cmd = new SqlCommand("GetLoginIdStoredProc", con);
    //         cmd.CommandType = CommandType.StoredProcedure;
    //         da = new SqlDataAdapter(cmd);
    //         ds = new DataSet();
    //         da.Fill(ds);
    //         try
    //         {
    //             return ds.Tables[0].Rows[0].ItemArray[0].ToString();
    //         }
    //         catch (Exception e)
    //         {
    //             return "0";
    //         }
        
      
    //}



         //public string Get_LoginId_Admin()
         //{
         //    SqlConnection con;
         //    SqlCommand cmd;
         //    SqlDataAdapter da;
         //    DataSet ds;
         //    con = new SqlConnection(GetConnection());

         //    con.Open();
         //    string max_ID;
         //    max_ID = "select LoginId from Register where Role='Admin'";
         //    cmd = new SqlCommand(max_ID, con);
         //    da = new SqlDataAdapter(cmd);
         //    ds = new DataSet();
         //    da.Fill(ds);
         //    con.Close();
         //    int c = ds.Tables[0].Rows.Count;
         //    if (c == 0)
         //        return "0";

         //    return (ds.Tables[0].Rows[0].ItemArray[0].ToString());
         //}


         //public string Get_LoginId_User()
         //{
         //    SqlConnection con;
         //    SqlCommand cmd;
         //    SqlDataAdapter da;
         //    DataSet ds;
         //    con = new SqlConnection(GetConnection());
         //    con.Open();
         //    string max_ID;
         //    max_ID = "select LoginId from Register where Role='User'";
         //    cmd = new SqlCommand(max_ID, con);
         //    da = new SqlDataAdapter(cmd);
         //    ds = new DataSet();
         //    da.Fill(ds);
         //    con.Close();
         //    int c = ds.Tables[0].Rows.Count;
         //    if (c == 0)
         //        return "0";

         //    return (ds.Tables[0].Rows[0].ItemArray[0].ToString());
         //}

    }
}
