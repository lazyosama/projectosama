﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

using System.Linq;
using System.Web;

using System.Xml.Linq;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ForgetPassword_Dal
{
    public class ForgotPasswordDal
    {

        public string GetConnection()
        {
            return ConfigurationManager.ConnectionStrings["mycon"].ConnectionString.ToString();
        }
        /// <summary>
        /// get_Username_for_reset_Password method checks whether login id and email id are present in the database
        /// </summary>
    
        public string get_Username(string LoginId, string EmailId)
        {
            SqlConnection con = new SqlConnection(GetConnection());
            con.Open();
            // string reset = "resetPasswordproc";
            //string query_select_Username_for_ResetPassword;
            //query_select_Username_for_ResetPassword = "select isnull(LoginId,0) from Register where LoginId='" + LoginId + "' and EmailId='" + EmailId + "'";

            SqlCommand cmd = new SqlCommand("select isnull(LoginId,0) from Register where LoginId='" + LoginId + "' and EmailId='" + EmailId + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);

            int User_Count = ds.Tables[0].Rows.Count;
            //ds.Tables[0].Rows[0].ItemArray[0].ToString();
            return User_Count.ToString();



            //else
            //       return "Connection Close error in Databse_Connect_DLL.get_Username_for_reset_Password";

        }
        /// <summary>
        /// resetPasswordproc from  reset_Password method will update the password.
        /// </summary>
        
        public string reset_Password(string LoginId, string Password)
        {
            SqlConnection con = new SqlConnection(GetConnection());
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand("resetPasswordproc", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@LoginId", LoginId);
                cmd.Parameters.AddWithValue("@Password", Password);
                //cmd.Parameters.AddWithValue("@acc_type", u.Acc_Type);

                cmd.ExecuteNonQuery();

                con.Close();
                return "Reset Password Successfull";

            }
            catch (Exception e)
            {
                // var frame = new StackTrace(e, true).GetFrame(0); // where the error originated
                //var lineNumber = frame.GetFileLineNumber();
                // Handle line numbers etc. here
                con.Close();
                return e.Message + "   register_acount_DLL Exception";

            }                  //return Password;

            //else
            //    return "Connection Unsuccessfull in Database_Connect_DLL.get_Acc_Name";
        }
    }


}


