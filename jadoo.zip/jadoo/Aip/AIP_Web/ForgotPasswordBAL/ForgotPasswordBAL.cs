﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using ForgetPassword_Dal;

namespace ForgotPassword_BAL
{
   
/// <summary>
/// Summary description for ForgotPasswordBAL
/// </summary>
public class ForgotPasswordBAL
{
	
     public bool get_Username(string LoginId, string EmailId)
        {
           ForgotPasswordDal forgotPass=new ForgotPasswordDal();
           // Database_Connect_DLL DbConnectDll = new Database_Connect_DLL();
            
         string user_count = forgotPass.get_Username(LoginId,EmailId);
            if (Convert.ToInt32(user_count) == 1)
                return true;
            else
                return false;
        }

        public string reset_Password(string LoginId, string Password)
        {
            ForgotPasswordDal resetPass = new ForgotPasswordDal();
            string reset_Check= resetPass.reset_Password(LoginId, Password);
            if (reset_Check == "Reset Password Successfull")
                return "Reset Password Successfull";
            else
            return "Reset Password Unsuccessfull";
        }

        

    }

}




    

