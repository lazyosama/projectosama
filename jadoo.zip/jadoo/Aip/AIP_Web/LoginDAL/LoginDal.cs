﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


 



namespace DAL_Login
{

   
    public class LoginDal
    {
        public string GetConnection()
        {
            return ConfigurationManager.ConnectionStrings["mycon"].ConnectionString.ToString();
        }
       
      
        
        /// <summary>
        /// userlogin method-- to get the count of rows of the entered credentials
        /// </summary>
 
        

        public int userlogin(string LoginId, string Password,string user_role)
        {
            SqlConnection con = new SqlConnection(GetConnection());
            try
            {
                
                con.Open();
                SqlCommand cmd = new SqlCommand("select count(*) from Register where LoginId='" + LoginId + "' and Password=CONVERT(varchar(45), HASHBYTES('MD5','" + Password + "'),2) and role = '"+user_role+"'", con);
                //SqlCommand cmd = new SqlCommand("Select count(*) from Register Where LoginId ='" + LoginId + "'COLLATE SQL_Latin1_General_Cp1_CS_AS and Password='" + Password + "'COLLATE SQL_Latin1_General_Cp1_CS_AS and role = '"+r+"'", con);
               
                int row_count = Convert.ToInt32(cmd.ExecuteScalar());

               
                return row_count;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        /// <summary>
        /// user_type_check-- to get the role
        /// </summary>
        /// <param name="LoginId"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        public string user_type_check(string LoginId, string Password)//getting the userType
        {
            SqlConnection con = new SqlConnection(GetConnection());

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select Role from Register where LoginId='" + LoginId + "' and Password=CONVERT(varchar(45), HASHBYTES('MD5','" + Password + "'),2)", con);
                //SqlCommand cmd = new SqlCommand("select Role from Register where LoginId='" + LoginId + "'COLLATE SQL_Latin1_General_Cp1_CS_AS and Password='" + Password + "'COLLATE SQL_Latin1_General_Cp1_CS_AS", con);
                string user_type = cmd.ExecuteScalar().ToString();
                return user_type;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }


    }
}
