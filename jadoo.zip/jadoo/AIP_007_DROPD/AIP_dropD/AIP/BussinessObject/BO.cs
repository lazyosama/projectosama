﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessObject
{
    public class UserRegistrationBO
    {
        private string U_Fname;

        public string UFname
        {
            get { return U_Fname; }
            set { U_Fname = value; }
        }

        
        private string U_Lname;

        public string ULname
        {
            get { return U_Lname; }
            set { U_Lname = value; }
        }
        private string U_Password;

        public string UPassword
        {
            get { return U_Password; }
            set { U_Password = value; }
        }
        private int U_Age;

        public int UAge
        {
            get { return U_Age; }
            set { U_Age = value; }
        }
        private string U_gender;

        public string Ugender
        {
            get { return U_gender; }
            set { U_gender = value; }
        }
        private string U_contact;

        public string Ucontact
        {
            get { return U_contact; }
            set { U_contact = value; }
        }
        private string U_email;

        public string Uemail
        {
            get { return U_email; }
            set { U_email = value; }
        }
        private string U_address;

        public string Uaddress
        {
            get { return U_address; }
            set { U_address = value; }
        }
        private string U_state;

        public string Ustate
        {
            get { return U_state; }
            set { U_state = value; }
        }
        private string U_city;

        public string Ucity
        {
            get { return U_city; }
            set { U_city = value; }
        }
        private int U_zip;

        public int Uzip
        {
            get { return U_zip; }
            set { U_zip = value; }
        }
 

    }
}
