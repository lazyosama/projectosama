﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessLogic
{
    public class BAL
    {
        private string _FirstName;


        private string _LastName;


        private string _Password;


        private string _ReEnterPassword;

        
        public string FirstName
        {
            get { return _FirstName; }
            set { _FirstName = value; }
        }
        public string LastName
        {
            get { return _LastName; }
            set { _LastName = value; }
        }

        public string Password
        {
            get { return _Password; }
            set { _Password = value; }
        }
        public string ReEnterPassword
        {
            get { return _ReEnterPassword; }
            set { _ReEnterPassword = value; }
        }
    }
}
