﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace AIP
{
    public partial class User_Login : System.Web.UI.Page
    {
       
         SqlConnection conn;
         SqlCommand com;
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            string constr = ConfigurationManager.ConnectionStrings["AIP_DataBaseConnectionString"].ConnectionString;
            conn = new SqlConnection(constr);
            //string login_id = Session["User_Id"].ToString();
        }

        protected void ibuserlogin_login_Click(object sender, ImageClickEventArgs e)
        {
            //string username1 = txt_userlogin_id.Text;
            //string password2 = txtuserlogin_pass.Text;
            
             string user =txt_userlogin_id.Text;
             string pass = txtuserlogin_pass.Text;

             try
             {
                 conn.Open();
                 Session["User_Id"] = txt_userlogin_id.Text;
               
                 com = new SqlCommand("sp_login", conn);
                 com.CommandType = CommandType.StoredProcedure;
                 com.Parameters.AddWithValue("@uname", txt_userlogin_id.Text);
                 com.Parameters.AddWithValue("@pass", txtuserlogin_pass.Text);
                 com.ExecuteNonQuery();
                 SqlDataAdapter da = new SqlDataAdapter(com);
                 DataTable dt = new DataTable();
                 da.Fill(dt);
                 if (dt.Rows.Count > 0)
                 {
                     Session["MySession"] = txt_userlogin_id.Text;
                     Response.Redirect("~/User_after_login.aspx?Uname="+txt_userlogin_id.Text, false);
                     MessageBox.Show("Login Successful");
                 }
                 else
                 {
                     MessageBox.Show("Invalid Username or Password");
                 }
             }
             catch (Exception ex)
             {
                 MessageBox.Show(ex.Message);
             }
             finally
             {
                 conn.Close();
             }
    }


            //if (username1 == "user" && password2 == "user123")
            //{
            //    Server.TransferRequest("~/User_After_login.aspx");

            //}
            //else
            //{
            //     MessageBox.Show("Invalid Username or Password");
            //}
        }
    }
