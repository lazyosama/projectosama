﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AIP
{
    public partial class User_registration : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;
        protected void Page_Load(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["AIP_DataBaseConnectionString"].ConnectionString;
            con = new SqlConnection(constr);
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None; 
        }

        protected void txtUserFname_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ibUserReset_Click(object sender, ImageClickEventArgs e)
        {
            txtUserFname.Text = "";
            txtUserEmail.Text = "";
           
        }

        protected void ibUserRegister_Click(object sender, ImageClickEventArgs e)
        {
            string log = null;
            Random r = new Random();
            log = ObjUregBO.UFname + (Convert.ToString(r.Next(1, 2000)));

            con = new SqlConnection(GetConnection());
            con.Open();

            com = new SqlCommand("sp_User_AIPRegistration", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@login", log);
            com.Parameters.AddWithValue("@fname", ObjUregBO.UFname);
            com.Parameters.AddWithValue("@lname", ObjUregBO.ULname);
            com.Parameters.AddWithValue("@password", ObjUregBO.UPassword);
            com.Parameters.AddWithValue("@age", ObjUregBO.UAge);
            com.Parameters.AddWithValue("@gender", ObjUregBO.Ugender);
            com.Parameters.AddWithValue("@contact_no", ObjUregBO.Ucontact);
            com.Parameters.AddWithValue("@e_mail", ObjUregBO.Uemail);
            com.Parameters.AddWithValue("@_address", ObjUregBO.Uaddress);
            com.Parameters.AddWithValue("@_state ", ObjUregBO.Ustate);
            com.Parameters.AddWithValue("@city", ObjUregBO.Ucity);
            com.Parameters.AddWithValue("@zip", ObjUregBO.Uzip);
            com.ExecuteNonQuery();
            MessageBox.Show("Your Login ID is:" + log);
            con.Close();
        }
    }
}