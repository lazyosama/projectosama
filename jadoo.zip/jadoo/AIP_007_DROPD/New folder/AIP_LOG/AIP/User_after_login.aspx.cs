﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace AIP
{
    public partial class User_after_login : System.Web.UI.Page
    {
        SqlConnection conn;
        SqlCommand com;
        protected void Page_Load(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["AIP_DataBaseConnectionString"].ConnectionString;
            conn = new SqlConnection(constr);
            lbllogin_id.Text = Session["User_Id"].ToString();
            BindData();

        }
        protected void BindData()
        {
            string login_id = Session["User_Id"].ToString();
            DataSet ds = new DataSet();
            DataTable FromTable = new DataTable();
            conn.Open();
            SqlDataAdapter adp = new SqlDataAdapter("SELECT * FROM user_account_Transaction WHERE loginid ='" + login_id + "'", conn);
            adp.Fill(ds);
            FromTable = ds.Tables[0];
            if (FromTable.Rows.Count > 0)
            {
                gvProject.DataSource = FromTable;
                gvProject.DataBind();
            }
            else
            {
                FromTable.Rows.Add(FromTable.NewRow());
                gvProject.DataSource = FromTable;
                gvProject.DataBind();
                int TotalColumns = gvProject.Rows[0].Cells.Count;
                gvProject.Rows[0].Cells.Clear();
                gvProject.Rows[0].Cells.Add(new TableCell());
                gvProject.Rows[0].Cells[0].ColumnSpan = TotalColumns;
                gvProject.Rows[0].Cells[0].Text = "No records Found";
            }
            ds.Dispose();
            conn.Close();
        }

    }
}