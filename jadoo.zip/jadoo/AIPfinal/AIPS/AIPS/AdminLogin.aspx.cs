﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AIPBAL;

namespace AIPS
{
    public partial class AdminLogin : System.Web.UI.Page
    {
      
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            LoginBAL lBAL = new LoginBAL();
            string loginId = txtuserId.Text;
            string passwd = txtPassword.Text;
            bool sts = false;
       
            if (loginId.StartsWith("A"))
            {
                sts = lBAL.loginBAL(loginId, passwd);
                if (sts)
                {
                    Response.Redirect("AdminHome.aspx");
                }
                else
                {
                    Response.Write("<script language='javascript'> alert('Invalid LoginID or Password. Please re-enter');</script>");
                }
            }
            else
            {
                Response.Write("<script language='javascript'> alert('Invalid LoginID or Password.');</script>");
            }
        }
    }
}