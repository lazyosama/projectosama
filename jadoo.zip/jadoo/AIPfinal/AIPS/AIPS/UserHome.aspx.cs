﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;

using System.Web.UI.WebControls.WebParts;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;
using AIPDAL;

namespace AIPS
{
    public partial class UserHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["name"] != null && Session["status"] != null)
            {
                lbluser.Text = Session["name"].ToString();
                labelstatus.Text = Session["status"].ToString();
            }
            else
            {
                Response.Redirect("UserLogin.aspx");
            }
            if (!IsPostBack)
            {

                UserGridViewBind();
                
            }

        }
        protected void UserGridViewBind()
        {
            SqlConnection con = new RegistrationDAL().GetConnection();
            con.Open();
            String logId=Session["lid"].ToString();
      
            SqlCommand cmd = new SqlCommand("SELECT DateOfTransaction,AmountTransferred,TransferredFromAcc,TransferredToAcc,TransferredFromBranch FROM Transactions WHERE LoginId='"+logId+"'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                UserTransactionGridView.DataSource = ds;
                UserTransactionGridView.DataBind();
            }

        }

        protected void download_PDF(object sender, EventArgs e)
        {

            String logId=Session["lid"].ToString();
              string name=Session["name"].ToString();
           string fname=name.Substring(0,name.IndexOf(' '));
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition",
             "attachment;filename="+fname+logId+".pdf");
            Response.Cache.SetCacheability(HttpCacheability.Public);
            
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            UserTransactionGridView.AllowPaging = false;
            UserGridViewBind();
            //UserTransactionGridView.DataBind();
            UserTransactionGridView.RenderControl(hw);
            UserTransactionGridView.HeaderRow.Enabled = true;
            UserTransactionGridView.HeaderRow.Style.Add("width", "50%");
            UserTransactionGridView.HeaderRow.Style.Add("font-size", "10px");
            UserTransactionGridView.Style.Add("text-decoration", "none");
            UserTransactionGridView.Style.Add("font-family", "Arial, Helvetica, sans-serif;");
            UserTransactionGridView.Style.Add("font-size", "8px");
            StringReader sr = new StringReader(sw.ToString());
            Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            pdfDoc.Open();
            htmlparser.Parse(sr);
            pdfDoc.Close();
            Response.Write(pdfDoc);
            Response.End();
        }
        public override void VerifyRenderingInServerForm(Control control)
        {
            return;
        }
        protected void logout_click(object sender, EventArgs e)
        {
            Session["lid"] = null;
            Session["pwd"] = null;
            Session["name"] =null;
            Session["status"] = null;
            Response.Redirect("UserLogin.aspx");
        }

    }
}