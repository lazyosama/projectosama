﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using AIPDAL;

namespace AIPS
{
    public partial class AdminHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["name"] != null)
            {
                lblUser.Text = Session["name"].ToString();
            }
            else
            {
                Response.Redirect("AdminLogin.aspx");
            }
            if (!IsPostBack)
            {
                lblList.Text = "Auto Defaulters";
                AutoViewBind();
                DefaultersView.ActiveViewIndex = 0;
            }
        }

        protected void Page_Init(object Sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.Now.AddDays(-1));
        }

       

        //Auto Default Edit and Update
        protected void AutoViewBind()
        {
            SqlConnection con = new RegistrationDAL().GetConnection();
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Borower where BorrowerRating>=8 and AccrualStatus between 2 and 5 and DefaultStatus!='Validate Error'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                AutoDispGrid.DataSource = ds;
                AutoDispGrid.DataBind();
            }

        }

        protected void AutoDispGrid_RowEditing(object sender, GridViewEditEventArgs e)
        {
            AutoDispGrid.EditIndex = e.NewEditIndex;

            AutoViewBind();
        }


        protected void AutoDispGrid_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            SqlConnection con = new RegistrationDAL().GetConnection();
            //int userid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value.ToString());
            GridViewRow row = (GridViewRow)AutoDispGrid.Rows[e.RowIndex];
          
            
            //DropDownList textName = ((DropDownList)row.Cells[6].Controls[0]);

            DropDownList textName = (DropDownList)row.FindControl("DropListStatus");
            //   TextBox textName = CType((DropDownList)row.Cells[6].Controls[0], System.Web.UI.WebControls.TextBox);
            TextBox textc = (TextBox)(row.Cells[8].Controls[0]);


            AutoDispGrid.EditIndex = -1;
            con.Open();
            String txtId = row.Cells[0].Text;
           String txtname= row.Cells[1].Text;

            SqlCommand cmd = new SqlCommand("update Borower set DefaultStatus='" + textName.Text +
                "', Comment='" + textc.Text + "' where borrowername = '" + txtname + "' and LoginId='"+txtId+"'", con);
            int i=cmd.ExecuteNonQuery();
            if (i > 0)
            {
                Response.Write("<script language='javascript'> alert('Successfully Updated');</script>");
            }

            con.Close();
            AutoViewBind();
        }



        //Manual Default Edit and Update

        protected void ManualViewBind()
        {
            SqlConnection con = new RegistrationDAL().GetConnection();
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from borower where BorrowerRating between 5 and 7 and AccrualStatus=1 or AccrualStatus=6 or AccrualStatus=7 and DaysPastDue between 90 and 179  and DefaultStatus!='Validate Error'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ManualDispGrid.DataSource = ds;
                ManualDispGrid.DataBind();
            }

        }

        protected void ManualDispGrid_RowEditing(object sender, GridViewEditEventArgs e)
        {
            ManualDispGrid.EditIndex = e.NewEditIndex;

            ManualViewBind();
        }


        protected void ManualDispGrid_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            SqlConnection con = new RegistrationDAL().GetConnection();

            GridViewRow row = (GridViewRow)ManualDispGrid.Rows[e.RowIndex];


            DropDownList textName = (DropDownList)row.FindControl("DrpListStatusManual");

            TextBox textc = (TextBox)row.Cells[8].Controls[0];


            ManualDispGrid.EditIndex = -1;
            con.Open();
            String txtId = row.Cells[0].Text;
            String txtname = row.Cells[1].Text;

            SqlCommand cmd = new SqlCommand("update Borower set DefaultStatus='" + textName.Text +
                "', Comment='" + textc.Text + "' where borrowername = '" + txtname + "' and Loginid='"+txtId+"'", con);
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                Response.Write("<script language='javascript'> alert('Successfully Updated');</script>");
            }

            con.Close();
            ManualViewBind();
        }



        //Re - Default Edit and Update

        protected void RedefaultBind()
        {
            SqlConnection con = new RegistrationDAL().GetConnection();
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from borower where DaysPastDue>=180", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ReDefaultGridView.DataSource = ds;
                ReDefaultGridView.DataBind();
            }

        }

     



        protected void AutoTab_Click(object sender, EventArgs e)
        {
            lblList.Text = "Auto Defaulters";
            AutoViewBind();
            DefaultersView.ActiveViewIndex = 0;
        }
        protected void ManualTab_Click(object sender, EventArgs e)
        {
            lblList.Text = "Manual Defaulters";
            ManualViewBind();
            DefaultersView.ActiveViewIndex = 1;
        }
        protected void ReDefaultTab_Click(object sender, EventArgs e)
        {
            lblList.Text = "Re Defaulters";
            RedefaultBind();
            DefaultersView.ActiveViewIndex = 2;
        }
        protected void logout_click(object sender, EventArgs e)
        {
            Session["lid"] = null;
            Session["pwd"] = null;
            Session["name"] = null;
           Response.Redirect("AdminLogin.aspx");
        }
        protected void Redefault_Update(object sender, EventArgs e)
        {
            SqlConnection con = new RegistrationDAL().GetConnection();
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from borower where DaysPastDue>=180 and( DefaultStatus is null or DefaultStatus in('Auto','Auto Weaver','Validate Error'))", con);
            SqlDataReader sr = cmd.ExecuteReader();
            if (sr.Read())
            {
                sr.Close();
                cmd = new SqlCommand("update Borower set DefaultStatus='Re-Default', Comment='You are a re-defaulter' where DaysPastDue>=180", con);
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    Response.Write("<script language='javascript'> alert(Successfully Updated as Redefaulter');</script>");
                    RedefaultBind();
                }
            }
            else
            {
                Response.Write("<script language='javascript'> alert('No Data To update');</script>");
            }
            con.Close();
        }

        protected void SqlDataSource2_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }
       
    }
}