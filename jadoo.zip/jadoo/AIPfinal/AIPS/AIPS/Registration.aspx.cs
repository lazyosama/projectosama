﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AIPVO;
using AIPBAL;

namespace AIPS
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string message = "Hello! Mudassar.";
            //System.Text.StringBuilder sb = new System.Text.StringBuilder();
            //sb.Append("<script type = 'text/javascript'>");
            //sb.Append("window.onload=function(){");
            //sb.Append("alert('");
            //sb.Append(message);
            //sb.Append("')};");
            //sb.Append("</script>");
            //ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            //string message = "Hello! Mudassar.";
            //System.Text.StringBuilder sb = new System.Text.StringBuilder();
            //sb.Append("<script type = 'text/javascript'>");

            //sb.Append("alert('");
            //sb.Append(message);

            //sb.Append("</script>");
            //ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());

            LoginIdTextBox.Text = string.Empty;
            PasswordTextBox.Text = string.Empty;
            FirstNameTextBox.Text = string.Empty;
            LastNameTextBox.Text = string.Empty;
            AgeTextBox.Text = string.Empty;
            ContactNumberTextBox.Text = string.Empty;
            EmailTextBox.Text = string.Empty;
            AddressTextBox.Text = string.Empty;
            ZipCodeTextBox.Text = string.Empty;
            ReEnterPasswordTextBox.Text = string.Empty;
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            RegistrationBAL rBAL = new RegistrationBAL();
            AIPVO.User u = new AIPVO.User();
            u._Role = Request.Form["role"].ToString();
            u._LoginId = rBAL.Generate_LoginIdBAL(u._Role);
            u._Password = PasswordTextBox.Text;
            u._FirstName = FirstNameTextBox.Text;
            u._LastName = LastNameTextBox.Text;
            u._Age = int.Parse(AgeTextBox.Text);
            u._Gender = Request.Form["sex"].ToString();
            u._ContactNo =double.Parse( ContactNumberTextBox.Text);
            u._EmailId = EmailTextBox.Text;
            u._Address = AddressTextBox.Text;
            u._CityName = CityDropDownList.SelectedItem.Text;
            u._ZipCode = int.Parse(ZipCodeTextBox.Text);

            bool status = rBAL.registerationBAL(u);
            if (status)
            {
                //Session["UserObj"] = u; 
                Response.Redirect("AfterRegistration.aspx?name="+u._FirstName+"&uid="+u._LoginId);
             
            }
            else
            {
                Response.Write("<script language='javascript'> alert('Registration Failed')");
            }


        }
        protected void radiorole_Changed(string role)
        {

        }

        protected void LoginIdTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        protected void AddressTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        
       
    }
}
