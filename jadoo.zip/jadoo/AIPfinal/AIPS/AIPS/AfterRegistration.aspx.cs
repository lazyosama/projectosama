﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AIPVO;

namespace AIPS
{
    public partial class AfterRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //User u = (User)Session["UserObj"];

            LoginIdLabel.Text =Request.QueryString["uid"];
            UserLabel.Text = Request.QueryString["name"]; ;

        }

        protected void loginBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }
}