﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AIPVO
{
    public class User
    {
        int Age, ZipCode;
        double ContactNo;



        string Password, LoginId, FirstName, LastName, EmailId, Address, Role, Gender, CityName;

        public string _LoginId
        {

            get { return LoginId; }

            set { LoginId = value; }

        }

        public int _Age
        {

            get { return Age; }

            set { Age = value; }

        }

        public double _ContactNo
        {

            get { return ContactNo; }

            set { ContactNo = value; }

        }

        public int _ZipCode
        {

            get { return ZipCode; }

            set { ZipCode = value; }

        }

        public string _Role
        {

            get { return Role; }

            set { Role = value; }

        }
        public string _CityName
        {

            get { return CityName; }

            set { CityName = value; }

        }

        public string _Gender
        {

            get { return Gender; }

            set { Gender = value; }

        }

        public string _Password
        {

            get { return Password; }

            set { Password = value; }

        }

        public string _FirstName
        {

            get { return FirstName; }

            set { FirstName = value; }

        }

        public string _LastName
        {

            get { return LastName; }

            set { LastName = value; }

        }
        public string _EmailId
        {

            get { return EmailId; }

            set { EmailId = value; }

        }

        public string _Address
        {

            get { return Address; }

            set { Address = value; }

        }
    }
}
