﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;


namespace AIPDAL
{
    public class LoginDAL
    {
        public bool loginDal(string uid, string pwd)
        {
            bool sts = false;
            RegistrationDAL rdaObj = new RegistrationDAL();
            SqlConnection con = rdaObj.GetConnection();
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("LoginProc", con);


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@userid", uid);
               
                cmd.Parameters.AddWithValue("@passwd",  pwd);
               SqlDataReader dr=cmd.ExecuteReader();
               if (dr.Read())
               {
                 
                
               HttpContext.Current.Session["lid"]=dr["LoginId"].ToString();
               HttpContext.Current.Session["pwd"] =pwd;
               HttpContext.Current.Session["name"] = dr["FirstName"].ToString() + " " + dr["LastName"].ToString();

               sts = true;

               dr.Close();
               if (uid.StartsWith("U"))
               {
                   cmd = new SqlCommand("getStatusProc", con);


                   cmd.CommandType = CommandType.StoredProcedure;
                   cmd.Parameters.AddWithValue("@userid", uid);
                   dr = cmd.ExecuteReader();
                   if (dr.Read())
                   {
                       HttpContext.Current.Session["status"] = dr["DefaultStatus"].ToString();
                   }


               }
                       

               }

               
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                con.Close();
            }
            
            return sts;
        }

    }
}
