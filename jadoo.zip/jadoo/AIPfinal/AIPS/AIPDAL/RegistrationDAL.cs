﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace AIPDAL
{
    public class RegistrationDAL
    {
        public SqlConnection GetConnection()
        {
            try
            {
                SqlConnection con = null;
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString);
                return con;
            }
            catch (Exception)
            {
                
                throw;
            }
           
        }
        public int Generate_LoginId_DAL(string role)
        {
            int count = 0;
            SqlConnection con = GetConnection();
            try
            {
                
                con.Open();
                SqlCommand cmd = new SqlCommand("GetUserCount_Proc", con);


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Role", role);
                cmd.Parameters.AddWithValue("@usercount", count);
                count = (int)cmd.ExecuteScalar();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                con.Close();
            }
            


            return count;
        }

        public int registerationDAL(AIPVO.User u)
        {
            int rc = 0;
            SqlConnection con = GetConnection();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Registerproc", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@LoginId", u._LoginId);

                cmd.Parameters.AddWithValue("@Role", u._Role);
                cmd.Parameters.AddWithValue("@Password", u._Password);
                cmd.Parameters.AddWithValue("@FirstName", u._FirstName);
                cmd.Parameters.AddWithValue("@LastName", u._LastName);
                cmd.Parameters.AddWithValue("@Age", u._Age);
                cmd.Parameters.AddWithValue("@Gender", u._Gender);
                cmd.Parameters.AddWithValue("@ContactNo", u._ContactNo);
                cmd.Parameters.AddWithValue("@EmailId", u._EmailId);
                cmd.Parameters.AddWithValue("@Address", u._Address);
                cmd.Parameters.AddWithValue("@CityName", u._CityName);
                cmd.Parameters.AddWithValue("@ZipCode", u._ZipCode);


                rc = cmd.ExecuteNonQuery();

            }
            catch (Exception)
            {
                
                throw;
            }
            return rc;
        }
    }
}
