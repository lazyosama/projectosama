﻿using AIPDAL;

namespace AIPBAL
{
    public class RegistrationBAL
    {
        RegistrationDAL rDAL = new RegistrationDAL();
        public string Generate_LoginIdBAL(string role)
        {

            string LoginId = "";

            int Count = rDAL.Generate_LoginId_DAL(role);
            if (role == "Admin")
            {
              
                if (Count == 0)
                {
                    LoginId = "A001";
                
                }
                else if (Count <= 9)
                {
                   LoginId = "A00" + (++Count);
                
                }
                else if (Count >= 10 && Count < 100)
                {
                    LoginId = "A0" + (++Count);
                  
                }
                else if (Count >= 100 && Count < 1000)
                {
                    LoginId = "A" + (++Count);
                   
                }
            }

            else if (role == "User")
            {
              
                if (Count == 0)
                {
                   LoginId = "U001";
                  
                }
                else if (Count <= 9)
                {
              LoginId = "U00" + (++Count);
                  
                }
                else if (Count >= 10 && Count < 100)
                {
              LoginId = "U0" + (++Count);
                 
                }
                else if (Count >= 100 && Count < 1000)
                {
                  LoginId = "U" + (++Count);
                  
                }
            }

            return LoginId;
        }


        public bool registerationBAL(AIPVO.User u)
        {
            int rc;
            bool sts;
            rc=rDAL.registerationDAL(u);
            if(rc>0)
                sts=true;
            else
                sts=false;
           
            return sts;
        }
    }
}
