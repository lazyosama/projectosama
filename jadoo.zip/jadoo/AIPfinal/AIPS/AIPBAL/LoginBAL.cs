﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AIPDAL;

namespace AIPBAL
{
 public class LoginBAL
    {
        LoginDAL lDal = new LoginDAL();
        public bool loginBAL(string uid, string pwd)
        {
            bool sts = false;
            sts=lDal.loginDal(uid,pwd);
            return sts;
        }
    }
}
