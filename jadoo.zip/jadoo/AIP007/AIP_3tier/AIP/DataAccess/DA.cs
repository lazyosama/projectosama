﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data; // Required for using Dataset , Datatable and Sql
using System.Data.SqlClient; // Required for Using Sql
using System.Configuration; // for Using Connection From Web.config 
using BussinessObject;
using System.Windows.Forms;


namespace DataAccess
{
    public class DA
    {
        SqlConnection con;
        SqlCommand com;
        SqlDataAdapter da;
        //SqlDataReader myReader;
        DataSet ds;
        
        /// <summary>
        /// function that returns Connection String
        /// </summary>
        /// <returns></returns>

        public string GetConnection()
        {
            return ConfigurationManager.ConnectionStrings["AIP_DataBase"].ConnectionString;
        }

        public int UserRegistration(UserRegistrationBO ObjUregBO)
        {
            try
            {
               
                string log = null;
                Random r = new Random();
                log = ObjUregBO.UFname + (Convert.ToString(r.Next(1, 2000)));
               
                con = new SqlConnection(GetConnection());
                con.Open();
                
                com = new SqlCommand("sp_AIPRegistration", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@login", log);
                com.Parameters.AddWithValue("@fname",ObjUregBO.UFname);
                com.Parameters.AddWithValue("@lname", ObjUregBO.ULname);
                com.Parameters.AddWithValue("@password", ObjUregBO.UPassword);
                com.Parameters.AddWithValue("@age", ObjUregBO.UAge);
                com.Parameters.AddWithValue("@gender", ObjUregBO.Ugender);
                com.Parameters.AddWithValue("@contact_no", ObjUregBO.Ucontact);
                com.Parameters.AddWithValue("@e_mail", ObjUregBO.Uemail);
                com.Parameters.AddWithValue("@_address", ObjUregBO.Uaddress);
                com.Parameters.AddWithValue("@_state ", ObjUregBO.Ustate);
                com.Parameters.AddWithValue("@city", ObjUregBO.Ucity);
                com.Parameters.AddWithValue("@zip", ObjUregBO.Uzip);
                com.ExecuteNonQuery();
                MessageBox.Show("Your Login ID is:" + log);
                con.Close();
                return 1;
               
            }
            catch
            {
                return -1;
            }

        }
             
    }
}
