﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
namespace AIP
{
    public partial class User_Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }

        protected void ibuserlogin_login_Click(object sender, ImageClickEventArgs e)
        {
            string username1 = txt_userlogin_id.Text;
            string password2 = txtuserlogin_pass.Text;


            //Server.Transfer("~/User_After_login.aspx");
            if (username1 == "user" && password2 == "user123")
            {
                //Server.Transfer("~/User_After_login.aspx");
                Response.Redirect("~/User_After_login.aspx", false);
            }
            else
            {
                 MessageBox.Show("Invalid Username or Password");
            }
        }
    }
}