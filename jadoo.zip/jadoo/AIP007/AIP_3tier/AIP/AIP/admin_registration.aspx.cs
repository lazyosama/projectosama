﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Configuration;

namespace AIP
{
    public partial class admin_registration : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;
        string gender;

        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            string constr = ConfigurationManager.ConnectionStrings["AIP_DataBase"].ConnectionString;
            con = new SqlConnection(constr);
            gender = "";
            if (RblAdmin.SelectedIndex == 1)
            {
                gender = " Male";
            }
            else
            {
                gender = "Female";
            }

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            //txtUserFname.Text = " ";
            //txtUserEmail.Text = " ";
            //txtUserZip.Text = "";
            //txtUserAdd.Text = "";
            //txtUserAge.Text = "";
            //txtUserCon.Text = "";
            //txtUserLname.Text = "";
            //txtUserPass.Text = "";
            //txtUserRepass.Text = "";
            //ddUserCity.SelectedIndex = 0;
            //ddUserCity.SelectedIndex = 0;
      
            

        }

        protected void txtAge_TextChanged(object sender, EventArgs e)
        {

        }

        protected void rbmale_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox7_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            string log=null;
            Random r = new Random();
            log =txtFname.Text + (Convert.ToString(r.Next(1, 2000)));
            con.Open();
            com = new SqlCommand("sp_Aip_Reg", con);
            com.CommandType = System.Data.CommandType.StoredProcedure;

            com.Parameters.AddWithValue("login", log);
            com.Parameters.AddWithValue("@fname",txtFname.Text);
            com.Parameters.AddWithValue("@lname", txtLname.Text);
            com.Parameters.AddWithValue("@password",txtPass.Text );
            com.Parameters.AddWithValue("@age",txtAge.Text );
            com.Parameters.AddWithValue("@gender",gender);
            com.Parameters.AddWithValue("@contact_no",txtcontact.Text );
            com.Parameters.AddWithValue("@e_mail", txtEmail.Text);
            com.Parameters.AddWithValue("@_address",txtAdd.Text );
            com.Parameters.AddWithValue("@_state ",ddState.Text );
            com.Parameters.AddWithValue("@city",ddCity.Text );
            com.Parameters.AddWithValue("@zip", txtZip.Text);
            com.ExecuteNonQuery();
            MessageBox.Show("Your Login ID is:" + log);

            con.Close();
            Response.Redirect("~/AIP_Home.aspx", false);
     

        }
    }
}