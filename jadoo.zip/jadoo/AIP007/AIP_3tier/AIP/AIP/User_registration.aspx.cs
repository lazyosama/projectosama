﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using BussinessObject;
using Bussinesslogic;

namespace AIP
{
    public partial class User_registration : System.Web.UI.Page
    {

        UserRegistrationBO userBO = new UserRegistrationBO();
        UserRegistrationBL userBl = new UserRegistrationBL();
        string gender;

        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
           
            

             gender = "";
            if (Rbluser.SelectedIndex == 1)
            {
                gender = " Male";
            }
            else
            {
                gender = "Female";
            }
        }

        

        protected void txtUserFname_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ibUserReset_Click(object sender, ImageClickEventArgs e)
        {
            //txtUserFname.Text = " ";
            //txtUserEmail.Text = " ";
            //txtUserZip.Text = "";
            //txtUserAdd.Text = "";
            //txtUserAge.Text = "";
            //txtUserCon.Text = "";
            //txtUserLname.Text = "";
            //txtUserPass.Text = "";
            //txtUserRepass.Text = "";
            //ddUserCity.SelectedIndex = 0;
            //ddUserCity.SelectedIndex = 0;


        }

        protected void ibUserRegister_Click(object sender, ImageClickEventArgs e)
        {
           // string log=null;
           // Random r = new Random();
           // log = txtUserFname.Text + (Convert.ToString(r.Next(1, 2000)));
           // con.Open();
           // com = new SqlCommand("sp_AIPRegistration4", con);
           // com.CommandType = System.Data.CommandType.StoredProcedure;

           // com.Parameters.AddWithValue("login", log);
           // com.Parameters.AddWithValue("@fname",txtUserFname.Text);
           // com.Parameters.AddWithValue("@lname", txtUserLname.Text);
           // com.Parameters.AddWithValue("@password",txtUserPass.Text );
           // com.Parameters.AddWithValue("@age",txtUserAge.Text );
           // com.Parameters.AddWithValue("@gender",gender);
           // com.Parameters.AddWithValue("@contact_no",txtUserCon.Text );
           // com.Parameters.AddWithValue("@e_mail", txtUserEmail.Text);
           // com.Parameters.AddWithValue("@_address",txtUserAdd.Text );
           // com.Parameters.AddWithValue("@_state ",ddUserState.Text );
           // com.Parameters.AddWithValue("@city",ddUserCity.Text );
           // com.Parameters.AddWithValue("@zip", txtUserZip.Text);
           // com.ExecuteNonQuery();
           //MessageBox.Show("Your Login ID is:" + log);
            
           // con.Close();
           // Server.Transfer("AIP_Home.aspx");

            userBO.UFname = txtUserFname.Text;
            userBO.ULname = txtUserLname.Text;
            userBO.Uemail = txtUserEmail.Text;
            userBO.Uaddress = txtUserAdd.Text;
            userBO.Ugender = gender;
            userBO.Ustate = ddUserState.Text;
            userBO.Ucity = ddUserCity.Text;
            userBO.UAge = Convert.ToInt32(txtUserAge.Text);
            userBO.Ucontact = Convert.ToInt32(txtUserCon.Text);
            userBO.UPassword = txtUserPass.Text;
            userBO.Uzip = Convert.ToInt32(txtUserZip.Text);

            int status = userBl.SaveUserRegistrationBL(userBO);
            if (status > 0)
            {
                Response.Redirect("~/AIP_Home.aspx");
            }
            else
            {
                MessageBox.Show("Not Registered Please try again");
            }

        }
    }
}