﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Configuration;
using BussinessObject;
using Bussinesslogic;


namespace AIP
{
    public partial class admin_registration : System.Web.UI.Page
    {
        AdminRegistrationBO AdminBO = new AdminRegistrationBO();
        UsingBL AdminBl = new UsingBL();
        string gender;

        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;

            gender = "";
            if (RblAdmin.SelectedIndex == 1)
            {
                gender = " Male";
            }
            else
            {
                gender = "Female";
            }

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            //txtUserFname.Text = " ";
            //txtUserEmail.Text = " ";
            //txtUserZip.Text = "";
            //txtUserAdd.Text = "";
            //txtUserAge.Text = "";
            //txtUserCon.Text = "";
            //txtUserLname.Text = "";
            //txtUserPass.Text = "";
            //txtUserRepass.Text = "";
            //ddUserCity.SelectedIndex = 0;
            //ddUserCity.SelectedIndex = 0;



        }

        protected void txtAge_TextChanged(object sender, EventArgs e)
        {

        }

        protected void rbmale_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox7_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {


            AdminBO.Aaddress = txtAdd.Text;
            AdminBO.AAge = Convert.ToInt32(txtAge.Text);
            AdminBO.Acity = ddCity.Text;
            AdminBO.Acontact = Convert.ToInt32(txtcontact.Text);
            AdminBO.Aemail = txtEmail.Text;
            AdminBO.AFname = txtFname.Text;
            AdminBO.Agender = gender;
            AdminBO.ALname = txtLname.Text;
            AdminBO.APassword = txtPass.Text;
            AdminBO.Astate = ddState.Text;
            AdminBO.Azip = Convert.ToInt32(txtZip.Text);

            int status = AdminBl.SaveAdminRegistrationBL(AdminBO);
            if (status > 0)
            {
                Response.Redirect("~/AIP_Home.aspx");
            }
            else
            {
                MessageBox.Show("Not Registered Please try again");
            }
        }
    }
}