﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using BussinessObject;
using Bussinesslogic;

namespace AIP
{
    public partial class User_registration : System.Web.UI.Page
    {

        UserRegistrationBO userBO = new UserRegistrationBO();
        UsingBL userBl = new UsingBL();
        string gender;

        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            gender = "";
            if (Rbluser.SelectedIndex == 1)
            {
                gender = " Male";
            }
            else
            {
                gender = "Female";
            }
        }



        protected void txtUserFname_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ibUserReset_Click(object sender, ImageClickEventArgs e)
        {
            //txtUserFname.Text = " ";
            //txtUserEmail.Text = " ";
            //txtUserZip.Text = "";
            //txtUserAdd.Text = "";
            //txtUserAge.Text = "";
            //txtUserCon.Text = "";
            //txtUserLname.Text = "";
            //txtUserPass.Text = "";
            //txtUserRepass.Text = "";
            //ddUserCity.SelectedIndex = 0;
            //ddUserCity.SelectedIndex = 0;


        }

        protected void ibUserRegister_Click(object sender, ImageClickEventArgs e)
        {

            userBO.UFname = txtUserFname.Text;
            userBO.ULname = txtUserLname.Text;
            userBO.Uemail = txtUserEmail.Text;
            userBO.Uaddress = txtUserAdd.Text;
            userBO.Ugender = gender;
            userBO.Ustate = ddUserState.Text;
            userBO.Ucity = ddUserCity.Text;
            userBO.UAge = Convert.ToInt32(txtUserAge.Text);
            userBO.Ucontact = Convert.ToInt32(txtUserCon.Text);
            userBO.UPassword = txtUserPass.Text;
            userBO.Uzip = Convert.ToInt32(txtUserZip.Text);

            int status = userBl.SaveUserRegistrationBL(userBO);
            if (status > 0)
            {
                Response.Redirect("~/AIP_Home.aspx");
            }
            else
            {
                MessageBox.Show("Not Registered Please try again");
            }

        }
    }
}