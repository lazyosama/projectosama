package com.bms.BusinessException;

public class BusinessException extends Exception{

	private static final long serialVersionUID = 1L;
	private String Message=null;
	public BusinessException(){
		 super();
	 }
	public BusinessException(String Message) {
		super(Message);
		this.Message=Message;
	}
	public BusinessException(Throwable cause) {
	    super(cause);
	}
	public String toString() {
	    return Message;
	}
	public String getMessage() {
		return Message;
	}

}
