package com.bms.logging;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * Servlet implementation class LoggerIntializer
 */
public class LoggerIntializer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static Logger LOG =Logger.getLogger(LoggerIntializer.class);
	public void init(ServletConfig config) throws ServletException {
		ServletContext context = config.getServletContext();
		String realPath=context.getRealPath("/");
		String logPropfile= realPath+"WEB-INF\\log4j.properties";
		PropertyConfigurator.configure(logPropfile);
		LOG.info("Application Intialized");
	}
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter out = res.getWriter();
		out.println("Hello! welcome to logging");
		LOG.info("in doGet()");
	}
}
