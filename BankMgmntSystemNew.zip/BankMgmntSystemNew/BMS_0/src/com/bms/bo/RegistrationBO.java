package com.bms.bo;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.RegistrationBean;
import com.bms.dao.RegistrationDAO;
import com.bms.util.PropertyUtil;

public class RegistrationBO {
	RegistrationDAO dao = new RegistrationDAO();
	public static Logger LOG = Logger.getLogger(RegistrationBO.class);
	PropertyUtil util = new PropertyUtil();

	private void emailValid(String mail_id) throws BusinessException,
			SQLException {
		boolean b;
		LOG.info("inside RegistrationBO email valid");
		if (mail_id == null)
			throw new BusinessException("Email cannot be blank");
		String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]"
				+ "\\@([\\w]+\\.)+[\\w]+[\\w]$";
		b = mail_id.matches(EMAIL_REGEX);
		if (b == false)
			throw new BusinessException("Email is not valid");
		int n = 0;
		n = dao.valideMail(mail_id);
		if (n != 0)
			throw new BusinessException(
					"User already registered with this email id");

	}

	private void nameValid(String name) throws BusinessException {
		LOG.info("inside RegistrationBO name valid");
		for (int i = 0; i < name.length(); i++) {
			char c = name.charAt(i);
			if (!Character.isLetter(c) && !Character.isSpace(c)) {
				throw new BusinessException(
						" Name can contain only alphabets and spaces");
			}
		}
	}

	private void guardian_name_valid(String guardian_Name)
			throws BusinessException {
		LOG.info("inside RegistrationBO  guardian name valid");
		for (int i = 0; i < guardian_Name.length(); i++) {
			char c = guardian_Name.charAt(i);
			if (!Character.isLetter(c) && !Character.isSpace(c)) {
				throw new BusinessException(
						"Guardian Name can contain only alphabets and spaces");
			}
		}
	}

	private void guardian_type_valid(String guardian_Type)
			throws BusinessException {
		LOG.info("inside RegistrationBO guardian type valid");
		boolean b;
		String name_regex = "^[\\p{L} .'-]+$";
		b = guardian_Type.matches(name_regex);
		if (b == false)
			throw new BusinessException(
					"Guardian Type is not valid/Can contain only alphabets and spaces");
	}

	private void passwordValid(String password, String repassword)
			throws BusinessException {
		LOG.info("inside RegistrationBO password valid");
		if (password.equals(null))
			throw new BusinessException("Password cannot be blank");
		if (!password.equals(repassword))
			throw new BusinessException(
					"Password and Re-type Password should match");
	}

	private void contactNoValid(long contact_No) throws BusinessException {
		LOG.info("inside RegistrationBO contact number valid");
		String name_regex = "^[1-9][0-9]{9}";
		String s = String.valueOf(contact_No);
		if (!s.matches(name_regex))
			throw new BusinessException(
					"Enter a valid Contact number of 10 digits");
	}

	/*
	 * private void Alternatecontactnovalid(Long Alternatecontact_No)throws
	 * BusinessException { LOG.info("inside RegistrationBO contact number valid"
	 * ); String name_regex = "^[1-9][0-9]{9}"; String s =
	 * String.valueOf(Alternatecontact_No); if (!s.matches(name_regex)) throw
	 * new BusinessException("Enter a valid Contact number of 10 digits"); }
	 */
	private void Reference_account_holder_acc_No(String ref_acc_holder_no,
			String reference_name, String reference_address)
			throws BusinessException, SQLException {
		LOG.info("inside RegistrationBO reference account holder account number validation   ");
		if (ref_acc_holder_no.equals(null))
			throw new BusinessException(
					"Reference account holder account number cannot be blank");
		ArrayList<String> list = new ArrayList<String>();
		list = util.refAccNo(ref_acc_holder_no);
		Iterator<String> iterator = list.iterator();
		int i = 0;
		while (iterator.hasNext()) {
			if ((iterator.next().equalsIgnoreCase(reference_name))) {
				i++;
				if ((iterator.next().equalsIgnoreCase(reference_address))) {
					i++;
				} else
					throw new BusinessException(
							"Invalid reference account holder");
			} else
				throw new BusinessException("Invalid reference account holder");
		}
		LOG.info("inside RegistrationBO  after validating reference account holder account number validation   "
				+ ref_acc_holder_no);
	}

	private void Identification_Document_NoValid(
			String identificationDocument_Number) throws BusinessException,
			SQLException {
		String iddoc_val = "[A-Za-z0-9]{12}[^<>'\"/;`%]*$";
		boolean b = false;
		if (identificationDocument_Number.equals(null))
			throw new BusinessException(
					"Identification document cannot be blank");
		else {
			b = identificationDocument_Number.matches(iddoc_val);

			if (b == false)
				throw new BusinessException("Invalid document number");
			else {
				RegistrationDAO dao = new RegistrationDAO();
				int b1 = 0;
				b1 = dao.validDocNo(identificationDocument_Number);
				if (b1 != 0)
					throw new BusinessException(
							"Identification document number  already exist in the system");
			}
			LOG.info("inside RegistrationBO after validating Identification Document no valid   "
					+ identificationDocument_Number);
		}
	}

	private void Initial_Deposit_AmountValid(float initial_deposit_amount,
			String account_type, String country_name) throws BusinessException {
		LOG.info("inside RegistrationBO initial deposit amount valid");
		if (account_type.equals("Savings")) {
			if (initial_deposit_amount < 5000)
				throw new BusinessException(
						"Initial Deposit Amount should not be less than 5000 for savings account");
			else if (country_name.equals("UK")
					&& initial_deposit_amount < 14000)
				throw new BusinessException(
						"Initial Deposit Amount should not be less than 14000 for UK customer having Salary account");
			else if (country_name.equals("US")
					&& initial_deposit_amount < 15000)
				throw new BusinessException(
						"Initial Deposit Amount should not be less than 14000 for US customer having Salary account");
			else if (country_name.equals("Italy")
					&& initial_deposit_amount < 13000)
				throw new BusinessException(
						"Initial Deposit Amount should not be less than 13000 for Italy customer having Salary account");
		}
	}

	private void registration_dateValid(String regdate)
			throws BusinessException, ParseException {
		LOG.info("inside RegistrationBO registration date valid");
		if (regdate.equals(null))
			throw new BusinessException("Registration date cannot be blank");
		else {
			Date d = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date d2 = sdf.parse(regdate);
			String d1 = sdf.format(d2);
			String d3 = sdf.format(d);
			if (!d1.equals(d3))
				throw new BusinessException(
						"Registration date should be today's date");
		}
	}

	private void ageValid(String date_Of_Birth, String citizen_status)
			throws BusinessException, ParseException {
		LOG.info("inside RegistrationBO age valid");
		if (date_Of_Birth.equals(null))
			throw new BusinessException("Date of birth cannot be blank");
		else {
			if (citizen_status.equals("minor"))
				throw new BusinessException(
						"Customer should be minimum of 18 years");
		}
	}

	public boolean insertUser(RegistrationBean user) throws BusinessException,
			ParseException, ClassNotFoundException, SQLException {
		LOG.info("inside RegistrationBO ,inseruser");
		nameValid(user.getName());
		userName(user.getUserName());
		passwordValid(user.getPassword(), user.getRepassword());
		guardian_type_valid(user.getGuardian_Type());
		guardian_name_valid(user.getGuardian_Name());
		emailValid(user.getEmail_Address());
		contactNoValid(user.getContact_No());
		ageValid(user.getDate_Of_Birth(), user.getCitizen_status());
		registration_dateValid(user.getRegdate());
		Initial_Deposit_AmountValid(user.getInitial_deposit_amount(),
				user.getAccount_type(), user.getCountry());
		Identification_Document_NoValid(user.getIdentificationDocument_Number());
		Reference_account_holder_acc_No(user.getRef_acc_holder_no(),
				user.getRef_acc_holder_name(), user.getRef_acc_holder_address());
		boolean flag = false;

		try {
			boolean flag1 = dao.insertUser(user);

			if (flag1 == true)
				flag = true;
			else
				flag = false;
		} catch (SQLException e) {
			LOG.error("error occured in RegisterBO" + e.getMessage());
			e.printStackTrace();
			// System.out.println(".......................................tuyutyuu");
			flag = false;
		}

		return flag;
	}

	private void userName(String user_name) throws BusinessException,
			SQLException {
		LOG.info("inside RegistrationBO ,username valid");
		if (user_name.equals(null))
			throw new BusinessException("UserName  cannot be blank");
		else {
			RegistrationDAO db = new RegistrationDAO();
			int b = 0;
			b = db.validUserName(user_name);
			if (b != 0)
				throw new BusinessException(
						"UserName  already exist in the system");
		}
	}
}
