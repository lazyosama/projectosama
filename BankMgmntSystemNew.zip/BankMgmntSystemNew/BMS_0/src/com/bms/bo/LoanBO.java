package com.bms.bo;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.LoanBean;
import com.bms.dao.LoanDAO;

public class LoanBO {
	public static Logger LOG = Logger.getLogger(LoanBO.class);

	private void invalidCurrentExp(int x, int y, String s)
			throws BusinessException {
		LOG.info("inside LoanBO" + x + y + s);
		if (s.equalsIgnoreCase("Educational")) {
			if (y > x)
				throw new BusinessException(
						"Invalid Father's Experience with current company.");
		} else {
			if (y > x) {
				throw new BusinessException(
						"Invalid Experience with current company.");
			}
		}
	}

	public Boolean insertLoanDetails(LoanBean loan) throws BusinessException,
			ParseException, ClassNotFoundException, SQLException {
		LOG.info("inside LoanBO" + loan.getLoanType());
		duration_of_loanValidate(loan.getDurationLoan());
		if (loan.getLoanType().equalsIgnoreCase("educational"))
			invalidCurrentExp(loan.getFatherTotalExp(), loan.getFatherExpwCC(),
					loan.getLoanType());
		if (!loan.getLoanType().equalsIgnoreCase("educational")) {
			invalidCurrentExp(loan.getTotalExp(), loan.getExpCC(),
					loan.getLoanType());
		}
		checkApplyDate(loan);
		createLoanId(loan);
		createLoanAccNo(loan);
		calculateEMI(loan);
		boolean flag = false;
		LoanDAO ld = new LoanDAO();
		try {
			ld.insertLoanDetails(loan);
			flag = true;
		} catch (SQLException e) {
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}

	private void calculateEMI(LoanBean loan) {
		LOG.info("inside LoanBO");
		double n = loan.getDurationLoan() * 12;
		double r = loan.getRateOfInterest() / 1200;
		double x = Math.pow(loan.getRateOfInterest() / 1200 + 1, n);
		double p = loan.getLoanAmount();
		double emi = ((p * r) * x) / (x - 1);
		loan.setEMI(emi);
	}

	public void checkInitialDeposit(String CusId)
			throws ClassNotFoundException, SQLException, BusinessException {
		LOG.info("inside LoanBO");
		LoanDAO ld = new LoanDAO();
		double d = ld.getInitialDeposit(CusId);
		if (d <= 0) {
			throw new BusinessException(
					"Initial Deposit too low to apply for loan");
		}
	}

	public void checkApplyDate(LoanBean loan) throws ParseException,
			BusinessException {
		LOG.info("inside LoanBO");
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date fill = sdf.parse(loan.getLoanApplyDate());
		String s = sdf.format(d);
		d = sdf.parse(s);
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		long y = c.getTimeInMillis();
		c.setTime(fill);
		long x = c.getTimeInMillis();
		if (x < y) {
			throw new BusinessException("Invalid Loan Apply Date");
		} else {
			c.add(Calendar.DATE, 15);
			Date d3 = c.getTime();
			s = sdf.format(d3);
			loan.setLoanIssueDate(s);
		}
	}

	private void createLoanId(LoanBean loan) throws ClassNotFoundException,
			SQLException {
		LOG.info("inside LoanBO");
		LoanDAO ld = new LoanDAO();
		String s[] = ld.getLoanId();
		int numcheck = Integer.parseInt(s[0]);
		if (numcheck != 0) {
			StringTokenizer st = new StringTokenizer(s[1], "-");
			String x = st.nextToken();
			String y = st.nextToken();
			StringBuffer sb = new StringBuffer();
			sb.append(x);
			sb.append('-');
			Integer num = Integer.parseInt(y);
			num = num + 1;
			y = Integer.toString(num);
			if (y.length() < 3) {
				for (int i = 0; i < (3 - y.length()); i++) {
					sb.append(0);
				}
			}
			sb.append(y);
			s[1] = sb.toString();
			loan.setLoanId(s[1]);
		} else {
			loan.setLoanId("L-001");
		}
	}

	private void createLoanAccNo(LoanBean loan) throws ClassNotFoundException,
			SQLException {
		LOG.info("inside LoanBO");
		LoanDAO ld = new LoanDAO();
		String s[] = ld.getLoanAccNo();
		int numcheck = Integer.parseInt(s[0]);
		if (numcheck != 0) {
			StringBuffer sb = new StringBuffer();
			numcheck += 1;
			String y = Integer.toString(numcheck);
			if (y.length() < 16) {
				for (int i = 0; i < (16 - y.length()); i++) {
					sb.append(0);
				}
			}
			sb.append(y);
			s[1] = sb.toString();
			loan.setLoanAccNo(s[1]);
		} else {
			loan.setLoanAccNo("1000000000000001");
		}
	}

	private void duration_of_loanValidate(int durationLoan)
			throws BusinessException {
		LOG.info("inside LoanBO");
		if (durationLoan != 5 && durationLoan != 10 && durationLoan != 15
				&& durationLoan != 20) {
			throw new BusinessException("Search Found No Relevant Results.");
		}
	}
}
