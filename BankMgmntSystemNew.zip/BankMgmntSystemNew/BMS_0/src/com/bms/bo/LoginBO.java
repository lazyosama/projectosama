package com.bms.bo;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.bms.bean.LoginBean;
import com.bms.dao.LoginDAO;

public class LoginBO {
	public static Logger LOG = Logger.getLogger(LoginBO.class);
	LoginDAO ld = null;

	public String checkLogin(LoginBean lb) throws ClassNotFoundException,
			SQLException {
		// LOG.info("inside LoginBO");
		ld = new LoginDAO();
		String s = ld.checkLogin(lb);
		return s;
	}
}
