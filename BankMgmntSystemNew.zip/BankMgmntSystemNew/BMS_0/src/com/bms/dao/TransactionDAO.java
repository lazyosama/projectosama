package com.bms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.TransactionBean;
import com.bms.util.PropertyUtil;

public class TransactionDAO {
	public static Logger LOG = Logger.getLogger(TransactionDAO.class);
	private Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	PreparedStatement prep = null;
	Statement stmt1 = null;
	PropertyUtil util = new PropertyUtil();

	public boolean checkAcc(String account, String Transaction_Type,
			String CustId) throws ClassNotFoundException, SQLException {
		Boolean b = false;
		String sql = "";
		LOG.info("Inside TransactionDAO class-check Account method ");
		try {
			conn = util.connections();
			if (Transaction_Type.equalsIgnoreCase("Loan EMI Debit")) {
				String account1 = getCustAccNo(CustId);
				sql = "select Loan_Acc_No from Loan_Details where Loan_Acc_No like '"
						+ account
						+ "' and Account_Number like '"
						+ account1
						+ "'";
			} else {
				sql = "select Account_Number from account_info where Account_Number like '"
						+ account + "'";
			}
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				b = true;
			} else
				b = false;
		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return b;
	}

	private String[] getLoanId(String LoanAccNo) throws SQLException,
			ClassNotFoundException {
		String[] loanid = { "0", "0", "0" };
		try {
			conn = util.connections();
			stmt = conn.createStatement();
			String sql = "select Loan_Id from Loan_Details where Loan_Acc_No like "
					+ "'" + LoanAccNo + "'";
			rs = stmt.executeQuery(sql);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				loanid[1] = rs.getString(1);
				loanid[0] = "1";
			}
		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return loanid;
	}

	public TransactionBean FetchDetails(String account, String TranType,
			String CustId) throws SQLException, BusinessException,
			ClassNotFoundException {
		TransactionBean bean = new TransactionBean();
		LOG.info("Inside TransactionDAO-Fetch Details method ");
		try {
			conn = util.connections();
			String sql = "";
			if (TranType.equalsIgnoreCase("Loan EMI Debit")) {
				account = getCustAccNo(CustId);
				bean.setAccount_Number(account);
			}
			sql = "select Customer_Id, Account_Number, Account_Type from account_info where Account_Number='"
					+ account + "'";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			String cid = new String();
			if (rs.next()) {
				cid = rs.getString("Customer_Id");
				bean.setAccount_Number(rs.getString("Account_Number"));
				bean.setAccount_Type(rs.getString("Account_Type"));
			} else
				bean = null;
			String sqlname = "select Name from customer_details where Customer_Id='"
					+ cid + "'";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sqlname);
			if (rs.next()) {
				bean.setAccount_Holder_Name(rs.getString(1));
			} else
				bean = null;
		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return bean;
	}

	public String getCustAccNo(String Custid) throws SQLException,
			ClassNotFoundException {
		String accno = "";
		try {
			conn = util.connections();
			String sql = "select Account_Number from account_info where Customer_Id ='"
					+ Custid + "'";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				accno = rs.getString(1);
			}
		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return accno;
	}

	public ArrayList<Integer> checkAmount(TransactionBean user,
			String custidofLogin) throws SQLException, ClassNotFoundException {
		LOG.info("inside TransactionDAO- method check Amount");
		ArrayList<Integer> list = new ArrayList<Integer>();
		try {
			Double idm = 0.0, ab = 0.0;
			String s = "";
			conn = util.connections();
			StringTokenizer str = new StringTokenizer(user.getAccount_Number(),
					" ");
			String s1 = str.nextToken();
			if (user.getTransaction_Type().equalsIgnoreCase("Deposit")) { // DEPOSIT
				String query = "select Initial_Deposit_Amount,Account_Balance,Account_Type from account_info where Account_Number="
						+ "(select Account_Number from account_info where Customer_Id='"
						+ custidofLogin + "')";
				stmt = conn.createStatement();
				rs = stmt.executeQuery(query);
				while (rs.next()) {
					idm = rs.getDouble(1);
					ab = rs.getDouble(2);
					s = rs.getString(3);
				}
				if (s.equalsIgnoreCase("Savings")) {
					if (ab < user.getAmount())
						list.add(1);
					else if ((ab - user.getAmount()) < 5000)
						list.add(2);
				}

				else if (s.equalsIgnoreCase("Salary")) {
					if (ab < user.getAmount())
						list.add(1);
					else if ((ab - user.getAmount()) < 0)
						list.add(2);
				}
			}
			if (user.getTransaction_Type().equalsIgnoreCase("withdrawl")) { // WITHDRAWL
				String qu = "select Initial_Deposit_Amount,Account_Balance,Account_Type from account_info where Account_Number='"
						+ s1 + "'";
				stmt = conn.createStatement();
				rs = stmt.executeQuery(qu);
				while (rs.next()) {
					idm = rs.getDouble(1);
					ab = rs.getDouble(2);
					s = rs.getString(3);
				}
				if (s.equalsIgnoreCase("Savings")) {
					if (ab < user.getAmount())
						list.add(4);
					else if ((ab - user.getAmount()) < 5000)
						list.add(5);
				}

				else if (s.equalsIgnoreCase("Salary")) {
					if (ab < user.getAmount())
						list.add(4);
					else if ((ab - user.getAmount()) < 0)
						list.add(5);
				}
			}
			if (user.getTransaction_Type().equalsIgnoreCase("Loan EMI Debit")) {
				String qu = "select Loan_Amount from Loan_Details where Loan_Acc_No='"
						+ s1 + "'";
				stmt = conn.createStatement();
				rs = stmt.executeQuery(qu);
				Double balance = 0.0;
				while (rs.next()) {
					balance = rs.getDouble(1);
				}
				if (balance <= 0) {
					list.add(7);
				} else if (balance < user.getAmount())
					list.add(8);
			}
		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return list;
	}

	public String[] insertUser(TransactionBean user, String Custid)
			throws ClassNotFoundException, ParseException, BusinessException,
			ClassNotFoundException, SQLException {
		String[] check = { "0", "0", "0" };
		try {
			conn = util.connections();
			LOG.info("Inside RegistrationDAO-insertuser method ");
			StringTokenizer str = new StringTokenizer(user.getAccount_Number(),
					" ");
			String s1 = str.nextToken();
			String id = generateTrantId();
			String balance = "";
			String loanid[] = getLoanId(s1);
			if (user.getTransaction_Type().equalsIgnoreCase("Withdrawal")) {
				String dep = "update account_info set Account_Balance=(Account_Balance+"
						+ user.getAmount()
						+ ") where Account_Number like '"
						+ s1 + "'";
				String with = "update account_info set Account_Balance=(Account_Balance-"
						+ user.getAmount()
						+ ") where Account_Number like '"
						+ getCustAccNo(Custid) + "'";
				stmt = conn.createStatement();
				stmt1 = conn.createStatement();
				if (stmt.executeUpdate(dep) > 0
						&& stmt1.executeUpdate(with) > 0)
					check[0] = "1";
				balance = getRemBalance(Custid, user.getTransaction_Type(),
						user.getAccount_Number());
				String qryString = "insert into Transaction_Details(Transaction_Id,Account_Number,"
						+ "Transaction_Type,Transaction_Date,Transaction_Amount,Description,Cheque_Number,balance) values (?,?,?,?,?,?,?,?)";

				prep = conn.prepareStatement(qryString);
				prep.setString(1, id);
				prep.setString(2, getCustAccNo(Custid));
				prep.setString(3, user.getTransaction_Type());
				prep.setDate(4,
						util.utilDateToSqlDate(user.getTransaction_Date()));
				prep.setDouble(5, user.getAmount());
				prep.setString(6, "Deposit to: " + user.getAccount_Number());
				prep.setString(7, "----");
				prep.setString(8, balance);
				if (prep.executeUpdate() > 0)
					check[0] = "1";
				else
					check[0] = "0";
			} else if (user.getTransaction_Type().equalsIgnoreCase("Deposit")) {
				String dep = "update account_info set  Account_Balance=(Account_Balance-"
						+ user.getAmount()
						+ ") where Account_Number like'"
						+ s1 + "'";
				String with = "update account_info set Account_Balance=(Account_Balance+"
						+ user.getAmount()
						+ ") where Account_Number like '"
						+ getCustAccNo(Custid) + "'";
				stmt = conn.createStatement();
				stmt1 = conn.createStatement();
				if (stmt.executeUpdate(dep) > 0
						&& stmt1.executeUpdate(with) > 0)
					check[0] = "1";
				balance = getRemBalance(Custid, user.getTransaction_Type(),
						user.getAccount_Number());
				String qryString = "insert into Transaction_Details(Transaction_Id,Account_Number,"
						+ "Transaction_Type,Transaction_Date,Transaction_Amount,Description,Cheque_Number,balance) values (?,?,?,?,?,?,?,?)";
				prep = conn.prepareStatement(qryString);
				prep.setString(1, id);
				prep.setString(2, getCustAccNo(Custid));
				prep.setString(3, user.getTransaction_Type());
				prep.setDate(4,
						util.utilDateToSqlDate(user.getTransaction_Date()));
				prep.setDouble(5, user.getAmount());
				prep.setString(6,
						"Withdrawal From account: " + user.getAccount_Number());
				prep.setString(7, "----");
				prep.setString(8, balance);
				if (prep.executeUpdate() > 0)
					check[0] = "1";
				else
					check[0] = "0";
			} else if (user.getTransaction_Type().equalsIgnoreCase(
					"Loan EMI Debit")) {
				String update = "update Loan_Details set Loan_Amount=(Loan_Amount-"
						+ user.getAmount()
						+ ") where Loan_id like'"
						+ loanid[1] + "'";
				stmt = conn.createStatement();
				if (stmt.executeUpdate(update) > 0)
					check[0] = "1";
				balance = getRemBalance(Custid, user.getTransaction_Type(),
						user.getAccount_Number());
				String qryString = "insert into Transaction_Details(Transaction_Id,Account_Number,"
						+ "Transaction_Type,Transaction_Date,Transaction_Amount,Description,Loan_Id,balance,Cheque_Number) values (?,?,?,?,?,?,?,?,?)";
				PreparedStatement prep = conn.prepareStatement(qryString);
				prep.setString(1, id);
				prep.setString(2, getCustAccNo(Custid));
				prep.setString(3, user.getTransaction_Type());
				prep.setDate(4,
						util.utilDateToSqlDate(user.getTransaction_Date()));
				prep.setDouble(5, user.getAmount());
				prep.setString(6, "EMI debit from: " + user.getAccount_Number());
				prep.setString(7, loanid[1]);
				prep.setString(8, balance);
				prep.setString(9, "----");
				if (prep.executeUpdate() > 0)
					check[0] = "1";
				else
					check[0] = "0";
			}
			check[1] = balance;
			check[2] = id;
		} finally {
			if (stmt != null)
				stmt.close();
			if (prep != null)
				prep.close();
		}
		return check;
	}

	private String getRemBalance(String Custid, String TranType,
			String Loan_Acc_No) throws SQLException, ClassNotFoundException {
		String sql = null;
		String balance = "";
		String loanid[];
		try {
			StringTokenizer str = new StringTokenizer(Loan_Acc_No, " ");
			String s1 = str.nextToken();
			loanid = getLoanId(s1);
			conn = util.connections();
			if (TranType.equalsIgnoreCase("Loan EMI Debit")) {
				sql = "select Loan_Amount from Loan_Details where Loan_Id ='"
						+ loanid[1] + "'";
			} else {
				sql = "select Account_Balance from account_info where Customer_Id ='"
						+ Custid + "'";
			}
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				balance = rs.getString(1);
			}
		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return balance;
	}

	private String generateTrantId() throws SQLException,
			ClassNotFoundException {
		LOG.info("inside TransactionDAO-generation of Transaction ID");
		StringBuffer sb = new StringBuffer();
		try {
			conn = util.connections();
			String sql = "select count(*) from transaction_details";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			String s = "";
			int num = 0;
			if (rs.next()) {
				num = rs.getInt(1);
			}
			if (num > 0) {
				sql = "select max(Transaction_Id) from transaction_details";
				rs = stmt.executeQuery(sql);
				if (rs.next())
					s = rs.getString(1);
				sb.append(s.substring(0, 1));
				long l = Long.valueOf((String) s.substring(1, s.length()));
				l = l + 1;
				sb.append(String.valueOf(l));
			} else
				sb.append("T211100");
		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return sb.toString();
	}

}
