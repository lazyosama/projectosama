package com.bms.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;

import com.bms.bean.UpdateBean;
import com.bms.util.PropertyUtil;

public class UpdateDAO {
	public static Logger LOG = Logger.getLogger(UpdateDAO.class);
	private Connection conn = null;
	Statement stmt = null;
	Statement stmt1 = null;
	Statement stmt2 = null;
	ResultSet rs = null;
	PropertyUtil util = new PropertyUtil();

	public UpdateBean getCustomer_details(String CustId) throws SQLException,
			ParseException, ClassNotFoundException {
		LOG.info(" UpdateDAO Inside DAO,getcustomer_details");
		UpdateBean bean = new UpdateBean();
		try {
			conn = util.connections();
			String sql = "select Name, Gender,Date_Of_Birth, Address,AlternateAddress,Contact_Number,AlternateContact_Number,Email_Address, Marital_Status,  Guardian_Type,Guardian_Name ,Citizenship from Customer_details where Customer_Id like "
					+ "'" + CustId + "'";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				bean.setName(rs.getString(1));
				bean.setGender(rs.getString(2));
				java.sql.Date sqld = rs.getDate(3);
				java.util.Date utilDate = new java.util.Date(sqld.getTime());
				SimpleDateFormat formatDateJava = new SimpleDateFormat(
						"yyyy/MM/dd");
				String date_to_string = formatDateJava.format(utilDate);
				bean.setDOB(date_to_string);
				bean.setAddress(rs.getString(4));
				bean.setAlternateAddress(rs.getString(5));
				bean.setContact_number(Long.parseLong(rs.getString(6)));
				bean.setAlternateContact_number(Long.parseLong(rs.getString(7)));
				bean.setMail_Id(rs.getString(8));
				bean.setMarital_Status(rs.getString(9));
				bean.setGuardian_Type(rs.getString(10));
				bean.setGuardian_Name(rs.getString(11));
				bean.setCitizenship(rs.getString(12));
			}
			String sql1 = "select Account_Number,Registration_Date, reference_acc_number,Account_Type from account_info where Customer_Id like "
					+ "'" + CustId + "'";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql1);
			while (rs.next()) {
				bean.setAccount_Number(rs.getString(1));
				java.sql.Date sqld1 = rs.getDate(2);
				java.util.Date utilDate1 = new java.util.Date(sqld1.getTime());
				SimpleDateFormat formatDateJava1 = new SimpleDateFormat(
						"yyyy/MM/dd");
				String date_to_string1 = formatDateJava1.format(utilDate1);
				bean.setRegistration_Date(date_to_string1);
				bean.setReference_account_holder_account_number(rs.getString(3));
				bean.setAccount_Type(rs.getString(4));
			}
			String sql2 = "select Country_Name,State from country_details where Country_Id in (select Country_Id from Customer_details where Customer_Id like "
					+ "'" + CustId + "')";
			rs = stmt.executeQuery(sql2);
			while (rs.next()) {
				bean.setCountry(rs.getString(1));
				bean.setState(rs.getString(2));
			}
			String s3 = "select IdentificationProof_Type, IdentificationDocument_Number from identification where Customer_Id like "
					+ "'" + CustId + "'";
			rs = stmt.executeQuery(s3);
			while (rs.next()) {
				bean.setIdentification_proof_type(rs.getString(1));
				bean.setIdentification_doc_number(rs.getString(2));
			}
			String s4 = "select IFSC_Code, Branch_Name from branch_info where IFSC_Code in(select IFSC_Code from account_info where Customer_Id like "
					+ "'" + CustId + "')";
			rs = stmt.executeQuery(s4);
			while (rs.next()) {
				bean.setIFSC_Code(rs.getString(1));
				bean.setBranch_Name(rs.getString(2));
			}
			String sql3 = "select Name,Address from customer_details where Customer_Id=(select Customer_Id from account_info where Account_Number='"
					+ bean.getReference_account_holder_account_number() + "')";
			rs = stmt.executeQuery(sql3);
			while (rs.next()) {
				bean.setReference_account_holder_name(rs.getString(1));
				bean.setReference_account_holder_address(rs.getString(2));
			}
			stmt = conn.createStatement();
			String sql4 = "select Loan_Issue_Date,Loan_Amount,Loan_Id,Loan_Type from Loan_Details where Account_Number like "
					+ "'" + bean.getAccount_Number() + "'";
			rs = stmt.executeQuery(sql4);
			while (rs.next()) {
				bean.setLoan_Issue_Date(rs.getString(1));

				bean.setLoan_Amount(rs.getString(2));

				if (rs.getString(3) != null) {
					bean.setLoan_Status("Active");
				} else {
					bean.setLoan_Status("InActive");
				}
				bean.setLoan_Type(rs.getString(4));

			}

		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return bean;
	}

	public boolean updateUser(UpdateBean user) throws SQLException,
			ParseException, ClassNotFoundException {
		LOG.info("inside UpdateDAO  inside updateuser()" + user);
		boolean flag = false;
		try {
			conn = util.connections();
			stmt = conn.createStatement();
			String coun = util.generateCountryId(user.getCountry(),
					user.getState());
			String sql = "UPDATE Customer_Details " + "SET Name ='"
					+ user.getName() + "',Guardian_Name='"
					+ user.getGuardian_Name() + "',Guardian_Type='"
					+ user.getGuardian_Type() + "',Address='"
					+ user.getAddress() + "',AlternateAddress='"
					+ user.getAlternateAddress() + "',Email_Address='"
					+ user.getMail_Id() + "',Gender='" + user.getGender()
					+ "',Marital_Status='" + user.getMarital_Status()
					+ "',Contact_Number='" + user.getContact_number()
					+ "',AlternateContact_Number='"
					+ user.getAlternateContact_number() + "',Date_Of_Birth='"
					+ util.utilDateToSqlDate(user.getDOB()) + "',Citizenship='"
					+ user.getCitizenship() + "',Country_Id='" + coun
					+ "' WHERE Customer_Id='" + user.getCustomer_Id() + "';";
			stmt1 = conn.createStatement();
			String sql1 = "UPDATE Identification "
					+ "SET IdentificationProof_Type='"
					+ user.getIdentification_proof_type()
					+ "',IdentificationDocument_Number='"
					+ user.getIdentification_doc_number()
					+ "'WHERE customer_id='" + user.getCustomer_Id() + "';";
			stmt2 = conn.createStatement();
			String sql2 = "UPDATE account_info SET IFSC_Code='"
					+ util.generateIFSC(user.getBranch_Name())
					+ "', reference_acc_number ='"
					+ user.getReference_account_holder_account_number()
					+ "' WHERE Customer_Id='" + user.getCustomer_Id() + "';";
			if ((stmt.executeUpdate(sql)) > 0)
				if ((stmt1.executeUpdate(sql1)) > 0)
					if ((stmt2.executeUpdate(sql2)) > 0)
						flag = true;
		} finally {
			if (rs != null)
				rs.close();
			if (stmt2 != null)
				stmt2.close();
			if (stmt1 != null)
				stmt1.close();
			if (stmt != null)
				stmt.close();
		}
		return flag;
	}

	public boolean validDocNo(String identification_doc_number, String Cust_id)
			throws SQLException {
		LOG.info("inside UpdateDAO valid identification document no from database");
		boolean b = false;
		Connection conn = null;
		conn = util.connections();
		java.sql.Statement stmt = conn.createStatement();
		String query = "Select IdentificationDocument_Number from identification where Customer_Id not in ('"
				+ Cust_id + "')";
		ResultSet rs = stmt.executeQuery(query);
		while (rs.next()) {
			if (rs.getString(1).equals(identification_doc_number))
				b = true;
		}
		return b;
	}
}
