package com.bms.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class RegistrationBean {
	private String Name;
	private String UserName;
	private String Guardian_Name;
	private String Guardian_Type;
	private String Address;
	private String AlternateAddress;
	private String Email_Address;
	private String Gender;
	private String Marital_Status;
	private Long Contact_No;
	private Long AlternateContact_No;
	private String Date_Of_Birth;
	private String Country;
	private String State;
	private String IdentificationProof_Type;
	private String IdentificationDocument_Number;
	private String password;
	private String repassword;
	private String regdate;
	private String account_type;
	private String branch_name;
	private String citizenship;
	private String  citizen_status;
	private String  ref_acc_holder_name;
	private String ref_acc_holder_no;
	private String ref_acc_holder_address;
	private float initial_deposit_amount;
	private String Customer_Id;
	private String account_number;
	
		
	
	public String getAccount_number() {
		return account_number;
	}
	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}
	public String getCustomer_Id() {
		return Customer_Id;
	}
	public void setCustomer_Id(String customer_Id) {
		Customer_Id = customer_Id;
	}
	public String getRef_acc_holder_address() {
		return ref_acc_holder_address;
	}
	public void setRef_acc_holder_address(String ref_acc_holder_address) {
		this.ref_acc_holder_address = ref_acc_holder_address;
	}
	public float getInitial_deposit_amount() {
		return initial_deposit_amount;
	}
	public void setInitial_deposit_amount(float f) {
		this.initial_deposit_amount = f;
	}
	public String getCitizen_status() {
		return citizen_status;
	}
	
	public String getRef_acc_holder_name() {
		return ref_acc_holder_name;
	}
	public void setRef_acc_holder_name(String ref_acc_holder_name) {
		this.ref_acc_holder_name = ref_acc_holder_name;
	}
	public String getRef_acc_holder_no() {
		return ref_acc_holder_no;
	}
	public void setRef_acc_holder_no(String ref_acc_holder_no) {
		this.ref_acc_holder_no = ref_acc_holder_no;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public String getBranch_name() {
		return branch_name;
	}
	public void setBranch_name(String branch_name) {
		this.branch_name = branch_name;
	}
	public String getCitizenship() {
		return citizenship;
	}
	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRepassword() {
		return repassword;
	}
	public void setRepassword(String repassword) {
		this.repassword = repassword;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getGuardian_Name() {
		return Guardian_Name;
	}
	public void setGuardian_Name(String guardian_Name) {
		Guardian_Name = guardian_Name;
	}
	public String getGuardian_Type() {
		return Guardian_Type;
	}
	public void setGuardian_Type(String guardian_Type) {
		Guardian_Type = guardian_Type;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getAlternateAddress() {
		return AlternateAddress;
	}
	public void setAlternateAddress(String Alternateaddress) {
		AlternateAddress = Alternateaddress;
	}
	
	
	public String getEmail_Address() {
		return Email_Address;
	}
	public void setEmail_Address(String email_Address) {
		Email_Address = email_Address;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getMarital_Status() {
		return Marital_Status;
	}
	public void setMarital_Status(String marital_Status) {
		Marital_Status = marital_Status;
	}
	public Long getContact_No() {
		//System.out.println(Contact_No);
		return Contact_No;
	}
	public void setContact_No(Long contact_No) {
		Contact_No = contact_No;
	}
	public Long getAlternateContact_No() {
		System.out.println(AlternateContact_No);
		return AlternateContact_No;
	}
	public void setAlternateContact_No(Long Alternatecontactno) {
		AlternateContact_No = Alternatecontactno;
	}
	public String getDate_Of_Birth() {
		return Date_Of_Birth;
	}
	public void setDate_Of_Birth(String date_Of_Birth) throws ParseException {
		Date_Of_Birth = date_Of_Birth;		
		Date curr= new Date();
		Calendar c1= Calendar.getInstance();
		c1.setTime(curr);
		Long l=c1.getTimeInMillis();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");		
		Date d2= sdf.parse(date_Of_Birth);
		c1.setTime(d2);
		Long l2=c1.getTimeInMillis();
		long age=( (l-l2)/(1000));
		age/=3600;
		age/=24;
		age/=365;
		if(age<18)
			this.citizen_status="minor";
		else if(age>=18&&age<60)
			this.citizen_status="normal";
		else
			this.citizen_status="senior";
		
		
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	

	 
	public String getIdentificationProof_Type() {
		return IdentificationProof_Type;
	}
	public void setIdentificationProof_Type(String identificationProof_Type) {
		IdentificationProof_Type = identificationProof_Type;
	}
	public String getIdentificationDocument_Number() {
		return IdentificationDocument_Number;
	}
	public void setIdentificationDocument_Number(
			String identificationDocument_Number) {
		IdentificationDocument_Number = identificationDocument_Number;
	}
	
	
}
