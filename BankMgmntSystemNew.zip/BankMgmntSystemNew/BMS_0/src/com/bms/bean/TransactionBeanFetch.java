package com.bms.bean;

public class TransactionBeanFetch {

	private String Account_Number;

	public String getAccount_Number() {
		return Account_Number;
	}

	public void setAccount_Number(String account_Number) {
		Account_Number = account_Number;
	}


}