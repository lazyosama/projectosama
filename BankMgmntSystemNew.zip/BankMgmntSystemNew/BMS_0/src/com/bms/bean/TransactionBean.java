package com.bms.bean;

public class TransactionBean {
	private String Account_Number;
    private String Account_Holder_Name;
    private String Cheque_Number;
    private String Account_Type;
    private String Transaction_Type;
    private String Transaction_Date;
    private Double Amount;
	public String getAccount_Number() {
		return Account_Number;
	}
	public void setAccount_Number(String account_Number) {
		Account_Number = account_Number;
	}
	public String getAccount_Holder_Name() {
		return Account_Holder_Name;
	}
	public void setAccount_Holder_Name(String account_Holder_Name) {
		Account_Holder_Name = account_Holder_Name;
	}
	public String getAccount_Type() {
		return Account_Type;
	}
	public void setAccount_Type(String account_Type) {
		Account_Type = account_Type;
	}
	public String getTransaction_Type() {
		return Transaction_Type;
	}
	public void setTransaction_Type(String transaction_Type) {
		Transaction_Type = transaction_Type;
	}
	public String getTransaction_Date() {
		return Transaction_Date;
	}
	public void setTransaction_Date(String transaction_Date) {
		Transaction_Date = transaction_Date;
	}
	public Double getAmount() {
		return Amount;
	}
	public void setAmount(Double amount) {
		Amount = amount;
	}
	
	public void setCheque_Number(String cheque_Number) {
		Cheque_Number = cheque_Number;
	}
	public String getCheque_Number() {
		return Cheque_Number;
	}
    

}