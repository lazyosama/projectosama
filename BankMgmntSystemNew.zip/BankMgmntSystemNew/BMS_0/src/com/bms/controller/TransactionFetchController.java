package com.bms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.TransactionBean;
import com.bms.dao.TransactionDAO;

public class TransactionFetchController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static Logger LOG = Logger
			.getLogger(TransactionFetchController.class);
	TransactionBean bean = null;
	TransactionDAO dao = null;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		// LOG.info("inside Transaction Fetch Controller-do post");

		String CustId = (String) session.getAttribute("Customer_Id");

		bean = new TransactionBean();
		dao = new TransactionDAO();

		try {
			if (request.getParameter("fundtransfer").isEmpty())
				throw new BusinessException("Invalid Fund type.");
			if (request.getParameter("trantype").isEmpty())
				throw new BusinessException("Invalid Transaction type.");

			String Transaction_Type = request.getParameter("trantype");
			bean.setTransaction_Type(Transaction_Type);

			if (!request.getParameter("account_number").isEmpty()) {
			} else
				throw new BusinessException(
						"Invalid Account Number/Loan Account Number");

			String accountnumber = request.getParameter("account_number");
			for (int i = 0; i < accountnumber.length(); i++) {
				if (!Character.isDigit(accountnumber.charAt(i)))
					throw new BusinessException(
							"Invalid Account Number/Loan Account Number");
			}

			bean.setAccount_Number(accountnumber);

			String CustAccNo = dao.getCustAccNo(CustId);

			if (CustAccNo.equalsIgnoreCase(bean.getAccount_Number()))
				throw new BusinessException(
						"Sorry!! Transaction can not be performed within same account.");
			if (dao.checkAcc(bean.getAccount_Number(),
					bean.getTransaction_Type(), CustId)) {
				session.setAttribute("object", bean);
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("Transaction.jsp");
				dispatcher.forward(request, response);
			} else {
				if (bean.getTransaction_Type().equalsIgnoreCase(
						"Loan EMI Debit")) {
					request.setAttribute("message",
							"Loan Account Number not found");
					RequestDispatcher disp = request
							.getRequestDispatcher("TransactionFetch.jsp");
					disp.forward(request, response);
				} else {
					request.setAttribute("message", "Account number not found");
					RequestDispatcher disp = request
							.getRequestDispatcher("TransactionFetch.jsp");
					disp.forward(request, response);
				}
			}

		} catch (BusinessException e) {
			// LOG.error("inside Transaction Fetch controller  error occurs"
			// + e.getMessage());
			request.setAttribute("message", e.getMessage());
			RequestDispatcher dispatch = request
					.getRequestDispatcher("TransactionFetch.jsp");
			dispatch.forward(request, response);
		} catch (Exception e) {
			// LOG.error("inside Transaction Fetch controller  error occurs"
			// + e.getMessage());
			request.setAttribute("message", "error");
			RequestDispatcher dispatch = request
					.getRequestDispatcher("TransactionFetch.jsp");
			dispatch.forward(request, response);
		}
	}
}
