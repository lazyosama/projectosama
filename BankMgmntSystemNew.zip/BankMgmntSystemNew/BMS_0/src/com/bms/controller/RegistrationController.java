package com.bms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.RegistrationBean;
import com.bms.bo.RegistrationBO;

public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static Logger LOG = Logger.getLogger(RegistrationController.class);
	RegistrationBean user = null;
	RegistrationBO regbo = null;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		Boolean flag = false;
		LOG.info("inside Registration controller");
		user = new RegistrationBean();
		regbo = new RegistrationBO();
		try {
			if (request.getParameter("name").isEmpty())
				throw new BusinessException("Name cannot be blank");
			else
				user.setName(request.getParameter("name"));
			LOG.info("inside Registration controller after intializing name");
			if (request.getParameter("username").isEmpty())
				throw new BusinessException("User Name cannot be blank");
			else
				user.setUserName(request.getParameter("username"));
			if (request.getParameter("password").isEmpty())
				throw new BusinessException("Password cannot be blank");
			else
				user.setPassword(request.getParameter("password"));
			if (request.getParameter("repass").isEmpty())
				throw new BusinessException("Re-type Password cannot be blank");
			else
				user.setRepassword(request.getParameter("repass"));
			if (request.getParameter("gtype").equalsIgnoreCase(""))
				throw new BusinessException("Guardian type cannot be blank");
			else
				user.setGuardian_Type(request.getParameter("gtype"));
			if (request.getParameter("gname").isEmpty())
				throw new BusinessException("Guardian Name cannot be blank");
			else
				user.setGuardian_Name(request.getParameter("gname"));
			if (request.getParameter("address").isEmpty())
				throw new BusinessException("Address cannot be blank");
			else
				user.setAddress(request.getParameter("address"));

			if (request.getParameter("citizenship").isEmpty())
				throw new BusinessException("CitizenShip cannot be blank");
			else
				user.setCitizenship(request.getParameter("citizenship"));
			if (request.getParameter("country").equalsIgnoreCase(""))
				throw new BusinessException("country cannot be blank");
			else {
				user.setCountry(request.getParameter("country"));
				user.setState(request.getParameter("state"));
			}

			// if (request.getParameter("state1").equalsIgnoreCase("")
			// && request.getParameter("state2").equalsIgnoreCase(""))
			// throw new BusinessException("state cannot be blank");
			// else {
			// if (user.getCountry().equalsIgnoreCase("India"))
			// user.setState(request.getParameter("state1"));
			// else
			// user.setState(request.getParameter("state2"));
			// }
			if (request.getParameter("eid").isEmpty())
				throw new BusinessException("Email Id cannot be blank");
			else
				user.setEmail_Address(request.getParameter("eid"));
			if (request.getParameter("Gender").equalsIgnoreCase(""))
				throw new BusinessException("Gender cannot be blank");
			else
				user.setGender(request.getParameter("Gender"));
			if (request.getParameter("mstatus").equalsIgnoreCase(""))
				throw new BusinessException("Marital Status cannot be blank");
			else
				user.setMarital_Status(request.getParameter("mstatus"));
			if (request.getParameter("contactno").isEmpty())
				throw new BusinessException("Contact Number cannot be blank");
			else
				user.setContact_No(Long.parseLong((request
						.getParameter("contactno"))));

			if (request.getParameter("dob").isEmpty())
				throw new BusinessException("Date of birth cannot be blank");
			else
				user.setDate_Of_Birth(request.getParameter("dob"));
			user.setRegdate((String) session.getAttribute("regdate"));
			if (request.getParameter("account_type").equalsIgnoreCase(""))
				throw new BusinessException("Account Type cannot be blank");
			else
				user.setAccount_type(request.getParameter("account_type"));
			if (request.getParameter("branch_name").equalsIgnoreCase(""))
				throw new BusinessException("Branch Name cannot be blank");
			else
				user.setBranch_name(request.getParameter("branch_name"));
			if (request.getParameter("initial_deposit_amount").isEmpty())
				throw new BusinessException(
						"Initial Deposit Amount cannot be blank");
			else
				user.setInitial_deposit_amount(Float.parseFloat(request
						.getParameter("initial_deposit_amount")));
			if (request.getParameter("identification_proof_type")
					.equalsIgnoreCase(""))
				throw new BusinessException(
						"Identification Proof Type cannot be blank");
			else
				user.setIdentificationProof_Type(request
						.getParameter("identification_proof_type"));
			if (request.getParameter("identification_document_no").isEmpty())
				throw new BusinessException(
						"Identification Document Number cannot be blank");
			else
				user.setIdentificationDocument_Number(request
						.getParameter("identification_document_no"));
			if (request.getParameter("reference_account_holder_name").isEmpty())
				throw new BusinessException(
						"reference account holder name cannot be blank");
			else
				user.setRef_acc_holder_name(request
						.getParameter("reference_account_holder_name"));
			if (!request.getParameter("reference_account_no").isEmpty())
				user.setRef_acc_holder_no(request
						.getParameter("reference_account_no"));
			else
				throw new BusinessException(
						"reference account number cannot be blank");

			if (request.getParameter("reference_account_address").isEmpty())
				throw new BusinessException(
						"reference account address cannot be blank");
			else
				user.setRef_acc_holder_address(request
						.getParameter("reference_account_address"));
			System.out.println("hello");
			if (request.getParameter("Alternatecontactno").isEmpty())
				throw new BusinessException(
						"Alternate Contact Number cannot be blank");
			else
				user.setAlternateContact_No(Long.parseLong((request
						.getParameter("Alternatecontactno"))));
			if (request.getParameter("Alternateaddress").isEmpty())
				throw new BusinessException("Alternate Address cannot be blank");
			else
				user.setAlternateAddress(request
						.getParameter("Alternateaddress"));
			// flag=true;
			// System.out.println("Hello");
			flag = regbo.insertUser(user);
			System.out.println(flag);
			if (flag == true) {
				request.setAttribute("custid", user.getCustomer_Id());
				request.setAttribute("acct_no", user.getAccount_number());
				request.setAttribute("message", "register");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("Registration.jsp");
				dispatcher.forward(request, response);
			}

		} catch (BusinessException e) {
			LOG.error("BusinessException" + e.getMessage());
			request.setAttribute("message", e.getMessage());
			RequestDispatcher dispatch = request
					.getRequestDispatcher("Registration.jsp");
			dispatch.forward(request, response);
		} catch (NumberFormatException e) {
			LOG.error("Business exception" + e.getMessage());
			request.setAttribute("message",
					"Contact Number/Initial deposit Amount should be digits only");
			RequestDispatcher dispatch = request
					.getRequestDispatcher("Registration.jsp");
			dispatch.forward(request, response);
		} catch (Exception e) {
			LOG.error("Exception from controller" + e.getMessage());
			request.setAttribute("message", "Error");
			RequestDispatcher dispatch = request
					.getRequestDispatcher("Registration.jsp");
			dispatch.forward(request, response);
		}
	}
}
