package com.bms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.LoanBean;
import com.bms.bo.LoanBO;

public class LoanController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static Logger LOG = Logger.getLogger(LoanController.class);

	@SuppressWarnings("deprecation")
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		LoanBean bean = new LoanBean();
		LoanBO lb = new LoanBO();
		Boolean flag = false;
		HttpSession session = request.getSession(true);
		if (session.getAttribute("Customer_Id") == null) {
			response.sendRedirect("Login.jsp");
		}
		String s = (String) session.getAttribute("Customer_Id");
		LOG.info("inside Loancontroller");
		try {
			lb.checkinitialdeposit(s);
			bean.setCustid(s);
			String lt = request.getParameter("LoanType");
			if (lt.equalsIgnoreCase("A")) {
				bean.setLoanType("Educational");
			} else if (lt.equalsIgnoreCase("B")) {
				bean.setLoanType("Housing");
			} else if (lt.equalsIgnoreCase("C")) {
				bean.setLoanType("Personal");
			} else {
				throw new BusinessException("Invalid Loan Type");
			}
			System.out.println("2");
			String LoanAmount = request.getParameter("LoanAmount");
			System.out.println(LoanAmount + "LA");
			if (!LoanAmount.isEmpty()) {
				for (int i = 0; i < LoanAmount.length(); i++) {
					char c = LoanAmount.charAt(i);
					if (Character.isLetter(c)) {
						throw new BusinessException("Invalid Loan Amount.");
					}
				}
			} else
				throw new BusinessException("Invalid Loan Amount.");
			bean.setLoanAmount(Double.parseDouble(LoanAmount));
			String LoanApplyDate = request.getParameter("LoanApplyDate");
			bean.setLoanApplyDate(LoanApplyDate);
			bean.setRateOfInterest(Float.parseFloat(request
					.getParameter("RateOfinterest")));
			String DurationLoan = request.getParameter("LoanDuration");
			if (DurationLoan.equalsIgnoreCase("B")) {
				bean.setDurationLoan(5);
			} else if (DurationLoan.equalsIgnoreCase("C")) {
				bean.setDurationLoan(10);
			} else if (DurationLoan.equalsIgnoreCase("D")) {
				bean.setDurationLoan(15);
			} else if (DurationLoan.equalsIgnoreCase("E")) {
				bean.setDurationLoan(20);
			} else {
				throw new BusinessException("Invalid Duration of Loan.");
			}
			if (lt.equalsIgnoreCase("A")) {
				String CourseFee = request.getParameter("CourseFee");
				System.out.println(CourseFee + "CF");
				if (!CourseFee.isEmpty()) {
					for (int i = 0; i < CourseFee.length(); i++) {
						char c = CourseFee.charAt(i);
						if (Character.isLetter(c)) {
							throw new BusinessException("Invalid Course Fee.");
						}
					}
				} else
					throw new BusinessException("Invalid Course Fee.");
				bean.setCourseFee(Double.parseDouble(CourseFee));
				String Course = request.getParameter("Course");
				System.out.println(Course + "C");
				if (!Course.isEmpty()) {
				} else
					throw new BusinessException("Invalid Course.");
				bean.setCourse(Course);
				String FatherName = request.getParameter("FatherName");
				if (!FatherName.isEmpty()) {
					for (int i = 0; i < FatherName.length(); i++) {
						char c = FatherName.charAt(i);
						if (!Character.isLetter(c) && !Character.isSpace(c)) {
							throw new BusinessException(
									"Invalid Father's Name.");
						}
					}
					System.out.println("3");
				} else {
					throw new BusinessException("Invalid Father's Name.");
				}
				bean.setFatherName(FatherName);
				String FatherOccupation = request
						.getParameter("FatherOccupation");
				System.out.println(FatherOccupation + "FO");
				if (!FatherOccupation.isEmpty()) {
				} else {
					throw new BusinessException("Invalid Father's Occupation.");
				}
				bean.setFatherOccupation(FatherOccupation);
				String FatherTotalExp = request.getParameter("FatherTotalExp");
				if (!FatherTotalExp.isEmpty()) {
					for (int i = 0; i < FatherTotalExp.length(); i++) {
						char c = FatherTotalExp.charAt(i);
						if (Character.isLetter(c)) {
							throw new BusinessException(
									"Invalid Father\'s Total Experience.");
						}
					}
				} else {
					throw new BusinessException(
							"Invalid Father\'s Total Experience.");
				}
				bean.setFatherTotalExp(Integer.parseInt(FatherTotalExp));
				String FatherExpwCC = request.getParameter("FatherExpwCC");
				if (!FatherExpwCC.isEmpty()) {
					for (int i = 0; i < FatherExpwCC.length(); i++) {
						char c = FatherExpwCC.charAt(i);
						if (Character.isLetter(c)) {
							throw new BusinessException(
									"Invalid Father\'s Experience with Current Company.");
						}
					}
				} else {
					throw new BusinessException(
							"Invalid Father\'s Experience with Current Company.");
				}
				bean.setFatherExpwCC(Integer.parseInt(FatherExpwCC));
				String RationCard = request.getParameter("RationCard");
				if (!RationCard.isEmpty()) {
				} else {
					throw new BusinessException("Invalid RationCard No.");
				}
				bean.setRationCard(RationCard);
			}
			String AnnualIncome = request.getParameter("AnnualIncome");
			if (!AnnualIncome.isEmpty()) {
				for (int i = 0; i < AnnualIncome.length(); i++) {
					char c = AnnualIncome.charAt(i);
					if (Character.isLetter(c)) {
						throw new BusinessException("Invalid Annual Income.");
					}
				}
			} else {
				throw new BusinessException("Invalid Annual Income.");
			}
			System.out.println("4");
			bean.setAnnualIncome(Double.parseDouble(AnnualIncome));
			if (lt.equalsIgnoreCase("B") || lt.equalsIgnoreCase("C")) {
				String CompanyName = request.getParameter("CompanyName");
				if (!CompanyName.isEmpty()) {
				} else {
					throw new BusinessException("Invalid Company Name.");
				}
				bean.setCompanyName(CompanyName);
				String Designation = request.getParameter("Designation");
				if (!Designation.isEmpty()) {
				} else {
					throw new BusinessException("Invalid Designation.");
				}
				bean.setDesignation(Designation);
				String TotalExp = request.getParameter("TotalExp");
				if (!TotalExp.isEmpty()) {
					for (int i = 0; i < TotalExp.length(); i++) {
						char c = TotalExp.charAt(i);
						if (Character.isLetter(c)) {
							throw new BusinessException(
									"Invalid Total Experience.");
						}
					}
				} else {
					throw new BusinessException("Invalid Total Experience.");
				}
				bean.setTotalExp(Integer.parseInt(TotalExp));
				String ExpCC = request.getParameter("ExpCC");
				if (!ExpCC.isEmpty()) {
					for (int i = 0; i < ExpCC.length(); i++) {
						char c = ExpCC.charAt(i);
						if (Character.isLetter(c)) {
							throw new BusinessException(
									"Invalid Experience with Current Company.");
						}
					}
				} else {
					throw new BusinessException(
							"Invalid Experience with Current Company.");
				}
				bean.setExpCC(Integer.parseInt(ExpCC));

				String GuarantorName = request.getParameter("GuarantorName");
				if (!GuarantorName.isEmpty()) {
					for (int i = 0; i < GuarantorName.length(); i++) {
						char c = GuarantorName.charAt(i);
						if (!Character.isLetter(c) && !Character.isSpace(c)) {
							throw new BusinessException(
									"Invalid Guarantor's Name.");
						}
					}
				} else {
					throw new BusinessException("Invalid Guarantor's Name.");
				}
				bean.setGuarantorName(request.getParameter("GuarantorName"));

				if (request.getParameter("GuarantorAddress").isEmpty())
					throw new BusinessException(
							"GuarantorAddress cannot be blank");
				else
					bean.setGuarantorAddress(request
							.getParameter("GuarantorAddress"));

				String GuarantorIncome = request
						.getParameter("GuarantorIncome");
				if (!GuarantorIncome.isEmpty()) {
					for (int i = 0; i < GuarantorIncome.length(); i++) {
						char c = GuarantorIncome.charAt(i);
						if (Character.isLetter(c)) {
							throw new BusinessException(
									"Invalid Guarantor Income.");
						}
					}
				} else {
					throw new BusinessException("Invalid Guarantor Income.");
				}

				bean.setGuarantorIncome(Double.parseDouble(request
						.getParameter("GuarantorIncome")));

			}

			flag = lb.insertLoanDetails(bean);
			System.out.println("5");
			if (flag == true) {
				request.setAttribute("Message", "Success");
				request.setAttribute("Loan_Id", bean.getLoanId());
				request.setAttribute("LoanAccNo", bean.getLoanAccNo());
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("ApplyLoan.jsp");
				dispatcher.forward(request, response);
			}
		} catch (BusinessException be) {
			LOG.error("BusinessException" + be.getMessage());
			request.setAttribute("Message", "Error");
			request.setAttribute("error", be.getMessage());
			RequestDispatcher dispatch = request
					.getRequestDispatcher("ApplyLoan.jsp");
			dispatch.forward(request, response);
		} catch (Exception e) {
			LOG.error("Exception from LoanController..." + e.getMessage());
			request.setAttribute("Message", "FatalError");
			RequestDispatcher dispatch = request
					.getRequestDispatcher("ApplyLoan.jsp");
			dispatch.forward(request, response);
		}
		// System.out.println("6");
	}
}
