package com.bms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.LoginBean;
import com.bms.bo.LoginBO;

public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static Logger LOG = Logger.getLogger(LoginController.class);

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		LoginBean lb = new LoginBean();
		LoginBO l = new LoginBO();

		String check = null;

		LOG.info("inside Logincontroller");

		try {
			String s = request.getParameter("username");
			if (!s.isEmpty()) {
				lb.setUsername(s);
			} else {
				throw new BusinessException("Invalid UserName");
			}
			s = request.getParameter("password");
			if (!s.isEmpty()) {
				lb.setPassword(s);
			} else {
				throw new BusinessException("Invalid password");
			}

			check = l.checkLOGIN(lb);
			if (!check.equals(null)) { // if customer id present check for
										// TRUE
				HttpSession session = request.getSession();
				session.setAttribute("Customer_Id", check);
				session.setAttribute("username", lb.getUsername());

				RequestDispatcher disp = request
						.getRequestDispatcher("Welcome.jsp");
				disp.forward(request, response);
			} else {
				throw new BusinessException("UserName/Password does not match");
			}
		} catch (BusinessException le) {
			// LOG.error("Exception from Login Controller..." +
			// le.getMessage());
			request.setAttribute("Message", le.getMessage());
			RequestDispatcher disp = request.getRequestDispatcher("Login.jsp");
			disp.forward(request, response);
		} catch (Exception e) {
			// LOG.error("Exception from Login Controller..." + e.getMessage());
			request.setAttribute("Message", "FatalError occured");
			RequestDispatcher dispatch = request
					.getRequestDispatcher("Login.jsp");
			dispatch.forward(request, response);
		}
	}
}
