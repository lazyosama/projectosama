package com.bms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import com.bms.BusinessException.BusinessException;
import com.bms.bean.StatementGenerationBean;
import com.bms.util.PropertyUtil;

public class StatementGenerationDAO {
	public static Logger LOG =Logger.getLogger(StatementGenerationDAO.class);
	public static Connection conn=null;
	Statement stmt=null;
	ResultSet resultset=null;
	PreparedStatement ps=null;
	PropertyUtil util=new PropertyUtil();
	public String getAccNo(String CustId) throws SQLException, ClassNotFoundException{
		String AccNo="";
		try{
			conn=util.connections();
			String sql1="select Account_Number from account_info where Customer_Id like "+"'"+CustId+"'";
			stmt=conn.createStatement();  
			resultset=stmt.executeQuery(sql1);
			while(resultset.next()){
				AccNo=resultset.getString(1);
				LOG.info("inside Statement GenerationDAO creating after getting account number");
			}
		}finally{
			if (stmt != null) stmt.close();
			if (resultset != null) resultset.close();
		}
		return AccNo;
	}

	public String[] getNumberofTran(StatementGenerationBean bean) throws BusinessException, ParseException, SQLException, ClassNotFoundException{
		String check[]=new String[2];
		String AccNo=getAccNo(bean.getCustomer_Id());
		try{
			conn=util.connections();
			stmt=conn.createStatement();
			String sql="";
			if(bean.getTransaction_Type().equalsIgnoreCase("all")){
				sql="select count(*) from Transaction_Details " +
				"where Transaction_Date >= '"+util.utildatetosqldate(bean.getFrom_Date())+"' " +
				"and Transaction_Date <= '"+util.utildatetosqldate(bean.getTo_Date())+"' " +
				"and Account_Number like '"+AccNo+"'";}
			else{
				sql="select count(*) from Transaction_Details " +
				"where Transaction_Date >= '"+util.utildatetosqldate(bean.getFrom_Date())+"' " +
				"and Transaction_Date <= '"+util.utildatetosqldate(bean.getTo_Date())+"' and Transaction_Type ='"+bean.getTransaction_Type()+"' " +
				"and Account_Number like '"+AccNo+"'";}
			resultset=stmt.executeQuery(sql);
			int num=0;
			LOG.info("inside Statement GenerationDAO  before getting  number of transaction");
			if(resultset.next()){  
				num=resultset.getInt(1);
				check[0]=""+1;
				check[1]=""+num;
			}else{
				throw new BusinessException("No transaction between from date and to date");}
			LOG.info("inside Statement GenerationDAO creating after getting  number of transaction");
		}finally{
			if (stmt != null) stmt.close();
			if (resultset != null) resultset.close();
		}
		return check;
	}

	public ArrayList<StatementGenerationBean> transaction(StatementGenerationBean bean,int start,int rows) throws SQLException, ParseException, ClassNotFoundException{
		ArrayList<StatementGenerationBean> details=new ArrayList<StatementGenerationBean>();
		try{
			conn = util.connections();
			String AccNo=getAccNo(bean.getCustomer_Id());
			if(bean.getTransaction_Type().equalsIgnoreCase("all")){
				String sql = "select Transaction_Date,Transaction_Type,Transaction_Id," +
				"Transaction_Amount,Description,Cheque_Number,balance from Transaction_Details where " +
				"Account_Number='"+AccNo+"' and Transaction_Date >= '"+util.utildatetosqldate(bean.getFrom_Date())+"' " +
				"and Transaction_Date <= '"+util.utildatetosqldate(bean.getTo_Date())+"' limit "+start+","+rows+"";
				ps = conn.prepareStatement(sql);
				resultset = ps.executeQuery(sql);
				LOG.info("inside Statement GenerationDAO creating after fetching data from view");
				while(resultset.next()){
					StatementGenerationBean bean1=new StatementGenerationBean();
					bean1.setBalance(resultset.getString("balance"));
					bean1.setTransaction_Type(resultset.getString("Transaction_Type"));
					bean1.setTransaction_Date(resultset.getString("Transaction_Date"));
					bean1.setTransaction_Id( resultset.getString("Transaction_Id"));
					bean1.setAmount(resultset.getString("Transaction_Amount"));
					bean1.setDescription(resultset.getString("Description"));
					bean1.setCheque_Number(resultset.getString("Cheque_Number"));
					details.add(bean1);
				}
			}else if(bean.getTransaction_Type().equalsIgnoreCase("deposit")){
				String sql = "select Transaction_Date,Transaction_Type,Transaction_Id," +
				"Transaction_Amount,Description,Cheque_Number,balance from Transaction_Details where " +
				"Account_Number='"+AccNo+"' and Transaction_Date >= '"+util.utildatetosqldate(bean.getFrom_Date())+"' " +
				"and Transaction_Date <= '"+util.utildatetosqldate(bean.getTo_Date())+"' and Transaction_Type='deposit' limit "+start+","+rows+"";
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet resultset = ps.executeQuery(sql);
				while(resultset.next()){
					StatementGenerationBean bean1=new StatementGenerationBean();
					bean1.setBalance(resultset.getString("balance"));
					bean1.setTransaction_Type(resultset.getString("Transaction_Type"));
					bean1.setTransaction_Date(resultset.getString("Transaction_Date"));
					bean1.setTransaction_Id( resultset.getString("Transaction_Id"));
					bean1.setAmount(resultset.getString("Transaction_Amount"));
					bean1.setDescription(resultset.getString("Description"));
					bean1.setCheque_Number(resultset.getString("Cheque_Number"));
					details.add(bean1);
				}
			}else if(bean.getTransaction_Type().equalsIgnoreCase("withdrawal")){
				String sql = "select Transaction_Date,Transaction_Type,Transaction_Id," +
				"Transaction_Amount,Description,Cheque_Number,balance from Transaction_Details where " +
				"Account_Number='"+AccNo+"' and Transaction_Date >= '"+util.utildatetosqldate(bean.getFrom_Date())+"' " +
				"and Transaction_Date <= '"+util.utildatetosqldate(bean.getTo_Date())+"' and Transaction_Type='withdrawal' limit "+start+","+rows+"";
				ps = conn.prepareStatement(sql);
				resultset = ps.executeQuery(sql);
				while(resultset.next()){
					StatementGenerationBean bean1=new StatementGenerationBean();
					bean1.setBalance(resultset.getString("balance"));
					bean1.setTransaction_Type(resultset.getString("Transaction_Type"));
					bean1.setTransaction_Date(resultset.getString("Transaction_Date"));
					bean1.setTransaction_Id( resultset.getString("Transaction_Id"));
					bean1.setAmount(resultset.getString("Transaction_Amount"));
					bean1.setDescription(resultset.getString("Description"));
					bean1.setCheque_Number(resultset.getString("Cheque_Number"));
					details.add(bean1);
				}
			}
			LOG.info("inside Statement GenerationDAO after getting data for statement view");
		}finally{
			if (ps != null) ps.close();
			if (resultset != null) resultset.close();
		}
		return details;
	}

	public ArrayList<StatementGenerationBean> transactiondownload(StatementGenerationBean bean) throws SQLException, ParseException, ClassNotFoundException{
		ArrayList<StatementGenerationBean> details=new ArrayList<StatementGenerationBean>();
		String AccNo=getAccNo(bean.getCustomer_Id());
		try{ 
			conn = util.connections();
			String sql = "select Transaction_Date,Transaction_Type,Transaction_Id," +
			"Transaction_Amount,Description,Cheque_Number,balance from Transaction_Details where " +
			"Account_Number='"+AccNo+"' and Transaction_Date >= '"+util.utildatetosqldate(bean.getFrom_Date())+"' " +
			"and Transaction_Date <= '"+util.utildatetosqldate(bean.getTo_Date())+"'";
			ps = conn.prepareStatement(sql);
			resultset = ps.executeQuery(sql);
			LOG.info("inside Statement GenerationDAO creating after fetching data from download");
			while(resultset.next()){
				StatementGenerationBean bean1=new StatementGenerationBean();
				bean1.setBalance(resultset.getString("balance"));
				bean1.setTransaction_Type(resultset.getString("Transaction_Type"));
				bean1.setTransaction_Date(resultset.getString("Transaction_Date"));
				bean1.setTransaction_Id( resultset.getString("Transaction_Id"));
				bean1.setAmount(resultset.getString("Transaction_Amount"));
				bean1.setDescription(resultset.getString("Description"));
				bean1.setCheque_Number(resultset.getString("Cheque_Number"));
				if(bean.getTransaction_Type().equalsIgnoreCase("all"))
					details.add(bean1);
				else{
					if(bean.getTransaction_Type().equalsIgnoreCase(bean1.getTransaction_Type())){
						details.add(bean1);
					}
				}
			}
			LOG.info("inside Statement GenerationDAO after getting data for statement download");
		}finally{
			if (ps!= null) ps.close();
			if (resultset != null) resultset.close();
		}
		return details;
	}

	public String getCustName(String CustId) throws SQLException, ClassNotFoundException{
		String CustName="";
		try{
			conn=util.connections();
			String sql1="select Name from Customer_Details where Customer_Id like "+"'"+CustId+"'";
			stmt=conn.createStatement();  
			resultset=stmt.executeQuery(sql1);
			while(resultset.next()){
				CustName=resultset.getString(1);
			}
		}finally{
			if (stmt != null) stmt.close();
			if (resultset != null) resultset.close();
		}
		return CustName;
	}	        
}


